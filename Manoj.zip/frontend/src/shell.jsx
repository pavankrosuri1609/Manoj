// ============================================================================
// App shell — sidebar, header, notifications dropdown, breadcrumbs.
// ============================================================================
const NAV_ITEMS = [
  { id:'dashboard', label:'Dashboard',     icon:'layout-dashboard' },
  { id:'workflow',  label:'Workflow Board', icon:'kanban-square' },
  { id:'my',        label:'My Videos',     icon:'film' },
  { id:'all',       label:'All Videos',    icon:'library' },
  { id:'notifications', label:'Notifications', icon:'bell' },
];

const ADMIN_NAV_ITEMS = [
  { id:'dashboard', label:'Overview',     icon:'layout-dashboard' },
  { id:'users',     label:'Users & roles', icon:'users' },
  { id:'governance', label:'Security & Governance', icon:'shield' },
  { id:'all',       label:'All Videos',    icon:'library' },
  { id:'workflow',  label:'Workflow Board', icon:'kanban-square' },
  { id:'notifications', label:'Notifications', icon:'bell' },
];

function AppShell({ children }) {
  const { currentUser, route, navigate, notifications, dispatch } = useApp();
  const [sidebarOpen, setSidebarOpen] = React.useState(false);
  const unread = notifications.filter(n => n.for === currentUser.id && !n.read).length;

  return (
    <div className="min-h-screen flex flex-col bg-ink-50">
      <Header unread={unread} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen}/>
      <div className="flex-1 flex">
        <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} unread={unread}/>
        <main className="flex-1 min-w-0 lg:pl-64">
          {children}
        </main>
      </div>
      <Toasts/>
    </div>
  );
}

function Header({ unread, sidebarOpen, setSidebarOpen }) {
  const { currentUser, route, navigate, dispatch } = useApp();
  const [notifOpen, setNotifOpen] = React.useState(false);
  const [profileOpen, setProfileOpen] = React.useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-ink-200">
      <div className="h-14 px-4 lg:px-6 flex items-center gap-3">
        <button className="lg:hidden w-9 h-9 rounded-lg hover:bg-ink-100 flex items-center justify-center" onClick={() => setSidebarOpen(o => !o)}>
          <Icon name={sidebarOpen?'x':'menu'} size={18}/>
        </button>

        <button className="flex items-center gap-2 group" onClick={() => navigate({ name:'dashboard' })}>
          <Logo size={26}/>
          <div>
            <div className="font-bold text-[15px] tracking-tight text-ink-900 leading-none">Clinicast</div>
            <div className="text-[10px] uppercase tracking-widest text-ink-400 mt-0.5 leading-none">Workflow</div>
          </div>
        </button>

        <Breadcrumb/>

        <div className="ml-auto flex items-center gap-1">
          <SearchBox/>
          <div className="relative">
            <button onClick={() => setNotifOpen(o => !o)}
              className="w-9 h-9 rounded-lg hover:bg-ink-100 flex items-center justify-center relative">
              <Icon name="bell" size={18} className="text-ink-700"/>
              {unread > 0 && (
                <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-white">
                  {unread > 9 ? '9+' : unread}
                </span>
              )}
            </button>
            {notifOpen && <NotificationDropdown onClose={() => setNotifOpen(false)}/>}
          </div>

          <div className="hidden md:block w-px h-6 bg-ink-200 mx-1"></div>

          <div className="relative">
            <button onClick={() => setProfileOpen(o => !o)} className="flex items-center gap-2.5 pl-1 pr-2 py-1 rounded-lg hover:bg-ink-100">
              <Avatar user={currentUser} size={32}/>
              <div className="hidden md:block text-left leading-tight">
                <div className="text-[13px] font-semibold text-ink-900">{currentUser.name.replace(/^Dr\. /,'Dr. ')}</div>
                <div className="text-[11px] text-ink-500">{ROLES[currentUser.role].label}</div>
              </div>
              <Icon name="chevron-down" size={14} className="text-ink-400 hidden md:inline"/>
            </button>
            {profileOpen && <ProfileDropdown onClose={() => setProfileOpen(false)}/>}
          </div>
        </div>
      </div>
    </header>
  );
}

function Breadcrumb() {
  const { route, videos, navigate } = useApp();
  if (route.name === 'dashboard') return null;

  const labelMap = { workflow:'Workflow Board', my:'My Videos', all:'All Videos', notifications:'Notifications', detail:'Video Detail' };
  const trail = [{ label:'Dashboard', onClick:() => navigate({ name:'dashboard' }) }];
  if (route.name === 'detail') {
    const v = videos.find(x => x.id === route.videoId);
    trail.push({ label:'My Videos', onClick:() => navigate({ name:'my' }) });
    trail.push({ label: v?.title || 'Video', truncate:true });
  } else {
    trail.push({ label: labelMap[route.name] || route.name });
  }
  return (
    <nav className="hidden md:flex items-center gap-1.5 ml-3 text-[12.5px]">
      {trail.map((t, i) => (
        <div className="contents" key={i}>
          {i > 0 && <Icon name="chevron-right" size={12} className="text-ink-300"/>}
          {t.onClick ? (
            <button onClick={t.onClick} className="text-ink-500 hover:text-ink-900 font-medium">{t.label}</button>
          ) : (
            <span className={`font-semibold text-ink-900 ${t.truncate?'max-w-[280px] truncate':''}`}>{t.label}</span>
          )}
        </div>
      ))}
    </nav>
  );
}

function SearchBox() {
  const { navigate, videos } = useApp();
  const [q, setQ] = React.useState('');
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef();

  React.useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const results = q ? videos.filter(v => v.title.toLowerCase().includes(q.toLowerCase())).slice(0,5) : [];

  return (
    <div ref={ref} className="hidden md:block relative">
      <Icon name="search" size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-400"/>
      <input
        value={q}
        onChange={e => { setQ(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        placeholder="Search videos…"
        className="w-56 lg:w-72 h-9 pl-8 pr-3 rounded-lg border border-ink-200 bg-ink-50 text-[13px] focus:bg-white focus:border-brand-500 focus:ring-2 focus:ring-brand-100 focus:outline-none transition"
      />
      {open && q && (
        <div className="absolute top-full mt-1.5 right-0 w-80 bg-white border border-ink-200 rounded-xl shadow-pop p-1 max-h-80 overflow-auto scroll-thin">
          {results.length === 0 && <div className="p-4 text-sm text-ink-400 text-center">No videos match "{q}"</div>}
          {results.map(v => (
            <button key={v.id} onClick={() => { setOpen(false); setQ(''); navigate({ name:'detail', videoId: v.id }); }}
              className="w-full flex items-center gap-2 p-2 rounded-lg hover:bg-ink-50 text-left">
              <Thumbnail video={v} className="w-14 flex-shrink-0" overlay={false}/>
              <div className="flex-1 min-w-0">
                <div className="text-[12.5px] font-semibold text-ink-900 truncate">{v.title}</div>
                <div className="mt-0.5"><StatusBadge status={v.status} size="sm"/></div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function NotificationDropdown({ onClose }) {
  const { currentUser, notifications, dispatch, navigate } = useApp();
  const ref = React.useRef();
  React.useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const mine = notifications.filter(n => n.for === currentUser.id).sort((a,b) => new Date(b.at) - new Date(a.at));
  const unreadCount = mine.filter(n => !n.read).length;

  const iconMap = {
    ASSIGNED:'user-plus', PEER_REVIEW:'user-check', FINAL_REVIEW:'shield-check', REVIEW:'eye',
    APPROVED:'check-circle-2', PEER_APPROVED:'user-check', FINAL_APPROVED:'shield-check',
    REJECTED:'x-circle', PUBLISHED:'send', COMMENT:'message-circle', UPLOAD:'upload',
  };
  const toneMap = {
    ASSIGNED:'bg-blue-50 text-blue-600',
    PEER_REVIEW:'bg-amber-50 text-amber-600',
    FINAL_REVIEW:'bg-orange-50 text-orange-600',
    REVIEW:'bg-amber-50 text-amber-600',
    APPROVED:'bg-brand-50 text-brand-600',
    PEER_APPROVED:'bg-amber-50 text-amber-600',
    FINAL_APPROVED:'bg-brand-50 text-brand-600',
    REJECTED:'bg-rose-50 text-rose-600',
    PUBLISHED:'bg-indigo-50 text-indigo-600',
    COMMENT:'bg-ink-100 text-ink-600',
    UPLOAD:'bg-violet-50 text-violet-600',
  };

  return (
    <div ref={ref} className="absolute top-full right-0 mt-2 w-[380px] bg-white rounded-xl shadow-pop border border-ink-200 z-50 anim-slide-up">
      <div className="flex items-center justify-between p-3.5 border-b border-ink-100">
        <div>
          <div className="font-bold text-ink-900">Notifications</div>
          <div className="text-[11.5px] text-ink-500">{unreadCount} unread</div>
        </div>
        <button
          onClick={() => dispatch({ type:'MARK_ALL_READ', userId: currentUser.id })}
          disabled={unreadCount === 0}
          className="text-[12px] font-semibold text-brand-600 hover:text-brand-700 disabled:text-ink-300">
          Mark all read
        </button>
      </div>
      <div className="max-h-96 overflow-auto scroll-thin">
        {mine.length === 0 && (
          <div className="py-12"><EmptyState icon="bell-off" title="All caught up" body="No notifications yet."/></div>
        )}
        {mine.map(n => (
          <button key={n.id}
            onClick={() => {
              dispatch({ type:'MARK_NOTIFICATIONS_READ', ids:[n.id] });
              if (n.videoId) navigate({ name:'detail', videoId: n.videoId });
              onClose();
            }}
            className={`w-full text-left flex gap-3 p-3 border-b border-ink-100 last:border-0 hover:bg-ink-50 transition ${!n.read?'bg-brand-50/40':''}`}>
            <div className={`w-9 h-9 rounded-lg flex-shrink-0 flex items-center justify-center ${toneMap[n.type]||'bg-ink-100 text-ink-600'}`}>
              <Icon name={iconMap[n.type]||'bell'} size={16}/>
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[13px] text-ink-800 leading-snug">{n.text}</div>
              <div className="text-[11px] text-ink-400 mt-1">{timeAgo(n.at)}</div>
            </div>
            {!n.read && <span className="w-2 h-2 rounded-full bg-brand-500 mt-2 flex-shrink-0"></span>}
          </button>
        ))}
      </div>
    </div>
  );
}

function ProfileDropdown({ onClose }) {
  const { currentUser, dispatch, toast } = useApp();
  const ref = React.useRef();
  React.useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const resetDemo = () => {
    if (confirm('Reset the demo to its seed state? Your local edits will be lost.')) {
      dispatch({ type:'RESET' });
      toast({ tone:'info', title:'Demo reset', message:'Seed data restored.' });
      onClose();
    }
  };

  return (
    <div ref={ref} className="absolute top-full right-0 mt-2 w-72 bg-white rounded-xl shadow-pop border border-ink-200 z-50 overflow-hidden anim-slide-up">
      <div className="p-4 border-b border-ink-100 flex items-center gap-3">
        <Avatar user={currentUser} size={42}/>
        <div className="flex-1 min-w-0">
          <div className="font-bold text-ink-900 text-[13.5px] truncate">{currentUser.name}</div>
          <div className="text-[11.5px] text-ink-500 truncate">{currentUser.specialty}</div>
          <div className="mt-1"><RoleBadge role={currentUser.role}/></div>
        </div>
      </div>
      <div className="p-1.5">
        <MenuRow icon="repeat" label="Switch role" hint="Sign out & pick a new role" onClick={() => { dispatch({ type:'LOGOUT' }); onClose(); }}/>
        <MenuRow icon="refresh-ccw" label="Reset demo data" onClick={resetDemo}/>
        <div className="h-px bg-ink-100 my-1"></div>
        <MenuRow icon="log-out" label="Sign out" tone="rose" onClick={() => { dispatch({ type:'LOGOUT' }); onClose(); }}/>
      </div>
    </div>
  );
}

function MenuRow({ icon, label, hint, onClick, tone }) {
  return (
    <button onClick={onClick} className={`w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-ink-50 transition text-left ${tone==='rose'?'text-rose-600':'text-ink-800'}`}>
      <Icon name={icon} size={16}/>
      <div className="flex-1">
        <div className="font-semibold text-[13px] leading-tight">{label}</div>
        {hint && <div className="text-[11px] text-ink-500 mt-0.5">{hint}</div>}
      </div>
    </button>
  );
}

function Sidebar({ open, onClose, unread }) {
  const { currentUser, route, navigate, videos, users } = useApp();
  const isAdmin = currentUser.role === 'ADMIN';
  const navItems = isAdmin ? ADMIN_NAV_ITEMS : NAV_ITEMS;
  // Counts
  const myVideosCount = videos.filter(v => isVideoForUser(v, currentUser)).length;
  const activeUserCount = (users || []).filter(u => u.active !== false).length;

  return (
    <div className="contents">
      {open && <div className="lg:hidden fixed inset-0 bg-ink-900/40 z-30" onClick={onClose}></div>}
      <aside className={`fixed top-14 bottom-0 left-0 w-64 bg-white border-r border-ink-200 z-40 transition-transform duration-200 ${open?'translate-x-0':'-translate-x-full'} lg:translate-x-0 flex flex-col`}>
        <nav className="p-3 flex-1 overflow-y-auto scroll-thin">
          <div className="px-2 pt-2 pb-1 text-[10.5px] font-bold uppercase tracking-widest text-ink-400">{isAdmin ? 'Administration' : 'Workspace'}</div>
          {navItems.map(item => {
            const active = route.name === item.id;
            let count = null;
            if (item.id === 'notifications') count = unread > 0 ? unread : null;
            if (item.id === 'my') count = myVideosCount;
            if (item.id === 'users') count = activeUserCount;
            if (item.id === 'all') count = videos.length;
            return (
              <button key={item.id} onClick={() => { navigate({ name: item.id }); onClose(); }}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition my-0.5 ${active?'bg-ink-900 text-white shadow-card':'text-ink-700 hover:bg-ink-100'}`}>
                <Icon name={item.icon} size={16}/>
                <span className="font-semibold text-[13.5px] flex-1 text-left">{item.label}</span>
                {count !== null && (
                  <span className={`min-w-[20px] h-5 px-1.5 rounded-full text-[10.5px] font-bold inline-flex items-center justify-center ${active?'bg-white/15 text-white':'bg-ink-100 text-ink-600'}`}>{count}</span>
                )}
              </button>
            );
          })}

          {!isAdmin && (
            <div className="contents">
              <div className="px-2 pt-6 pb-1 text-[10.5px] font-bold uppercase tracking-widest text-ink-400">Pipeline</div>
              {STATUS_ORDER.map(s => {
                const count = videos.filter(v => v.status === s).length;
                return (
                  <button key={s} onClick={() => navigate({ name:'workflow', status: s })}
                    className="w-full flex items-center gap-3 px-3 py-1.5 rounded-lg hover:bg-ink-100 my-0.5">
                    <span className={`w-2 h-2 rounded-full ${STATUS[s].dot}`}></span>
                    <span className="text-[12.5px] text-ink-700 font-medium flex-1 text-left">{STATUS[s].label}</span>
                    <span className="text-[11px] text-ink-400 font-mono">{count}</span>
                  </button>
                );
              })}
            </div>
          )}

          {isAdmin && (
            <div className="contents">
              <div className="px-2 pt-6 pb-1 text-[10.5px] font-bold uppercase tracking-widest text-ink-400">Roles</div>
              {Object.keys(ROLES).map(r => {
                const count = (users || []).filter(u => u.role === r).length;
                return (
                  <button key={r} onClick={() => navigate({ name:'users', role: r })}
                    className="w-full flex items-center gap-3 px-3 py-1.5 rounded-lg hover:bg-ink-100 my-0.5">
                    <Icon name={({ADMIN:'shield',DOCTOR:'stethoscope',EDITOR:'film',WRITER:'pen-tool',APPROVER:'shield-check',SOCIAL:'send'})[r]||'user'} size={12} className="text-ink-500"/>
                    <span className="text-[12.5px] text-ink-700 font-medium flex-1 text-left">{ROLES[r].label}</span>
                    <span className="text-[11px] text-ink-400 font-mono">{count}</span>
                  </button>
                );
              })}
            </div>
          )}
        </nav>

        <div className="p-3 border-t border-ink-100">
          <div className={`${isAdmin?'bg-gradient-to-br from-ink-900 to-ink-800':'bg-ink-900'} text-white rounded-xl p-3.5 relative overflow-hidden`}>
            <div className="absolute -right-6 -top-6 w-20 h-20 rounded-full bg-brand-500/30 blur-2xl"></div>
            <div className="relative">
              <div className="text-[11px] uppercase tracking-widest text-brand-300 font-bold flex items-center gap-1">
                <Icon name={isAdmin?'shield':'sparkles'} size={11}/> {isAdmin ? 'Privileged session' : 'Demo Mode'}
              </div>
              <div className="text-[12.5px] mt-1 leading-snug text-ink-200">
                {isAdmin
                  ? 'You can manage all users, roles and assignments. Actions are audited.'
                  : 'All data is mocked. Switch roles freely to explore each view.'}
              </div>
            </div>
          </div>
        </div>
      </aside>
    </div>
  );
}

function isVideoForUser(v, user) {
  if (!user) return false;
  switch (user.role) {
    case 'DOCTOR':   return v.uploader === user.id;
    case 'EDITOR':   return v.editor === user.id;
    case 'WRITER':   return v.writer === user.id;
    case 'APPROVER':
      return user.tier === 'final'
        ? v.finalApprover === user.id
        : v.peerApprover === user.id;
    case 'SOCIAL':   return v.social === user.id;
    default: return false;
  }
}

Object.assign(window, { AppShell, NAV_ITEMS, isVideoForUser });
