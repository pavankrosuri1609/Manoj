// ============================================================================
// Login screen — role + user picker, with separate Admin sign-in tab.
// ============================================================================
function LoginScreen() {
  const { dispatch, toast, users } = useApp();
  const [mode, setMode] = React.useState('team');  // 'team' | 'admin'
  const [role, setRole] = React.useState('DOCTOR');
  const [pickedId, setPickedId] = React.useState('d1');
  const [pending, setPending] = React.useState(false);
  const [adminEmail, setAdminEmail] = React.useState('sarah.mitchell@clinicast.health');
  const [adminPassword, setAdminPassword] = React.useState('•••••••••');
  const [adminError, setAdminError] = React.useState('');

  const usersInRole = (users || []).filter(u => u.role === role && u.active !== false);
  React.useEffect(() => {
    if (!usersInRole.find(u => u.id === pickedId)) {
      setPickedId(usersInRole[0]?.id || '');
    }
  }, [role, users]);

  const signInTeam = () => {
    setPending(true);
    setTimeout(() => {
      dispatch({ type:'LOGIN', userId: pickedId });
      const u = (users || []).find(x => x.id === pickedId);
      toast({ tone:'success', title:`Welcome, ${u.name.split(' ')[0]}`, message:`Signed in as ${ROLES[u.role].label}.` });
      setPending(false);
    }, 500);
  };

  const signInAdmin = () => {
    setAdminError('');
    const match = (users || []).find(u => u.role === 'ADMIN' && u.email.toLowerCase() === adminEmail.trim().toLowerCase() && u.active !== false);
    if (!match) {
      setAdminError('No active administrator with that email. Try sarah.mitchell@clinicast.health');
      return;
    }
    if (!adminPassword.trim()) {
      setAdminError('Password is required.');
      return;
    }
    setPending(true);
    setTimeout(() => {
      dispatch({ type:'LOGIN', userId: match.id });
      toast({ tone:'success', title:`Welcome, ${match.name.split(' ')[0]}`, message:'Signed in as Administrator.' });
      setPending(false);
    }, 600);
  };

  return (
    <div className="min-h-screen w-full grid lg:grid-cols-[1fr_1fr]">
      {/* Left — brand panel */}
      <div className="relative hidden lg:flex flex-col justify-between p-12 bg-ink-900 text-white overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-[0.06]"></div>
        <div className="absolute -right-32 -top-32 w-[480px] h-[480px] rounded-full bg-brand-500/20 blur-3xl"></div>
        <div className="absolute -left-32 bottom-0 w-[420px] h-[420px] rounded-full bg-brand-700/30 blur-3xl"></div>

        <div className="relative z-10 flex items-center gap-2.5">
          <Logo size={32} variant="light"/>
          <span className="font-bold text-lg tracking-tight">Clinicast</span>
        </div>

        <div className="relative z-10 max-w-md">
          <div className="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-widest text-brand-300 bg-white/5 border border-white/10 rounded-full px-3 py-1 mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-400 pulse-ring"></span>
            Content Workflow Platform
          </div>
          <h1 className="text-[44px] leading-[1.05] font-extrabold tracking-tight">
            Doctor‑grade content,<br/>
            <span className="text-brand-300">moved through the right hands.</span>
          </h1>
          <p className="text-ink-300 mt-5 text-[15px] leading-relaxed max-w-sm">
            From the recording room to the feed — Clinicast routes every clip through editing, scripting, medical review and publishing in one continuous workflow.
          </p>

          <div className="mt-10 grid grid-cols-2 gap-3 max-w-sm">
            <StatCard label="Avg. cycle" value="48h" hint="Upload → publish"/>
            <StatCard label="Doctors" value="240+" hint="Across 18 specialties"/>
            <StatCard label="Reach" value="12M" hint="Monthly views"/>
            <StatCard label="Compliance" value="100%" hint="Medically reviewed"/>
          </div>
        </div>

        <div className="relative z-10 text-[12px] text-ink-400">
          © 2026 Clinicast Health Media · A workflow platform for verified medical content.
        </div>
      </div>

      {/* Right — sign-in card */}
      <div className="flex items-center justify-center p-6 lg:p-12 bg-ink-50">
        <div className="w-full max-w-[460px] anim-slide-up">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <Logo size={28}/>
            <span className="font-bold text-lg tracking-tight">Clinicast</span>
          </div>

          {/* Mode tabs */}
          <div className="inline-flex p-1 bg-white border border-ink-200 rounded-xl mb-6">
            <button onClick={() => setMode('team')} className={`flex items-center gap-2 px-3.5 h-9 rounded-lg text-[13px] font-semibold transition ${mode==='team'?'bg-ink-900 text-white shadow-card':'text-ink-600 hover:text-ink-900'}`}>
              <Icon name="users" size={14}/> Team sign-in
            </button>
            <button onClick={() => setMode('admin')} className={`flex items-center gap-2 px-3.5 h-9 rounded-lg text-[13px] font-semibold transition ${mode==='admin'?'bg-ink-900 text-white shadow-card':'text-ink-600 hover:text-ink-900'}`}>
              <Icon name="shield" size={14}/> Administrator
            </button>
          </div>

          {mode === 'team' && (
            <TeamSignIn
              role={role} setRole={setRole}
              pickedId={pickedId} setPickedId={setPickedId}
              usersInRole={usersInRole}
              pending={pending}
              onSubmit={signInTeam}
            />
          )}

          {mode === 'admin' && (
            <AdminSignIn
              email={adminEmail} setEmail={setAdminEmail}
              password={adminPassword} setPassword={setAdminPassword}
              error={adminError}
              pending={pending}
              onSubmit={signInAdmin}
              users={users}
            />
          )}

          <div className="mt-5 text-center text-[11.5px] text-ink-400">
            Demo environment · No real auth · Data stored locally in your browser
          </div>
        </div>
      </div>
    </div>
  );
}

function TeamSignIn({ role, setRole, pickedId, setPickedId, usersInRole, pending, onSubmit }) {
  // Only show roles a person picks themselves — ADMIN is via the Administrator tab.
  const teamRoles = ASSIGNABLE_ROLES.map(k => ROLES[k]);
  return (
    <div>
      <h2 className="text-2xl font-bold text-ink-900 tracking-tight">Pick a role to demo</h2>
      <p className="text-ink-500 text-sm mt-1">State persists locally — switch roles any time.</p>

      <div className="mt-6">
        <div className="text-[12px] font-semibold text-ink-700 mb-2">Choose your role</div>
        <div className="grid grid-cols-2 gap-2">
          {teamRoles.map(r => (
            <button key={r.key} onClick={() => setRole(r.key)}
              className={`text-left p-3 rounded-xl border-2 transition ${role===r.key?'border-brand-500 bg-brand-50/50':'border-ink-200 bg-white hover:border-ink-300'}`}>
              <div className="flex items-center gap-2">
                <RoleIcon role={r.key} active={role===r.key}/>
                <div className="font-semibold text-[13px] text-ink-900">{r.label}</div>
              </div>
              <div className="text-[11px] text-ink-500 mt-1 leading-snug">{r.desc}</div>
            </button>
          ))}
          <div className="p-3 rounded-xl border-2 border-dashed border-ink-200 flex items-center justify-center text-[11.5px] text-ink-400">
            <Icon name="users" size={14} className="mr-1.5"/>
            {usersInRole.length} member{usersInRole.length!==1?'s':''}
          </div>
        </div>
      </div>

      <div className="mt-5">
        <div className="text-[12px] font-semibold text-ink-700 mb-2">Continue as</div>
        <div className="flex flex-col gap-1.5 max-h-72 overflow-auto scroll-thin pr-1">
          {usersInRole.length === 0 && (
            <div className="text-[12.5px] text-ink-400 italic text-center py-4">No active users with this role.</div>
          )}
          {usersInRole.map(u => (
            <label key={u.id} className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition ${pickedId===u.id?'border-brand-500 bg-brand-50/40':'border-ink-200 bg-white hover:border-ink-300'}`}>
              <input type="radio" name="user" checked={pickedId===u.id} onChange={()=>setPickedId(u.id)} className="sr-only"/>
              <Avatar user={u} size={36}/>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-[13px] text-ink-900 truncate">{u.name}</div>
                <div className="text-[11.5px] text-ink-500 truncate">{u.specialty}</div>
              </div>
              <span className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${pickedId===u.id?'border-brand-500':'border-ink-300'}`}>
                {pickedId===u.id && <span className="w-1.5 h-1.5 bg-brand-500 rounded-full"></span>}
              </span>
            </label>
          ))}
        </div>
      </div>

      <div className="mt-6">
        <Button full size="lg" tone="brand" onClick={onSubmit} disabled={!pickedId||pending} iconRight={pending?undefined:'arrow-right'}>
          {pending ? 'Signing in…' : `Continue as ${ROLES[role].label}`}
        </Button>
      </div>
    </div>
  );
}

function AdminSignIn({ email, setEmail, password, setPassword, error, pending, onSubmit, users }) {
  const admins = (users || []).filter(u => u.role === 'ADMIN');
  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <div className="w-9 h-9 rounded-xl bg-ink-900 text-white flex items-center justify-center">
          <Icon name="shield" size={16}/>
        </div>
        <div>
          <h2 className="text-2xl font-bold text-ink-900 tracking-tight leading-none">Administrator sign-in</h2>
          <p className="text-ink-500 text-[12.5px] mt-1">Privileged access — user management, roles, and platform settings.</p>
        </div>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); onSubmit(); }} className="space-y-4 mt-6">
        <Field label="Administrator email" required>
          <div className="relative">
            <Icon name="mail" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
            <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="admin@clinicast.health" className="pl-9" type="email"/>
          </div>
        </Field>
        <Field label="Password" required>
          <div className="relative">
            <Icon name="lock" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
            <Input value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="pl-9" type="password"/>
          </div>
        </Field>

        {error && (
          <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 flex gap-2 text-[12.5px] text-rose-700">
            <Icon name="alert-circle" size={14} className="mt-0.5 flex-shrink-0"/>
            <span>{error}</span>
          </div>
        )}

        <div className="flex items-center justify-between text-[11.5px] text-ink-500">
          <label className="flex items-center gap-2 cursor-pointer">
            <Checkbox checked={true} onChange={()=>{}}/>
            <span>Trust this device for 24h</span>
          </label>
          <button type="button" className="font-semibold text-ink-700 hover:text-ink-900">Forgot password?</button>
        </div>

        <Button full size="lg" tone="primary" type="submit" disabled={pending} iconRight={pending?undefined:'arrow-right'}>
          {pending ? 'Signing in…' : 'Sign in as Administrator'}
        </Button>
      </form>

      {admins.length > 0 && (
        <div className="mt-5 bg-ink-100/70 border border-ink-200 rounded-xl p-3">
          <div className="text-[11px] uppercase tracking-widest font-bold text-ink-500 mb-2">Demo administrators</div>
          <div className="flex flex-col gap-1.5">
            {admins.map(a => (
              <button key={a.id} type="button" onClick={() => setEmail(a.email)}
                className="flex items-center gap-2.5 text-left p-1.5 rounded-lg hover:bg-white transition">
                <Avatar user={a} size={26}/>
                <div className="flex-1 min-w-0">
                  <div className="text-[12.5px] font-semibold text-ink-900 truncate">{a.name}</div>
                  <div className="text-[11px] text-ink-500 truncate font-mono">{a.email}</div>
                </div>
                <Icon name="arrow-up-left" size={12} className="text-ink-400"/>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, hint }) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-3 backdrop-blur-sm">
      <div className="text-[11px] uppercase tracking-widest text-ink-400 font-semibold">{label}</div>
      <div className="text-2xl font-extrabold mt-0.5 tracking-tight">{value}</div>
      <div className="text-[11px] text-ink-400 mt-0.5">{hint}</div>
    </div>
  );
}

function RoleIcon({ role, active }) {
  const map = {
    ADMIN:'shield', DOCTOR:'stethoscope', EDITOR:'film', WRITER:'pen-tool', APPROVER:'shield-check', SOCIAL:'send',
  };
  return (
    <span className={`w-7 h-7 rounded-lg flex items-center justify-center ${active?'bg-brand-500 text-white':'bg-ink-100 text-ink-600'}`}>
      <Icon name={map[role]||'user'} size={14}/>
    </span>
  );
}

function Logo({ size = 28, variant='dark' }) {
  const fg = variant==='light' ? '#ECFBF7' : '#0E1521';
  const accent = '#13A786';
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <rect x="2" y="2" width="28" height="28" rx="8" fill={fg}/>
      <path d="M9 19 L13 14 L16 17 L19 11 L23 19" stroke={accent} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      <circle cx="23" cy="19" r="2" fill={accent}/>
    </svg>
  );
}

Object.assign(window, { LoginScreen, Logo, RoleIcon });
