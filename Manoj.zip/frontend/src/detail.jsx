// ============================================================================
// Video Detail page — player placeholder, metadata, comments, timeline, actions.
// ============================================================================
function VideoDetail({ videoId }) {
  const { videos, currentUser, userById, navigate, addComment, toast } = useApp();
  const video = videos.find(v => v.id === videoId);
  const [activeVersionId, setActiveVersionId] = React.useState(null);

  React.useEffect(() => {
    if (video) setActiveVersionId(defaultVersionId(video));
  }, [video?.id, video?.versions?.length]);

  if (!video) {
    return (
      <div className="p-10">
        <EmptyState icon="search" title="Video not found" body="It may have been removed."
          action={<Button tone="brand" icon="arrow-left" onClick={() => navigate({ name:'dashboard' })}>Back to dashboard</Button>}/>
      </div>
    );
  }

  const up = userById(video.uploader);
  const editor = userById(video.editor);
  const writer = userById(video.writer);
  const peerApprover = userById(video.peerApprover);
  const finalApprover = userById(video.finalApprover);
  const social = userById(video.social);

  const activeVersion = (video.versions || []).find(v => v.id === activeVersionId) || (video.versions || [])[0];

  return (
    <div className="p-6 lg:p-10 max-w-[1280px] mx-auto">
      <button onClick={() => navigate({ name: currentUser.role === 'DOCTOR' ? 'dashboard' : 'my' })}
        className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-ink-500 hover:text-ink-900 mb-4">
        <Icon name="arrow-left" size={14}/> Back
      </button>

      <div className="grid lg:grid-cols-[1fr_360px] gap-6">
        {/* Left — main */}
        <div>
          <VideoPlayer video={video} activeVersion={activeVersion}/>

          <VersionsPanel video={video} activeId={activeVersion?.id} onSelect={setActiveVersionId}/>

          <div className="mt-5 flex items-start justify-between gap-4 flex-wrap">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-2">
                <StatusBadge status={video.status} size="lg"/>
                <span className="text-[12px] text-ink-500">·</span>
                <span className="text-[12px] text-ink-500">Uploaded {formatDate(video.createdAt)}</span>
                <span className="text-[12px] text-ink-500">·</span>
                <span className="text-[12px] text-ink-500 font-mono">{formatDuration(video.duration)}</span>
              </div>
              <h1 className="text-[28px] font-extrabold tracking-tight text-ink-900 leading-tight">{video.title}</h1>
              <p className="text-ink-600 mt-2 text-[14px] leading-relaxed">{video.description}</p>
            </div>
          </div>

          {(video.captions || video.hashtags?.length > 0 || video.platforms?.length > 0) && (
            <Card className="mt-5" padding="p-5">
              <SectionHeader title="Caption & metadata" hint="What the social team will publish"/>
              {video.captions && (
                <div className="bg-ink-50 rounded-lg p-3 text-[13px] text-ink-800 leading-relaxed italic">"{video.captions}"</div>
              )}
              {video.hashtags?.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {video.hashtags.map(h => <Pill key={h} tone="brand">{h}</Pill>)}
                </div>
              )}
              {video.platforms?.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-3">
                  <span className="text-[11.5px] text-ink-500 mr-1">Channels:</span>
                  {video.platforms.map(p => <Pill key={p} icon={({Instagram:'instagram',YouTube:'youtube',Twitter:'twitter',TikTok:'music',LinkedIn:'linkedin'})[p]||'send'}>{p}</Pill>)}
                </div>
              )}
            </Card>
          )}

          {video.reasons?.length > 0 && (
            <Card className="mt-5 border-rose-200 bg-rose-50/40" padding="p-5">
              <div className="flex items-center gap-2 mb-3">
                <Icon name="alert-triangle" size={16} className="text-rose-600"/>
                <h3 className="font-bold text-ink-900 text-[15px]">Change requests</h3>
              </div>
              <div className="space-y-2">
                {video.reasons.map((r, i) => (
                  <div key={i} className="bg-white border border-rose-200 rounded-lg p-3 text-[13px]">
                    <div className="text-ink-800">{r.reason}</div>
                    <div className="text-[11.5px] text-ink-500 mt-1.5">— {r.by} · {timeAgo(r.at)}</div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          <CommentsSection video={video}/>
        </div>

        {/* Right — sidebar */}
        <div className="space-y-5">
          <RoleActions video={video}/>

          <Card padding="p-5">
            <SectionHeader title="People"/>
            <div className="space-y-3">
              <PersonRow user={up} role="Doctor" icon="stethoscope"/>
              <PersonRow user={editor} role="Editor" icon="film"/>
              <PersonRow user={writer} role="Writer" icon="pen-tool"/>
              <PersonRow user={peerApprover} role="Peer Review · Stage 1" icon="user-check"/>
              <PersonRow user={finalApprover} role="Final Approval · Stage 2" icon="shield-check"/>
              <PersonRow user={social} role="Social Media" icon="send"/>
            </div>
          </Card>

          <Card padding="p-5">
            <SectionHeader title="Workflow timeline" hint="Who did what, when"/>
            <Timeline history={video.history}/>
          </Card>
        </div>
      </div>
    </div>
  );
}

function VideoPlayer({ video, activeVersion }) {
  const { userById } = useApp();
  const [playing, setPlaying] = React.useState(false);
  const [pos, setPos] = React.useState(0); // 0-100
  React.useEffect(() => {
    if (!playing) return;
    const i = setInterval(() => setPos(p => p >= 100 ? 0 : p + 100/(video.duration*4)), 250);
    return () => clearInterval(i);
  }, [playing, video.duration]);

  const currentSec = Math.floor(video.duration * (pos/100));

  return (
    <div className={`${`thumb-grad-${video.thumb % 6}`} relative rounded-2xl overflow-hidden shadow-card aspect-video`}>
      <svg className="absolute inset-0 w-full h-full opacity-25" viewBox="0 0 400 225" preserveAspectRatio="none">
        <path d="M0 140 Q 50 60, 100 140 T 200 140 T 300 140 T 400 140" stroke="white" strokeWidth="1.2" fill="none"/>
        <path d="M0 160 Q 50 100, 100 160 T 200 160 T 300 160 T 400 160" stroke="white" strokeWidth="0.8" fill="none" opacity="0.6"/>
        <circle cx="320" cy="60" r="30" stroke="white" strokeWidth="1" fill="none" opacity="0.5"/>
        <circle cx="320" cy="60" r="44" stroke="white" strokeWidth="0.6" fill="none" opacity="0.3"/>
        <circle cx="320" cy="60" r="58" stroke="white" strokeWidth="0.4" fill="none" opacity="0.2"/>
      </svg>

      {/* Floating title */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between gap-3 text-white">
        <div className="flex items-center gap-2">
          <span className="text-[11px] uppercase tracking-widest font-bold bg-black/40 backdrop-blur px-2 py-1 rounded">Clinicast Preview</span>
          {activeVersion && (
            <span className={`text-[11px] font-bold uppercase tracking-widest px-2 py-1 rounded backdrop-blur ${activeVersion.kind === 'edit' ? 'bg-brand-500/80' : 'bg-amber-500/80'}`}>
              {activeVersion.kind === 'edit' ? 'Edited cut' : 'Original'}
            </span>
          )}
        </div>
        <span className="text-[11px] font-mono bg-black/40 backdrop-blur px-2 py-1 rounded">
          {activeVersion?.fileName || video.id.toUpperCase()}
        </span>
      </div>

      {/* Play button */}
      <button onClick={() => setPlaying(p => !p)} className="absolute inset-0 m-auto w-20 h-20 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md flex items-center justify-center ring-1 ring-white/40 transition">
        <Icon name={playing?'pause':'play'} size={32} className="text-white" strokeWidth={2.5}/>
      </button>

      {/* Bottom controls */}
      <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 to-transparent">
        <div className="flex items-center gap-2 text-white text-[11.5px] font-mono mb-1.5">
          <span>{formatDuration(currentSec)}</span>
          <div className="flex-1 h-1 bg-white/20 rounded-full overflow-hidden">
            <div className="h-full bg-white transition-all" style={{ width: `${pos}%` }}></div>
          </div>
          <span>{formatDuration(video.duration)}</span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setPlaying(p => !p)} className="text-white hover:text-brand-300"><Icon name={playing?'pause':'play'} size={16}/></button>
          <button className="text-white/70 hover:text-white"><Icon name="volume-2" size={16}/></button>
          <div className="ml-auto flex items-center gap-1.5">
            <button className="text-white/70 hover:text-white"><Icon name="settings" size={16}/></button>
            <button className="text-white/70 hover:text-white"><Icon name="maximize" size={16}/></button>
          </div>
        </div>
      </div>
    </div>
  );
}

function PersonRow({ user, role, icon }) {
  if (!user) {
    return (
      <div className="flex items-center gap-3 opacity-50">
        <div className="w-9 h-9 rounded-full bg-ink-100 text-ink-400 flex items-center justify-center"><Icon name={icon} size={14}/></div>
        <div className="flex-1 min-w-0">
          <div className="text-[12.5px] text-ink-500">Unassigned</div>
          <div className="text-[10.5px] uppercase tracking-widest text-ink-400 font-bold">{role}</div>
        </div>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-3">
      <Avatar user={user} size={36}/>
      <div className="flex-1 min-w-0">
        <div className="text-[13px] font-semibold text-ink-900 truncate">{user.name}</div>
        <div className="text-[10.5px] uppercase tracking-widest text-ink-400 font-bold">{role}</div>
      </div>
    </div>
  );
}

function Timeline({ history }) {
  if (!history?.length) return <div className="text-[12px] text-ink-400">No history yet.</div>;
  return (
    <ol className="relative space-y-3.5">
      <span className="absolute left-[15px] top-2 bottom-2 w-px bg-ink-200"></span>
      {history.map((h, i) => {
        const s = actionStyle(h.action);
        return (
          <li key={i} className="flex gap-3 relative">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ring-4 ring-white ${s.bg}`}>
              <Icon name={s.icon} size={13} className={s.text}/>
            </div>
            <div className="flex-1 min-w-0 pt-0.5">
              <div className="text-[12.5px] text-ink-800 leading-snug">
                <span className="font-semibold">{h.actor}</span> {h.label}
              </div>
              <div className="text-[11px] text-ink-400 mt-0.5">{formatDate(h.at)} · {timeAgo(h.at)}</div>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

function CommentsSection({ video }) {
  const { currentUser, userById, addComment } = useApp();
  const [text, setText] = React.useState('');

  return (
    <Card className="mt-5" padding="p-5">
      <SectionHeader title="Comments" hint={`${video.comments.length} ${video.comments.length === 1 ? 'comment' : 'comments'}`}/>
      <div className="flex gap-3 mb-5">
        <Avatar user={currentUser} size={32}/>
        <div className="flex-1">
          <Textarea rows={2} value={text} onChange={e => setText(e.target.value)} placeholder={`Add a comment as ${currentUser.name}…`}/>
          <div className="flex justify-end mt-2">
            <Button size="sm" tone="brand" icon="send" disabled={!text.trim()} onClick={() => { addComment(video.id, text); setText(''); }}>Post comment</Button>
          </div>
        </div>
      </div>
      {video.comments.length === 0 ? (
        <div className="text-center py-6 text-[12.5px] text-ink-400">No comments yet. Start the conversation.</div>
      ) : (
        <div className="space-y-4">
          {video.comments.map(c => {
            const u = userById(c.author);
            return (
              <div key={c.id} className="flex gap-3">
                <Avatar user={u} size={32}/>
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline gap-2">
                    <span className="font-semibold text-ink-900 text-[13px]">{u?.name || 'Unknown'}</span>
                    <RoleBadge role={u?.role}/>
                    <span className="text-[11px] text-ink-400">· {timeAgo(c.at)}</span>
                  </div>
                  <div className="text-[13px] text-ink-800 mt-1 leading-relaxed">{c.text}</div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}

// ----------------------------------------------------------------------------
// Role-based action panel — shows what THIS user can do on THIS video.
// ----------------------------------------------------------------------------
function RoleActions({ video }) {
  const app = useApp();
  const { currentUser, completeEditing, peerApprove, finalApprove, publishVideo, navigate } = app;
  const [sendBackOpen, setSendBackOpen] = React.useState(false);
  const [publishOpen, setPublishOpen] = React.useState(false);

  const isMyVideo = isVideoForUser(video, currentUser);

  let content = null;

  // EDITOR + EDITING
  if (currentUser.role === 'EDITOR' && video.editor === currentUser.id && video.status === 'EDITING') {
    content = (
      <div className="contents">
        <ActionLead icon="scissors" title="You're the editor" hint="Mark as complete when the edit is final to hand off to the writer."/>
        <Button full tone="brand" icon="check" onClick={() => completeEditing(video)}>Complete editing</Button>
      </div>
    );
  }
  // WRITER + WRITING
  else if (currentUser.role === 'WRITER' && video.writer === currentUser.id && video.status === 'WRITING') {
    content = (
      <div className="contents">
        <ActionLead icon="pen-tool" title="You're the writer" hint="Add captions, hashtags and target platforms, then submit for review."/>
        <Button full tone="brand" icon="arrow-right" onClick={() => navigate({ name:'dashboard' })}>Open caption editor</Button>
      </div>
    );
  }
  // APPROVER · PEER (Stage 1)
  else if (currentUser.role === 'APPROVER' && currentUser.tier === 'peer' && video.status === 'PEER_REVIEW' && video.peerApprover === currentUser.id) {
    content = (
      <div className="contents">
        <ActionLead icon="user-check" title="Stage 1 — Peer review" hint="Verify clinical accuracy and source quality. Pass to Stage 2 or send back."/>
        <Button full tone="brand" icon="check" onClick={() => peerApprove(video)}>Approve · pass to Stage 2</Button>
        <Button full tone="secondary" icon="corner-up-left" onClick={() => setSendBackOpen(true)}>Send back…</Button>
        <SendBackModal open={sendBackOpen} onClose={() => setSendBackOpen(false)} video={video} fromStage="peer"/>
      </div>
    );
  }
  // APPROVER · FINAL (Stage 2)
  else if (currentUser.role === 'APPROVER' && currentUser.tier === 'final' && video.status === 'FINAL_REVIEW' && video.finalApprover === currentUser.id) {
    content = (
      <div className="contents">
        <ActionLead icon="shield-check" title="Stage 2 — Final approval" hint="Final compliance & brand sign-off. Once you approve, the video releases to the social team."/>
        <Button full tone="brand" icon="check" onClick={() => finalApprove(video)}>Final approve · release</Button>
        <Button full tone="secondary" icon="corner-up-left" onClick={() => setSendBackOpen(true)}>Send back…</Button>
        <SendBackModal open={sendBackOpen} onClose={() => setSendBackOpen(false)} video={video} fromStage="final"/>
      </div>
    );
  }
  // SOCIAL + APPROVED
  else if (currentUser.role === 'SOCIAL' && video.status === 'APPROVED') {
    content = (
      <div className="contents">
        <ActionLead icon="rocket" title="Ready to publish" hint="Choose channels and go live."/>
        <Button full tone="brand" icon="send" onClick={() => setPublishOpen(true)}>Publish to channels</Button>
        <PublishModalLite open={publishOpen} onClose={() => setPublishOpen(false)} video={video} onSubmit={(plats) => { publishVideo(video, plats); setPublishOpen(false); }}/>
      </div>
    );
  }
  // DOCTOR or generic info
  else {
    content = (
      <div className="contents">
        <ActionLead icon={video.status === 'PUBLISHED' ? 'check-circle-2' : 'eye'}
          title={video.status === 'PUBLISHED' ? 'Live across channels' : 'Tracking progress'}
          hint={video.status === 'PUBLISHED'
            ? `Published to ${(video.platforms||[]).join(', ') || 'channels'}.`
            : `Currently ${STATUS[video.status].label.toLowerCase()} — you'll be notified at every handoff.`}/>
        {isMyVideo && video.status === 'PUBLISHED' && (
          <div className="bg-ink-50 rounded-lg p-3 text-center">
            <div className="text-[10.5px] uppercase tracking-widest text-ink-400 font-bold">Performance (24h)</div>
            <div className="grid grid-cols-3 gap-3 mt-2 text-ink-900">
              <div><div className="text-lg font-bold">142K</div><div className="text-[10px] text-ink-500">Views</div></div>
              <div><div className="text-lg font-bold">8.4K</div><div className="text-[10px] text-ink-500">Likes</div></div>
              <div><div className="text-lg font-bold">6.2%</div><div className="text-[10px] text-ink-500">Engage</div></div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <Card padding="p-5" className="bg-gradient-to-br from-white to-brand-50/40 border-brand-200">
      <div className="flex flex-col gap-3">{content}</div>
      {['PEER_REVIEW','FINAL_REVIEW','APPROVED','PUBLISHED'].includes(video.status) && (
        <ApprovalProgress video={video}/>
      )}
    </Card>
  );
}

function ApprovalProgress({ video }) {
  const { userById } = useApp();
  const peer = userById(video.peerApprover);
  const fin = userById(video.finalApprover);
  const peerDone = ['FINAL_REVIEW','APPROVED','PUBLISHED'].includes(video.status);
  const finDone  = ['APPROVED','PUBLISHED'].includes(video.status);
  const stages = [
    { label:'Peer Review · Stage 1',    user: peer, done: peerDone, active: video.status === 'PEER_REVIEW' },
    { label:'Final Approval · Stage 2', user: fin,  done: finDone,  active: video.status === 'FINAL_REVIEW' },
  ];
  return (
    <div className="mt-4 pt-4 border-t border-brand-200/60">
      <div className="text-[10.5px] font-bold uppercase tracking-widest text-ink-500 mb-2">Approval progress</div>
      <div className="space-y-2">
        {stages.map((s, i) => (
          <div key={i} className="flex items-center gap-2.5">
            <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
              s.done ? 'bg-brand-500 text-white'
              : s.active ? 'bg-amber-500 text-white pulse-ring'
              : 'bg-ink-100 text-ink-400'
            }`}>
              {s.done ? <Icon name="check" size={12}/> : <span className="text-[11px] font-bold">{i+1}</span>}
            </div>
            <div className="flex-1 min-w-0">
              <div className={`text-[12.5px] font-semibold ${s.done?'text-ink-900':'text-ink-700'}`}>{s.label}</div>
              <div className="text-[11px] text-ink-500 truncate">
                {s.done
                  ? `Cleared by ${s.user?.name || 'reviewer'}`
                  : s.active
                    ? `Awaiting ${s.user?.name || 'reviewer'}`
                    : 'Pending'}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ActionLead({ icon, title, hint }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-10 h-10 rounded-xl bg-brand-600 text-white flex items-center justify-center flex-shrink-0">
        <Icon name={icon} size={18}/>
      </div>
      <div className="min-w-0">
        <div className="font-bold text-ink-900 text-[14px]">{title}</div>
        <div className="text-[12px] text-ink-500 mt-0.5 leading-snug">{hint}</div>
      </div>
    </div>
  );
}

// SendBackModal lives in dashboards.jsx (loaded earlier in the same global scope).

function PublishModalLite({ open, onClose, video, onSubmit }) {
  const [plats, setPlats] = React.useState([]);
  React.useEffect(() => { if (open) setPlats(video.platforms?.length ? video.platforms : ['Instagram','YouTube']); }, [open, video]);
  const toggle = (p) => setPlats(plats.includes(p) ? plats.filter(x=>x!==p) : [...plats, p]);
  return (
    <Modal open={open} onClose={onClose} title="Publish to channels"
      footer={<>
        <Button tone="secondary" onClick={onClose}>Cancel</Button>
        <Button tone="brand" icon="send" disabled={plats.length === 0} onClick={() => onSubmit(plats)}>Publish to {plats.length}</Button>
      </>}>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {PLATFORMS.map(p => (
          <button key={p} onClick={() => toggle(p)} className={`flex items-center gap-2 p-3 rounded-lg border-2 transition ${plats.includes(p)?'border-brand-500 bg-brand-50/50':'border-ink-200 hover:border-ink-300'}`}>
            <PlatformIcon name={p}/>
            <span className="text-[13px] font-semibold flex-1 text-left">{p}</span>
            {plats.includes(p) && <Icon name="check" size={14} className="text-brand-600"/>}
          </button>
        ))}
      </div>
    </Modal>
  );
}

// ----------------------------------------------------------------------------
// Versions panel — shows raw (doctor) + edited (editor) and lets viewer switch.
// ----------------------------------------------------------------------------
function VersionsPanel({ video, activeId, onSelect }) {
  const { userById, currentUser, toast } = useApp();
  const versions = video.versions || [];
  if (versions.length === 0) return null;

  return (
    <div className="mt-5">
      <div className="flex items-center justify-between mb-2.5">
        <div className="flex items-center gap-2">
          <h3 className="font-bold text-ink-900 text-[15px]">Files & versions</h3>
          <span className="text-[11px] font-mono text-ink-500 bg-ink-100 rounded px-1.5 py-0.5">{versions.length}</span>
        </div>
        <span className="text-[11.5px] text-ink-500">Switch to compare</span>
      </div>

      <div className="grid sm:grid-cols-2 gap-2.5">
        {versions.map((v, i) => {
          const author = userById(v.by);
          const isActive = v.id === activeId;
          const isRaw = v.kind === 'raw';
          return (
            <button
              key={v.id}
              onClick={() => onSelect(v.id)}
              className={`text-left rounded-xl border-2 p-3 transition relative ${isActive
                ? (isRaw ? 'border-amber-400 bg-amber-50/40' : 'border-brand-500 bg-brand-50/40')
                : 'border-ink-200 bg-white hover:border-ink-300'}`}
            >
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${isRaw ? 'bg-amber-100 text-amber-700' : 'bg-brand-100 text-brand-700'}`}>
                  <Icon name={isRaw ? 'video' : 'film'} size={18}/>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className={`text-[10px] font-bold uppercase tracking-widest px-1.5 py-0.5 rounded ${isRaw ? 'bg-amber-100 text-amber-700' : 'bg-brand-100 text-brand-700'}`}>
                      {isRaw ? 'Raw' : 'Edit'}
                    </span>
                    <span className="font-semibold text-ink-900 text-[13px] truncate">{v.label}</span>
                    {isActive && <Icon name="play-circle" size={14} className={isRaw ? 'text-amber-600' : 'text-brand-600'}/>}
                  </div>
                  <div className="font-mono text-[11.5px] text-ink-600 truncate mt-1">{v.fileName}</div>
                  <div className="flex items-center gap-2 text-[11px] text-ink-500 mt-1.5">
                    {author && <Avatar user={author} size={16}/>}
                    <span className="truncate">{author?.name || 'Unknown'}</span>
                    <span>·</span>
                    <span>{timeAgo(v.at)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10.5px] text-ink-400 mt-1 font-mono">
                    <span>{v.sizeMB?.toFixed(1)} MB</span>
                    <span>·</span>
                    <span className="truncate">{v.notes}</span>
                  </div>
                </div>
              </div>
              <div className="flex justify-end gap-1.5 mt-2.5 pt-2.5 border-t border-ink-100">
                <button
                  onClick={(e) => { e.stopPropagation(); toast({ tone:'info', title:'Download started', message:`Fetching ${v.fileName}…` }); }}
                  className="inline-flex items-center gap-1 text-[11.5px] font-semibold text-ink-600 hover:text-ink-900 px-2 py-1 rounded hover:bg-ink-100"
                >
                  <Icon name="download" size={12}/> Download
                </button>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { VideoDetail, VersionsPanel });
