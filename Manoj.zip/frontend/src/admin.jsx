// ============================================================================
// Admin dashboard + user management (RBAC).
// ============================================================================
function AdminDashboard() {
  const { users, currentUser, videos, navigate, deleteUser, route } = useApp();
  const [filter, setFilter] = React.useState('ALL');
  const [q, setQ] = React.useState('');
  const [editing, setEditing] = React.useState(null);     // user object being edited
  const [creating, setCreating] = React.useState(false);
  const [confirmDel, setConfirmDel] = React.useState(null);

  // Sync filter from route (sidebar role chips link with ?role=).
  React.useEffect(() => {
    if (route?.name === 'users' && route.role && route.role !== filter) {
      setFilter(route.role);
    }
  }, [route?.role]);

  const counts = React.useMemo(() => {
    const c = { total: users.length, active: users.filter(u => u.active !== false).length };
    Object.keys(ROLES).forEach(r => { c[r] = users.filter(u => u.role === r).length; });
    return c;
  }, [users]);

  const filtered = users.filter(u => {
    if (filter !== 'ALL' && u.role !== filter) return false;
    if (q && !`${u.name} ${u.email} ${u.specialty}`.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="p-6 lg:p-10 max-w-[1280px] mx-auto">
      <PageHeader
        eyebrow="RBAC · User management"
        title="Users & roles"
        subtitle="Add teammates, assign roles, and control who can see what. All access is gated by role — change the role, change the dashboard."
        actions={<Button tone="primary" icon="user-plus" onClick={() => setCreating(true)}>Add user</Button>}
      />

      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3 mb-6">
        <StatTile icon="users" label="Total users" value={counts.total} tone="ink"/>
        <StatTile icon="user-check" label="Active" value={counts.active} hint={`${counts.total - counts.active} inactive`} tone="brand"/>
        <StatTile icon="stethoscope" label="Doctors" value={counts.DOCTOR || 0} tone="brand"/>
        <StatTile icon="film" label="Editors" value={counts.EDITOR || 0} tone="blue"/>
        <StatTile icon="pen-tool" label="Writers" value={counts.WRITER || 0} tone="violet"/>
        <StatTile icon="shield-check" label="Reviewers" value={counts.APPROVER || 0} tone="amber"/>
      </div>

      <Card padding="p-3" className="mb-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[220px]">
            <Icon name="search" size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-400"/>
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search name, email or specialty…"
              className="w-full h-9 pl-8 pr-3 rounded-lg border border-ink-200 text-[13px] focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100"/>
          </div>
          <div className="flex gap-1 flex-wrap">
            <FilterChip active={filter==='ALL'} onClick={() => setFilter('ALL')}>All <span className="text-ink-400 ml-1 font-mono">{counts.total}</span></FilterChip>
            {Object.keys(ROLES).map(r => (
              <FilterChip key={r} active={filter===r} onClick={() => setFilter(r)}>
                <Icon name={ROLE_ICONS[r]||'user'} size={11} className="mr-1.5"/>
                {ROLES[r].label}
                <span className="text-ink-400 ml-1 font-mono">{counts[r]||0}</span>
              </FilterChip>
            ))}
          </div>
        </div>
      </Card>

      {filtered.length === 0 ? (
        <Card><EmptyState icon="users" title="No matching users" body="Try a different filter or search."/></Card>
      ) : (
        <Card padding="p-0">
          <div className="overflow-x-auto scroll-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-ink-50 border-b border-ink-200 text-[11px] uppercase tracking-widest text-ink-500">
                  <th className="text-left font-bold px-4 py-2.5">User</th>
                  <th className="text-left font-bold px-4 py-2.5 hidden md:table-cell">Email</th>
                  <th className="text-left font-bold px-4 py-2.5 hidden lg:table-cell">Phone</th>
                  <th className="text-left font-bold px-4 py-2.5">Role</th>
                  <th className="text-left font-bold px-4 py-2.5 hidden md:table-cell">Status</th>
                  <th className="text-right font-bold px-4 py-2.5">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(u => (
                  <UserRow
                    key={u.id}
                    user={u}
                    isSelf={u.id === currentUser.id}
                    onEdit={() => setEditing(u)}
                    onDelete={() => setConfirmDel(u)}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <div className="mt-6 bg-white border border-ink-200 rounded-xl p-4 flex items-start gap-3">
        <div className="w-9 h-9 rounded-lg bg-ink-900 text-white flex items-center justify-center flex-shrink-0">
          <Icon name="shield" size={16}/>
        </div>
        <div className="flex-1">
          <div className="font-semibold text-ink-900 text-[13px]">Role-based access (RBAC)</div>
          <div className="text-[12px] text-ink-500 mt-1 leading-relaxed">
            Every action is gated by role. Editors only see videos at <span className="font-semibold text-ink-700">Editing</span>; Stage 1 reviewers only see videos at <span className="font-semibold text-ink-700">Peer Review</span>; Stage 2 only at <span className="font-semibold text-ink-700">Final Approval</span>. Deactivating a user immediately revokes their session and removes them from assignment pickers.
          </div>
        </div>
      </div>

      <UserFormModal
        open={creating}
        onClose={() => setCreating(false)}
        mode="create"
      />
      <UserFormModal
        open={!!editing}
        onClose={() => setEditing(null)}
        mode="edit"
        user={editing}
      />
      <DeleteConfirmModal
        open={!!confirmDel}
        user={confirmDel}
        onClose={() => setConfirmDel(null)}
        onConfirm={() => { deleteUser(confirmDel.id); setConfirmDel(null); }}
      />
    </div>
  );
}

const ROLE_ICONS = { ADMIN:'shield', DOCTOR:'stethoscope', EDITOR:'film', WRITER:'pen-tool', APPROVER:'shield-check', SOCIAL:'send' };
const ROLE_TONES = {
  ADMIN:'bg-ink-900 text-white',
  DOCTOR:'bg-brand-50 text-brand-700',
  EDITOR:'bg-blue-50 text-blue-700',
  WRITER:'bg-violet-50 text-violet-700',
  APPROVER:'bg-amber-50 text-amber-700',
  SOCIAL:'bg-indigo-50 text-indigo-700',
};

function RolePill({ role, tier, size='md' }) {
  const dims = size === 'sm' ? 'text-[10.5px] px-1.5 py-0.5' : 'text-[11px] px-2 py-0.5';
  return (
    <span className={`inline-flex items-center gap-1 rounded-md font-bold uppercase tracking-wide ${ROLE_TONES[role]||'bg-ink-100 text-ink-700'} ${dims}`}>
      <Icon name={ROLE_ICONS[role]||'user'} size={size==='sm'?10:12}/>
      {ROLES[role]?.label || role}
      {tier && <span className="opacity-80 font-medium">· {APPROVER_TIERS[tier]?.short || tier}</span>}
    </span>
  );
}

function UserRow({ user, isSelf, onEdit, onDelete }) {
  const { updateUser } = useApp();
  const toggleActive = () => updateUser(user.id, { active: user.active === false });
  return (
    <tr className="border-b border-ink-100 last:border-0 hover:bg-ink-50/60 transition">
      <td className="px-4 py-3">
        <div className="flex items-center gap-3">
          <Avatar user={user} size={36}/>
          <div className="min-w-0">
            <div className="font-semibold text-ink-900 text-[13.5px] truncate">{user.name}
              {isSelf && <span className="ml-1.5 text-[10px] font-bold text-brand-600 uppercase tracking-wider">You</span>}
            </div>
            <div className="text-[11.5px] text-ink-500 truncate">{user.specialty}</div>
          </div>
        </div>
      </td>
      <td className="px-4 py-3 hidden md:table-cell">
        <a href={`mailto:${user.email}`} className="text-[12.5px] font-mono text-ink-700 hover:text-brand-700 truncate inline-block max-w-[220px]">{user.email}</a>
      </td>
      <td className="px-4 py-3 hidden lg:table-cell text-[12.5px] font-mono text-ink-600">{user.phone}</td>
      <td className="px-4 py-3"><RolePill role={user.role} tier={user.tier}/></td>
      <td className="px-4 py-3 hidden md:table-cell">
        <button onClick={toggleActive} className={`inline-flex items-center gap-1.5 text-[11.5px] font-semibold rounded-full px-2 py-0.5 border transition ${
          user.active !== false
            ? 'bg-brand-50 text-brand-700 border-brand-200 hover:bg-brand-100'
            : 'bg-ink-100 text-ink-500 border-ink-200 hover:bg-ink-200'
        }`}>
          <span className={`w-1.5 h-1.5 rounded-full ${user.active !== false ? 'bg-brand-500' : 'bg-ink-400'}`}></span>
          {user.active !== false ? 'Active' : 'Inactive'}
        </button>
      </td>
      <td className="px-4 py-3 text-right">
        <div className="inline-flex gap-1">
          <IconButton name="pencil" title="Edit user" onClick={onEdit}/>
          <IconButton name="trash-2" title="Delete user" onClick={onDelete} className={isSelf?'opacity-30 cursor-not-allowed':'hover:bg-rose-50 hover:text-rose-600'}/>
        </div>
      </td>
    </tr>
  );
}

// ----------------------------------------------------------------------------
// User create / edit modal
// ----------------------------------------------------------------------------
function UserFormModal({ open, onClose, mode='create', user }) {
  const { createUser, updateUser, users, toast } = useApp();
  const [name, setName] = React.useState('');
  const [email, setEmail] = React.useState('');
  const [phone, setPhone] = React.useState('');
  const [role, setRole] = React.useState('DOCTOR');
  const [tier, setTier] = React.useState('peer');
  const [specialty, setSpecialty] = React.useState('');
  const [errors, setErrors] = React.useState({});

  React.useEffect(() => {
    if (open) {
      if (mode === 'edit' && user) {
        setName(user.name || '');
        setEmail(user.email || '');
        setPhone(user.phone || '');
        setRole(user.role || 'DOCTOR');
        setTier(user.tier || 'peer');
        setSpecialty(user.specialty || '');
      } else {
        setName(''); setEmail(''); setPhone('');
        setRole('DOCTOR'); setTier('peer'); setSpecialty('');
      }
      setErrors({});
    }
  }, [open, user, mode]);

  const validate = () => {
    const e = {};
    if (!name.trim()) e.name = 'Name is required';
    if (!email.trim()) e.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) e.email = 'Enter a valid email address';
    else {
      const conflict = (users || []).find(u => u.email.toLowerCase() === email.trim().toLowerCase() && (mode === 'create' || u.id !== user?.id));
      if (conflict) e.email = `Already used by ${conflict.name}`;
    }
    if (!phone.trim()) e.phone = 'Phone is required';
    else if (!/^[+\d][\d\s\-().]{6,}$/.test(phone.trim())) e.phone = 'Enter a valid phone number';
    if (!role) e.role = 'Role is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = () => {
    if (!validate()) return;
    const payload = { name, email, phone, role, specialty };
    if (role === 'APPROVER') payload.tier = tier;
    if (mode === 'create') {
      createUser(payload);
    } else {
      const patch = { ...payload };
      if (role !== 'APPROVER') patch.tier = undefined;
      updateUser(user.id, patch);
    }
    onClose();
  };

  const isAdminEdit = mode === 'edit' && user?.role === 'ADMIN';

  return (
    <Modal open={open} onClose={onClose} title={mode === 'create' ? 'Add new user' : `Edit ${user?.name || 'user'}`} size="lg"
      footer={<>
        <Button tone="secondary" onClick={onClose}>Cancel</Button>
        <Button tone="primary" icon={mode === 'create' ? 'user-plus' : 'save'} onClick={submit}>
          {mode === 'create' ? 'Create user' : 'Save changes'}
        </Button>
      </>}>
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="sm:col-span-2">
          <Field label="Full name" required>
            <div className="relative">
              <Icon name="user" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
              <Input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Dr. Aisha Khan" className="pl-9"/>
            </div>
            {errors.name && <FieldError>{errors.name}</FieldError>}
          </Field>
        </div>

        <Field label="Email address" required>
          <div className="relative">
            <Icon name="mail" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
            <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="name@clinicast.health" className="pl-9" type="email"/>
          </div>
          {errors.email && <FieldError>{errors.email}</FieldError>}
        </Field>

        <Field label="Phone number" required>
          <div className="relative">
            <Icon name="phone" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
            <Input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+1 (415) 555-0100" className="pl-9" type="tel"/>
          </div>
          {errors.phone && <FieldError>{errors.phone}</FieldError>}
        </Field>

        <div className="sm:col-span-2">
          <Field label="Role" required hint="Defines what this user sees and can do. Administrators are managed separately.">
            {isAdminEdit ? (
              <div className="bg-ink-100 border border-ink-200 rounded-lg p-2.5 text-[12.5px] text-ink-600 flex items-center gap-2">
                <Icon name="lock" size={13}/> Administrator role can't be changed from this form.
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {ASSIGNABLE_ROLES.map(r => (
                  <button key={r} type="button" onClick={() => setRole(r)}
                    className={`p-3 rounded-lg border-2 text-left transition ${role===r?'border-brand-500 bg-brand-50/40':'border-ink-200 hover:border-ink-300'}`}>
                    <div className="flex items-center gap-2">
                      <span className={`w-7 h-7 rounded-lg flex items-center justify-center ${role===r?'bg-brand-500 text-white':'bg-ink-100 text-ink-600'}`}>
                        <Icon name={ROLE_ICONS[r]} size={13}/>
                      </span>
                      <span className="font-semibold text-[12.5px] text-ink-900">{ROLES[r].label}</span>
                    </div>
                    <div className="text-[10.5px] text-ink-500 mt-1.5 leading-snug">{ROLES[r].desc}</div>
                  </button>
                ))}
              </div>
            )}
          </Field>
        </div>

        {role === 'APPROVER' && !isAdminEdit && (
          <div className="sm:col-span-2">
            <Field label="Review tier" required hint="Stage 1 reviewers check clinical accuracy. Stage 2 handles compliance & final sign-off.">
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(APPROVER_TIERS).map(([k, t]) => (
                  <button key={k} type="button" onClick={() => setTier(k)}
                    className={`p-3 rounded-lg border-2 text-left transition ${tier===k?'border-brand-500 bg-brand-50/40':'border-ink-200 hover:border-ink-300'}`}>
                    <div className="flex items-center gap-2">
                      <Icon name={t.icon} size={14} className={tier===k?'text-brand-600':'text-ink-500'}/>
                      <span className="font-semibold text-[12.5px] text-ink-900">{t.label}</span>
                    </div>
                    <div className="text-[10.5px] text-ink-500 mt-1.5">{t.short}</div>
                  </button>
                ))}
              </div>
            </Field>
          </div>
        )}

        <div className="sm:col-span-2">
          <Field label="Specialty / title" hint="Optional — shown next to their name across the app.">
            <Input value={specialty} onChange={e => setSpecialty(e.target.value)} placeholder={role === 'DOCTOR' ? 'e.g. Endocrinology' : role === 'EDITOR' ? 'e.g. Senior Editor' : 'e.g. Copy Lead'}/>
          </Field>
        </div>
      </div>

      <div className="mt-5 bg-ink-50 border border-ink-200 rounded-lg p-3 flex gap-3 items-start">
        <div className="w-8 h-8 rounded-lg bg-white border border-ink-200 flex items-center justify-center flex-shrink-0">
          <Icon name="key-round" size={14} className="text-ink-500"/>
        </div>
        <div className="text-[11.5px] text-ink-500 leading-relaxed">
          New users receive an email with a one-time sign-in link. In this demo environment, they appear immediately in the role picker on the login screen.
        </div>
      </div>
    </Modal>
  );
}

function FieldError({ children }) {
  return <div className="text-[11.5px] text-rose-600 mt-1 flex items-center gap-1"><Icon name="alert-circle" size={11}/>{children}</div>;
}

function DeleteConfirmModal({ open, onClose, onConfirm, user }) {
  if (!user) return null;
  return (
    <Modal open={open} onClose={onClose} title="Remove user?"
      footer={<>
        <Button tone="secondary" onClick={onClose}>Cancel</Button>
        <Button tone="danger" icon="trash-2" onClick={onConfirm}>Yes, remove</Button>
      </>}>
      <div className="flex items-start gap-3 bg-rose-50 border border-rose-200 rounded-lg p-3">
        <div className="w-10 h-10 rounded-lg bg-white border border-rose-200 flex items-center justify-center flex-shrink-0">
          <Icon name="alert-triangle" size={18} className="text-rose-600"/>
        </div>
        <div className="text-[13px] text-rose-800 leading-relaxed">
          You're about to remove <span className="font-semibold">{user.name}</span> ({ROLES[user.role].label}).
          If this user has open assignments, they'll be deactivated instead. Removed users immediately lose access.
        </div>
      </div>
      <div className="mt-3 flex items-center gap-3 p-3 bg-white border border-ink-200 rounded-lg">
        <Avatar user={user} size={36}/>
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-ink-900 text-[13px] truncate">{user.name}</div>
          <div className="text-[11.5px] text-ink-500 truncate font-mono">{user.email}</div>
        </div>
        <RolePill role={user.role} tier={user.tier} size="sm"/>
      </div>
    </Modal>
  );
}

Object.assign(window, { AdminDashboard, RolePill });
