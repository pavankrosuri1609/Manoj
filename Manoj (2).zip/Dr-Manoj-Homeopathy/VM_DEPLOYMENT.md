# VM Deployment Guide — Dr. Manoj's Homeopathy Care Content Platform

**No Docker required.** This guide installs the platform directly on a single Linux VM
(Ubuntu 22.04 LTS assumed; notes for RHEL/CentOS included). Follow the steps in order.
Total time for a first deploy: ~45–60 minutes.

At the end you will have:
- MySQL 8 holding all data
- The Node/Express API running as a `systemd` service (auto-restart, starts on boot)
- The React frontend served by nginx over HTTPS
- The API and frontend on the same domain, so no CORS juggling

```
                 ┌────────── your VM ──────────┐
   Internet ──▶  │  nginx :443 (TLS)           │
                 │   ├── / ............ frontend static files
                 │   └── /api ......... proxy → Node :4000
                 │  Node/Express (systemd)     │
                 │  MySQL 8 (systemd)          │
                 └── S3 bucket (AWS, external) ┘
```

---

## Prerequisites

- A Linux VM with a public IP (2 vCPU / 4 GB RAM minimum; 4 vCPU / 8 GB recommended)
- A domain name pointed at the VM's IP (e.g. `app.drmanojhomeopathy.com`)
- SSH access with `sudo`
- An **AWS S3** account with two buckets and an IAM user (video storage — see Step 6)
- The project files from the zip, copied to the VM at `/opt/clinicast`

> **Where do the files go?** Copy the unzipped project so you have:
> `/opt/clinicast/frontend` and `/opt/clinicast/backend` on the VM.
> `scp -r ./Manoj/* user@your-vm:/tmp/clinicast` then `sudo mv /tmp/clinicast /opt/clinicast`.

---

## Step 1 — Update the VM & install base tools

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl git ufw
```

RHEL/CentOS: `sudo dnf update -y && sudo dnf install -y curl git`

---

## Step 2 — Install Node.js 20

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt install -y nodejs
node -v      # expect v20.x
```

RHEL/CentOS: `curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -` then `sudo dnf install -y nodejs`

---

## Step 3 — Install & secure MySQL 8

```bash
sudo apt install -y mysql-server
sudo systemctl enable --now mysql
sudo mysql_secure_installation      # set a root password, answer Y to the rest
```

RHEL/CentOS: `sudo dnf install -y mysql-server && sudo systemctl enable --now mysqld`

---

## Step 4 — Create the database, schema & API user

```bash
# Load the schema (creates the `clinicast` database and all tables)
sudo mysql < /opt/clinicast/backend/schema.sql

# Create a least-privilege API user (NOT root) and lock down the audit table
sudo mysql <<'SQL'
CREATE USER IF NOT EXISTS 'clinicast_api'@'localhost' IDENTIFIED BY 'CHANGE_ME_STRONG_PASSWORD';
GRANT SELECT, INSERT, UPDATE, DELETE ON clinicast.* TO 'clinicast_api'@'localhost';
-- audit_log is append-only: the API may INSERT and SELECT, never UPDATE/DELETE
REVOKE UPDATE, DELETE ON clinicast.audit_log FROM 'clinicast_api'@'localhost';
FLUSH PRIVILEGES;
SQL
```

Replace `CHANGE_ME_STRONG_PASSWORD` with a strong password — you'll put it in the API config next.

Verify:
```bash
sudo mysql -e "SELECT COUNT(*) AS users FROM clinicast.users;"   # expect 11
```

---

## Step 5 — Generate secrets

The API refuses to start in production without strong secrets (this is a security feature).
Generate two distinct 64-byte secrets and keep them handy for Step 7:

```bash
echo "JWT_SECRET=$(openssl rand -hex 64)"
echo "AUDIT_HMAC_KEY=$(openssl rand -hex 64)"
```

---

## Step 6 — Set up AWS S3 (video storage)

1. In the AWS console create **two buckets**, e.g. `drmanoj-raw-prod` and `drmanoj-edit-prod`, in your region (e.g. `ap-south-1`).
2. Create an **IAM user** (programmatic access) with this policy (replace bucket names):
   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       { "Effect": "Allow", "Action": ["s3:PutObject","s3:GetObject"],
         "Resource": ["arn:aws:s3:::drmanoj-raw-prod/*","arn:aws:s3:::drmanoj-edit-prod/*"] },
       { "Effect": "Allow", "Action": ["s3:ListBucket"],
         "Resource": ["arn:aws:s3:::drmanoj-raw-prod","arn:aws:s3:::drmanoj-edit-prod"] }
     ]
   }
   ```
3. On **each bucket** → Permissions → CORS, add (replace the domain with yours):
   ```json
   [
     { "AllowedOrigins": ["https://app.drmanojhomeopathy.com"],
       "AllowedMethods": ["PUT","GET"], "AllowedHeaders": ["*"],
       "ExposeHeaders": ["ETag"], "MaxAgeSeconds": 3000 }
   ]
   ```
   This is required — the browser uploads directly to S3, so S3 must allow your site's origin.
4. Save the IAM user's **Access key** and **Secret key** for Step 7.

> ⚠️ For real AWS S3: leave `S3_ENDPOINT` empty and `S3_FORCE_PATH_STYLE=false`.
> Setting either wrong is the #1 cause of "upload returns 403".

---

## Step 7 — Configure the API

```bash
cd /opt/clinicast/backend/api
cp .env.example .env
sudo nano .env      # or vim
```

Fill in (using your values from Steps 4–6):

```ini
# DB
DB_HOST=localhost
DB_PORT=3306
DB_USER=clinicast_api
DB_PASSWORD=CHANGE_ME_STRONG_PASSWORD
DB_NAME=clinicast

# Auth — paste the secrets from Step 5
JWT_SECRET=<paste 64-byte hex>
AUDIT_HMAC_KEY=<paste a DIFFERENT 64-byte hex>
JWT_ACCESS_TTL=900
JWT_REFRESH_TTL=2592000

# Login brute-force protection
LOGIN_LOCK_THRESHOLD=5
LOGIN_LOCK_MINUTES=15

# S3 (real AWS)
S3_ENDPOINT=
S3_REGION=ap-south-1
S3_BUCKET_RAW=drmanoj-raw-prod
S3_BUCKET_EDIT=drmanoj-edit-prod
S3_ACCESS_KEY=<IAM access key>
S3_SECRET_KEY=<IAM secret key>
S3_FORCE_PATH_STYLE=false

# HTTP — same-origin deploy, so the frontend calls /api directly
PORT=4000
CORS_ORIGIN=https://app.drmanojhomeopathy.com
NODE_ENV=production
```

Install dependencies and seed the demo users' passwords:

```bash
npm install --omit=dev
npm run seed        # sets every seeded user's password to: demo1234
```

> **Change demo passwords before real use.** `demo1234` is for first login only.

---

## Step 8 — Verify the backend before wiring the web server

```bash
node src/server.js
```

Watch the startup log. You want to see:
```
[security] ✓ secret + CORS configuration validated.
Clinicast API listening on :4000 (env=production)
[storage] ✓ S3 reachable — AWS S3 region ap-south-1 ...; buckets OK
```
If you see a `✗` line, it tells you exactly what's wrong (bad secret, wrong S3 region, missing bucket, etc.). Fix `.env` and retry. Press `Ctrl+C` when it's green.

Run the full end-to-end smoke test (proves login, upload to S3, the 2-stage approval workflow, publishing, RBAC, session revocation, and account lockout all work against your real DB + S3):

```bash
# One IP makes many logins during the test, so raise the login rate limit for the run:
LOGIN_RATE_LIMIT=1000 node src/server.js &     # start API in background
sleep 3
npm run smoke                                   # expect: all checks passed
kill %1                                         # stop the background API
```

**A green smoke run is your go-live proof.** If it passes, the platform genuinely works on your infrastructure.

---

## Step 9 — Run the API as a systemd service

Create a dedicated user and the service unit:

```bash
sudo useradd -r -s /usr/sbin/nologin clinicast || true
sudo chown -R clinicast:clinicast /opt/clinicast
sudo mkdir -p /var/log/clinicast && sudo chown clinicast:clinicast /var/log/clinicast

sudo tee /etc/systemd/system/clinicast-api.service >/dev/null <<'UNIT'
[Unit]
Description=Clinicast API (Dr. Manoj's Homeopathy)
After=network.target mysql.service
Wants=mysql.service

[Service]
Type=simple
User=clinicast
WorkingDirectory=/opt/clinicast/backend/api
EnvironmentFile=/opt/clinicast/backend/api/.env
ExecStart=/usr/bin/node src/server.js
Restart=always
RestartSec=5
TimeoutStopSec=20
StandardOutput=append:/var/log/clinicast/api.log
StandardError=append:/var/log/clinicast/api.err.log

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable --now clinicast-api
sudo systemctl status clinicast-api      # should be active (running)
curl -s http://localhost:4000/health     # {"status":"ok","db":"ok","s3":"ok"}
```

The service now auto-restarts on crash, starts on boot, and drains cleanly on stop
(graceful shutdown is built in — `TimeoutStopSec=20` gives it room to finish in-flight requests).

---

## Step 10 — Point the frontend at the API

```bash
sudo nano /opt/clinicast/frontend/config.js
```

Set the single line to same-origin:

```javascript
window.CLINICAST_CONFIG = { API_BASE_URL: "/api" };
```

That's the entire go-live switch. With `/api`, the app authenticates against your MySQL
users table (real JWT) and reads/writes MySQL + S3. (Left empty, it runs the offline preview.)

---

## Step 11 — Serve the frontend with nginx + HTTPS

```bash
sudo apt install -y nginx certbot python3-certbot-nginx

sudo tee /etc/nginx/sites-available/clinicast >/dev/null <<'NGINX'
server {
    listen 80;
    server_name app.drmanojhomeopathy.com;

    root /opt/clinicast/frontend;
    index index.html;

    # Serve the SPA
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Proxy API calls to the Node service
    location /api/ {
        proxy_pass http://127.0.0.1:4000/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        client_max_body_size 5m;   # API bodies are small; video goes direct to S3
    }
}
NGINX

sudo ln -sf /etc/nginx/sites-available/clinicast /etc/nginx/sites-enabled/clinicast
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Get a free TLS certificate (auto-configures HTTPS + renewal)
sudo certbot --nginx -d app.drmanojhomeopathy.com
```

---

## Step 12 — Firewall & final check

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw --force enable
```

Open **https://app.drmanojhomeopathy.com** in a browser. You should see the sign-in screen.
Log in with a seeded account:

| Role | Email | Password |
|---|---|---|
| Administrator | `sarah.mitchell@drmanojhomeopathy.com` | `demo1234` |
| Doctor (founder) | `dr.manoj@drmanojhomeopathy.com` | `demo1234` |

**Change these passwords immediately** via the admin screen / a DB update for real use.

---

## Day-2 operations

```bash
# Logs
sudo tail -f /var/log/clinicast/api.log
sudo journalctl -u clinicast-api -f

# Restart / stop (graceful)
sudo systemctl restart clinicast-api
sudo systemctl stop clinicast-api

# Health
curl -s http://localhost:4000/health | jq

# Nightly DB backup (add to crontab)
mysqldump --single-transaction clinicast | gzip > /var/backups/clinicast-$(date +\%F).sql.gz

# Verify the audit chain is intact (tamper check)
cd /opt/clinicast/backend/api
node -e "import('./src/audit.js').then(m=>m.verifyAuditChain().then(r=>{console.log(r);process.exit()}))"

# Unlock an account locked by failed logins
sudo mysql -e "UPDATE clinicast.users SET failed_login_attempts=0, locked_until=NULL WHERE email='someone@drmanojhomeopathy.com';"

# Reset a user's password (until the admin reset UI ships)
cd /opt/clinicast/backend/api
node -e "import('./src/auth.js').then(async m=>{const h=await m.hashPassword('NewPass123');const {q}=await import('./src/db.js');await q('UPDATE users SET password_hash=?,failed_login_attempts=0,locked_until=NULL WHERE email=?',[h,'someone@drmanojhomeopathy.com']);console.log('done');process.exit()})"
```

---

## Updating to a new build

```bash
sudo systemctl stop clinicast-api
# copy new files over /opt/clinicast (keep your .env and config.js)
cd /opt/clinicast/backend/api && npm install --omit=dev
# if the schema changed, review & apply the migration, then:
sudo systemctl start clinicast-api
sudo systemctl reload nginx
```

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| API won't start, log says `[security] ✗ JWT_SECRET ...` | Set real 64-byte secrets in `.env` (Step 5). This is intentional — it won't run insecure. |
| `[storage] ✗ ... PermanentRedirect / 301` | Wrong `S3_REGION` for the bucket. |
| `[storage] ✗ ... 403` | IAM user lacks permissions, or wrong keys. |
| Upload starts then fails in the browser | Bucket **CORS** missing your domain (Step 6.3). |
| Login always fails | Did you run `npm run seed`? Password is `demo1234`. |
| `/health` shows `"db"` error | MySQL down or wrong `DB_PASSWORD` in `.env`. |
| Account "locked" message | 5 failed logins — unlock via the SQL in Day-2 ops, or wait 15 min. |
| Page loads but stuck on preview/demo | `config.js` `API_BASE_URL` is empty — set it to `"/api"` (Step 10). |

---

## Security checklist before real patient content

- [ ] Strong `JWT_SECRET` **and** distinct `AUDIT_HMAC_KEY` (Step 5) — never the defaults
- [ ] All demo passwords changed
- [ ] TLS active (Step 11) and HTTP→HTTPS redirect on
- [ ] `CORS_ORIGIN` = your exact domain (not `*`)
- [ ] MySQL bound to `localhost` only (default) — not exposed publicly
- [ ] Nightly `mysqldump` backups running and tested-restore verified
- [ ] S3 buckets: block public access ON, server-side encryption ON
- [ ] Firewall enabled (Step 12)
- [ ] Green `npm run smoke` run recorded (Step 8)
- [ ] (Healthcare) HIPAA BAA signed with AWS before storing real patient-identifiable content

You're live. 🎉
