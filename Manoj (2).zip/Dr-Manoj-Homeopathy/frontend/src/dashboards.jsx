// ============================================================================
// Role-based dashboards + shared list views.
// ============================================================================

function Dashboard() {
  const { currentUser } = useApp();
  const Comp = {
    ADMIN: AdminDashboard,
    DOCTOR: DoctorDashboard,
    EDITOR: EditorDashboard,
    WRITER: WriterDashboard,
    APPROVER: ApproverDashboard,
    SOCIAL: SocialDashboard,
  }[currentUser.role] || DoctorDashboard;
  return <Comp/>;
}

function PageHeader({ eyebrow, title, subtitle, actions }) {
  return (
    <div className="flex items-start justify-between gap-4 flex-wrap mb-6">
      <div>
        {eyebrow && <div className="text-[11px] uppercase tracking-widest font-bold text-brand-600 mb-1.5">{eyebrow}</div>}
        <h1 className="text-[28px] font-extrabold tracking-tight text-ink-900 leading-tight">{title}</h1>
        {subtitle && <p className="text-ink-500 mt-1.5 max-w-2xl text-[14px]">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2 flex-shrink-0">{actions}</div>}
    </div>
  );
}

function StatTile({ icon, label, value, hint, tone='ink' }) {
  const tones = {
    ink:'bg-ink-100 text-ink-600',
    brand:'bg-brand-50 text-brand-600',
    blue:'bg-blue-50 text-blue-600',
    violet:'bg-violet-50 text-violet-600',
    amber:'bg-amber-50 text-amber-600',
    rose:'bg-rose-50 text-rose-600',
    indigo:'bg-indigo-50 text-indigo-600',
  };
  return (
    <Card padding="p-4">
      <div className="flex items-center justify-between mb-3">
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${tones[tone]}`}>
          <Icon name={icon} size={16}/>
        </div>
        {hint && <span className="text-[11px] text-ink-400 font-medium">{hint}</span>}
      </div>
      <div className="text-[26px] font-extrabold tracking-tight text-ink-900 leading-none">{value}</div>
      <div className="text-[12px] text-ink-500 mt-1.5 font-medium">{label}</div>
    </Card>
  );
}

// ----------------------------------------------------------------------------
// Doctor dashboard
// ----------------------------------------------------------------------------
function DoctorDashboard() {
  const { currentUser, videos, navigate } = useApp();
  const [uploadOpen, setUploadOpen] = React.useState(false);
  const mine = videos.filter(v => v.uploader === currentUser.id);
  const byStatus = (s) => mine.filter(v => v.status === s).length;

  const inFlight = mine.filter(v => !['PUBLISHED','UPLOADED'].includes(v.status)).slice(0,4);
  const recent = mine.slice().sort((a,b) => new Date(b.updatedAt) - new Date(a.updatedAt)).slice(0,6);

  return (
    <div className="p-6 lg:p-10 max-w-[1280px] mx-auto">
      <PageHeader
        eyebrow="Doctor"
        title={`Welcome back, ${currentUser.name.split(' ').slice(-1)[0]}.`}
        subtitle="Upload your latest recordings and track them through the editorial pipeline. You'll be notified at every handoff."
        actions={<Button tone="brand" icon="upload" onClick={() => setUploadOpen(true)}>Upload video</Button>}
      />

      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3 mb-8">
        <StatTile icon="film" label="Total uploads" value={mine.length} tone="ink"/>
        <StatTile icon="scissors" label="In editing" value={byStatus('EDITING')} tone="blue"/>
        <StatTile icon="pen-tool" label="Writing" value={byStatus('WRITING')} tone="violet"/>
        <StatTile icon="user-check" label="Peer review" value={byStatus('PEER_REVIEW')} tone="amber"/>
        <StatTile icon="shield-check" label="Final approval" value={byStatus('FINAL_REVIEW')} tone="amber"/>
        <StatTile icon="send" label="Published" value={byStatus('PUBLISHED')} tone="indigo"/>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SectionHeader title="In flight" hint="Videos currently moving through the workflow" action={mine.length > 4 && <Button tone="ghost" size="sm" iconRight="arrow-right" onClick={() => navigate({ name:'my'})}>View all</Button>}/>
          <div className="grid sm:grid-cols-2 gap-3">
            {inFlight.length === 0 && (
              <Card className="sm:col-span-2"><EmptyState icon="upload-cloud" title="Nothing in the pipeline" body="Upload your first recording to kick off the workflow." action={<Button tone="brand" icon="upload" onClick={() => setUploadOpen(true)}>Upload video</Button>}/></Card>
            )}
            {inFlight.map(v => <VideoCard key={v.id} video={v} onClick={() => navigate({ name:'detail', videoId: v.id })} dense/>)}
          </div>
        </div>

        <div>
          <SectionHeader title="Recent activity"/>
          <Card padding="p-0">
            <ActivityFeed userId={currentUser.id} limit={6}/>
          </Card>
        </div>
      </div>

      <div className="mt-10">
        <SectionHeader title="All your videos" hint={`${mine.length} total`}/>
        <VideoTable videos={mine}/>
      </div>

      <UploadModal open={uploadOpen} onClose={() => setUploadOpen(false)}/>
    </div>
  );
}

// ----------------------------------------------------------------------------
// Editor dashboard
// ----------------------------------------------------------------------------
function EditorDashboard() {
  const { currentUser, videos, navigate, completeEditing, userById, toast } = useApp();
  const assigned = videos.filter(v => v.editor === currentUser.id && v.status === 'EDITING');
  const completed = videos.filter(v => v.editor === currentUser.id && v.status !== 'EDITING').slice(0,5);
  const [uploadFor, setUploadFor] = React.useState(null);

  return (
    <div className="p-6 lg:p-10 max-w-[1280px] mx-auto">
      <PageHeader
        eyebrow="Editor queue"
        title={`${assigned.length} ${assigned.length === 1 ? 'video' : 'videos'} need your edit`}
        subtitle="Trim, color-grade, and finalize. When you mark a video as edited, it moves to the Content Writer for captions."
      />

      <div className="grid sm:grid-cols-4 gap-3 mb-8">
        <StatTile icon="inbox" label="In your queue" value={assigned.length} tone="blue"/>
        <StatTile icon="check-circle-2" label="Completed this week" value={completed.length} tone="brand"/>
        <StatTile icon="timer" label="Avg. turnaround" value="4.2h" hint="last 7d" tone="ink"/>
        <StatTile icon="trophy" label="On-time rate" value="98%" hint="rolling 30d" tone="indigo"/>
      </div>

      <SectionHeader title="Assigned to you" hint="Click any video to open the detail view"/>
      {assigned.length === 0 ? (
        <Card><EmptyState icon="check-circle-2" title="Inbox zero" body="No edits waiting. Nice work."/></Card>
      ) : (
        <div className="grid lg:grid-cols-2 gap-3">
          {assigned.map(v => {
            const up = userById(v.uploader);
            const raw = (v.versions || []).find(x => x.kind === 'raw');
            return (
            <Card key={v.id} padding="p-4">
              <div className="flex gap-3">
                <Thumbnail video={v} className="w-36 flex-shrink-0"/>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-ink-900 text-[14px] leading-snug">{v.title}</h4>
                  <p className="text-[12px] text-ink-500 mt-1 line-clamp-2">{v.description}</p>
                  <div className="flex items-center gap-3 text-[11.5px] text-ink-500 mt-2">
                    <Avatar user={up} size={18}/>
                    <span className="font-medium text-ink-700">{up?.name}</span>
                    <span>·</span>
                    <span>Uploaded {timeAgo(v.createdAt)}</span>
                  </div>
                  {raw && (
                    <div className="mt-2.5 flex items-center gap-2 text-[11.5px] bg-ink-50 border border-ink-200 rounded-lg px-2.5 py-1.5">
                      <Icon name="file-video" size={13} className="text-ink-500"/>
                      <span className="font-mono text-ink-700 truncate flex-1">{raw.fileName}</span>
                      <span className="text-ink-400 font-mono">{raw.sizeMB.toFixed(1)} MB</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-3 pt-3 border-t border-ink-100">
                <VersionHistory video={v} onUploadNew={() => setUploadFor(v)}/>
              </div>

              <div className="flex flex-wrap gap-2 mt-3">
                <Button size="sm" tone="secondary" icon="download" onClick={() => toast({ tone:'info', title:'Download started', message:`Fetching ${raw?.fileName || 'original'}…` })}>Download original</Button>
                <Button size="sm" tone="ghost" icon="external-link" onClick={() => navigate({ name:'detail', videoId: v.id })}>Detail</Button>
                <Button size="sm" tone="brand" icon="upload-cloud" onClick={() => setUploadFor(v)} className="ml-auto">Upload edited cut</Button>
              </div>
            </Card>
          );})}
        </div>
      )}

      <div className="mt-10">
        <SectionHeader title="Recently completed" hint="Your finished edits — expand any to view its version history"/>
        {completed.length === 0 ? (
          <Card><EmptyState icon="film" title="Nothing yet" body="Edits you've handed off will show here."/></Card>
        ) : (
          <div className="space-y-3">
            {completed.map(v => (
              <Card key={v.id} padding="p-4">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <Thumbnail video={v} className="w-24 flex-shrink-0" overlay={false}/>
                    <div className="min-w-0">
                      <div className="font-semibold text-ink-900 text-[13.5px] truncate">{v.title}</div>
                      <div className="mt-1"><StatusBadge status={v.status} size="sm"/></div>
                    </div>
                  </div>
                  <Button size="sm" tone="ghost" icon="external-link" onClick={() => navigate({ name:'detail', videoId: v.id })}>Detail</Button>
                </div>
                <div className="pt-3 border-t border-ink-100">
                  <VersionHistory video={v} onUploadNew={() => setUploadFor(v)} compact/>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      <EditUploadModal open={!!uploadFor} video={uploadFor} mode={uploadFor && (uploadFor.versions||[]).some(x=>x.kind==='edit') ? 'revision' : 'handoff'} onClose={() => setUploadFor(null)}/>
    </div>
  );
}

// ----------------------------------------------------------------------------
// Writer dashboard
// ----------------------------------------------------------------------------
function WriterDashboard() {
  const { currentUser, videos, navigate } = useApp();
  const assigned = videos.filter(v => v.writer === currentUser.id && v.status === 'WRITING');
  const inReview = videos.filter(v => v.writer === currentUser.id && ['PEER_REVIEW','FINAL_REVIEW'].includes(v.status));

  const [activeId, setActiveId] = React.useState(assigned[0]?.id);
  const active = videos.find(v => v.id === activeId);

  return (
    <div className="p-6 lg:p-10 max-w-[1280px] mx-auto">
      <PageHeader
        eyebrow="Writer studio"
        title={`Write captions for ${assigned.length} ${assigned.length === 1 ? 'video' : 'videos'}`}
        subtitle="Add platform-tailored captions and hashtags. Submit for medical review when ready."
      />

      <div className="grid sm:grid-cols-4 gap-3 mb-8">
        <StatTile icon="pen-tool" label="In your queue" value={assigned.length} tone="violet"/>
        <StatTile icon="eye" label="Awaiting review" value={inReview.length} tone="amber"/>
        <StatTile icon="check-circle-2" label="Approved (mo)" value={videos.filter(v=>v.writer===currentUser.id && v.status==='APPROVED').length} tone="brand"/>
        <StatTile icon="send" label="Published (mo)" value={videos.filter(v=>v.writer===currentUser.id && v.status==='PUBLISHED').length} tone="indigo"/>
      </div>

      {assigned.length === 0 ? (
        <Card><EmptyState icon="check-circle-2" title="Nothing in your queue" body="Editor handoffs will appear here."/></Card>
      ) : (
        <div className="grid lg:grid-cols-[320px_1fr] gap-6">
          <div>
            <SectionHeader title="Your assignments"/>
            <div className="space-y-2">
              {assigned.map(v => (
                <button key={v.id} onClick={() => setActiveId(v.id)}
                  className={`w-full text-left p-3 rounded-xl border transition ${activeId===v.id?'border-brand-500 bg-brand-50/40 shadow-card':'border-ink-200 bg-white hover:border-ink-300'}`}>
                  <div className="flex gap-2.5">
                    <Thumbnail video={v} className="w-20 flex-shrink-0" overlay={false}/>
                    <div className="flex-1 min-w-0">
                      <div className="text-[12.5px] font-semibold text-ink-900 line-clamp-2 leading-snug">{v.title}</div>
                      <div className="text-[11px] text-ink-500 mt-1">{timeAgo(v.updatedAt)}</div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
          {active && <WritingPanel video={active}/>}
        </div>
      )}

      <div className="mt-10">
        <SectionHeader title="Awaiting review" hint="What you've submitted that's pending medical approval"/>
        <VideoTable videos={inReview}/>
      </div>
    </div>
  );
}

const PLATFORMS = ['Instagram', 'YouTube', 'Twitter', 'TikTok', 'LinkedIn'];

function WritingPanel({ video }) {
  const { submitForReview, dispatch, navigate, toast } = useApp();
  const [description, setDescription] = React.useState(video.description || '');
  const [captions, setCaptions] = React.useState(video.captions || '');
  const [hashInput, setHashInput] = React.useState('');
  const [hashtags, setHashtags] = React.useState(video.hashtags || []);
  const [platforms, setPlatforms] = React.useState(video.platforms || []);

  React.useEffect(() => {
    setDescription(video.description || '');
    setCaptions(video.captions || '');
    setHashtags(video.hashtags || []);
    setPlatforms(video.platforms || []);
  }, [video.id]);

  const addHash = () => {
    const v = hashInput.trim().replace(/^#?/, '#');
    if (v && v.length > 1 && !hashtags.includes(v)) setHashtags([...hashtags, v]);
    setHashInput('');
  };

  const submit = () => {
    if (!captions.trim()) return;
    submitForReview(video, { description, captions, hashtags, platforms });
  };

  const togglePlatform = (p) => setPlatforms(platforms.includes(p) ? platforms.filter(x=>x!==p) : [...platforms, p]);

  return (
    <Card padding="p-5">
      <div className="flex items-start gap-3 mb-4">
        <Thumbnail video={video} className="w-28 flex-shrink-0"/>
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-ink-900 leading-snug">{video.title}</h3>
          <p className="text-[12px] text-ink-500 mt-1 line-clamp-2">{video.description}</p>
          <div className="mt-2"><Button size="sm" tone="ghost" icon="external-link" onClick={() => navigate({ name:'detail', videoId: video.id })}>Open full view</Button></div>
        </div>
      </div>

      <div className="space-y-4">
        <Field label="Description" hint="A short summary of the video. This carries through to review and publishing.">
          <Textarea value={description} onChange={e => setDescription(e.target.value)} rows={2} placeholder="Summarize what this video covers…"/>
        </Field>

        <Field label="Captions" required hint="Hook within the first 7 words. Tailor tone per platform.">
          <Textarea value={captions} onChange={e => setCaptions(e.target.value)} rows={4} placeholder="Write a caption that opens with a strong hook…"/>
          <div className="text-[11px] text-ink-400 mt-1 text-right">{captions.length} chars</div>
        </Field>

        <Field label="Hashtags" hint="Press Enter to add — keep to 3–5 high-relevance tags.">
          <div className="flex gap-2">
            <Input value={hashInput} onChange={e => setHashInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addHash(); } }}
              placeholder="HeartHealth, Cardiology…"/>
            <Button size="md" tone="secondary" icon="plus" onClick={addHash}>Add</Button>
          </div>
          {hashtags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-2.5">
              {hashtags.map(h => <Pill key={h} tone="brand" removable onRemove={() => setHashtags(hashtags.filter(x => x !== h))}>{h}</Pill>)}
            </div>
          )}
        </Field>

        <Field label="Target platforms" required hint="The Social Media team will publish to whatever you check.">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {PLATFORMS.map(p => (
              <button key={p} type="button" onClick={() => togglePlatform(p)}
                className={`flex items-center gap-2 p-2.5 rounded-lg border-2 transition ${platforms.includes(p)?'border-brand-500 bg-brand-50/50':'border-ink-200 hover:border-ink-300'}`}>
                <PlatformIcon name={p}/>
                <span className="text-[13px] font-semibold text-ink-800">{p}</span>
              </button>
            ))}
          </div>
        </Field>
      </div>

      <div className="flex gap-2 mt-5 pt-5 border-t border-ink-100">
        <Button size="md" tone="secondary" icon="save" onClick={() => { dispatch({ type:'UPDATE_VIDEO', id: video.id, patch:{ description, captions, hashtags, platforms } }); toast({ title:'Draft saved', message:'Caption draft saved locally.', tone:'info' }); }}>Save draft</Button>
        <Button size="md" tone="brand" icon="send" disabled={!captions.trim() || platforms.length === 0} onClick={submit}>Submit for review</Button>
      </div>
    </Card>
  );
}

function PlatformIcon({ name }) {
  const map = { Instagram:'instagram', YouTube:'youtube', Twitter:'twitter', TikTok:'music', LinkedIn:'linkedin' };
  return <Icon name={map[name] || 'send'} size={14} className="text-ink-600"/>;
}

// ----------------------------------------------------------------------------
// Approver dashboard — single component, branches on tier.
// ----------------------------------------------------------------------------
function ApproverDashboard() {
  const { videos, navigate, peerApprove, finalApprove, userById, currentUser } = useApp();
  const tier = currentUser.tier || 'peer';
  const tierCfg = APPROVER_TIERS[tier];
  const myQueueStatus = tierCfg.status;             // PEER_REVIEW or FINAL_REVIEW
  const queue = videos.filter(v => v.status === myQueueStatus && (
    tier === 'peer' ? v.peerApprover === currentUser.id : v.finalApprover === currentUser.id
  ));
  const otherStageStatus = tier === 'peer' ? 'FINAL_REVIEW' : 'PEER_REVIEW';
  const inOtherStage = videos.filter(v => v.status === otherStageStatus).length;

  const [rejectFor, setRejectFor] = React.useState(null);

  const onApprove = (v) => tier === 'peer' ? peerApprove(v) : finalApprove(v);
  const approvedKeyForTier = tier === 'peer' ? 'PEER_APPROVED' : 'FINAL_APPROVED';

  return (
    <div className="p-6 lg:p-10 max-w-[1280px] mx-auto">
      <PageHeader
        eyebrow={`${tierCfg.short} · ${tierCfg.label}`}
        title={`${queue.length} ${queue.length === 1 ? 'video' : 'videos'} awaiting your sign-off`}
        subtitle={tier === 'peer'
          ? "Stage 1 — verify clinical accuracy and source quality. Pass to final approval, or send back with specific notes."
          : "Stage 2 — final compliance and brand sign-off. Once you approve, the video is released to the social team."}
      />

      <TierStrip currentTier={tier}/>

      <div className="grid sm:grid-cols-4 gap-3 mb-8 mt-6">
        <StatTile icon={tierCfg.icon} label={`Pending ${tierCfg.short}`} value={queue.length} tone="amber"/>
        <StatTile icon="check-circle-2" label="Approved (mo)" value={videos.filter(v => (v.history||[]).some(h => h.action === approvedKeyForTier && h.actor === currentUser.name)).length} tone="brand"/>
        <StatTile icon="arrow-right-left" label={`In ${tier === 'peer' ? 'final' : 'peer'} stage`} value={inOtherStage} tone="ink"/>
        <StatTile icon="timer" label="Avg. cycle" value={tier === 'peer' ? '2.1h' : '4.4h'} hint="last 7d" tone="indigo"/>
      </div>

      <SectionHeader title="Review queue" hint="Oldest first — keep cycle time tight"/>
      {queue.length === 0 ? (
        <Card><EmptyState icon="check-circle-2" title="Queue is empty" body="Nothing at your stage right now."/></Card>
      ) : (
        <div className="space-y-3">
          {queue.map(v => (
            <ApproverQueueCard
              key={v.id}
              video={v}
              tier={tier}
              onApprove={() => onApprove(v)}
              onReject={() => setRejectFor(v)}
              onOpen={() => navigate({ name:'detail', videoId: v.id })}
              userById={userById}
            />
          ))}
        </div>
      )}

      <SendBackModal open={!!rejectFor} video={rejectFor} fromStage={tier} onClose={() => setRejectFor(null)}/>
    </div>
  );
}

function TierStrip({ currentTier }) {
  // Two-step indicator for the approver's stage
  const steps = [
    { tier: 'peer',  label: 'Peer Review',    sub: 'Stage 1 · Clinical accuracy' },
    { tier: 'final', label: 'Final Approval', sub: 'Stage 2 · Compliance sign-off' },
  ];
  return (
    <div className="bg-white border border-ink-200 rounded-xl p-3">
      <div className="flex items-center gap-2">
        {steps.map((s, i) => {
          const active = s.tier === currentTier;
          return (
            <React.Fragment key={s.tier}>
              <div className={`flex-1 flex items-center gap-3 p-2 rounded-lg ${active?'bg-amber-50':''}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-[12px] ${active?'bg-amber-500 text-white':'bg-ink-100 text-ink-500'}`}>{i+1}</div>
                <div className="min-w-0">
                  <div className={`text-[13px] font-bold ${active?'text-amber-900':'text-ink-700'}`}>{s.label}</div>
                  <div className="text-[11px] text-ink-500 truncate">{s.sub}</div>
                </div>
              </div>
              {i === 0 && <Icon name="chevron-right" size={16} className="text-ink-300 flex-shrink-0"/>}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

function ApproverQueueCard({ video, tier, onApprove, onReject, onOpen, userById }) {
  const writer = userById(video.writer);
  const peerApprover = userById(video.peerApprover);
  return (
    <Card padding="p-4" className="anim-slide-up">
      <div className="flex gap-4 flex-col lg:flex-row">
        <Thumbnail video={video} className="w-full lg:w-48 flex-shrink-0"/>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h4 className="font-bold text-ink-900 text-[15px] leading-snug">{video.title}</h4>
              <p className="text-[12px] text-ink-500 mt-1">{video.description}</p>
            </div>
            <StatusBadge status={video.status}/>
          </div>

          {tier === 'final' && peerApprover && (
            <div className="mt-3 flex items-center gap-2 text-[12px] bg-brand-50/60 border border-brand-200 rounded-lg p-2.5">
              <Icon name="check-circle-2" size={14} className="text-brand-600"/>
              <span>Cleared Stage 1 by <span className="font-semibold text-ink-900">{peerApprover.name}</span></span>
            </div>
          )}

          <div className="mt-3 grid sm:grid-cols-2 gap-4">
            <div>
              <div className="text-[10.5px] uppercase tracking-widest font-bold text-ink-400 mb-1">Caption draft</div>
              <p className="text-[12.5px] text-ink-800 bg-ink-50 rounded-lg p-2.5 leading-relaxed">{video.captions || <span className="text-ink-400">No caption submitted</span>}</p>
            </div>
            <div>
              <div className="text-[10.5px] uppercase tracking-widest font-bold text-ink-400 mb-1">Hashtags & platforms</div>
              <div className="flex flex-wrap gap-1.5">{(video.hashtags||[]).map(h => <Pill key={h} tone="brand">{h}</Pill>)}</div>
              <div className="flex flex-wrap gap-1.5 mt-2">{(video.platforms||[]).map(p => <Pill key={p} tone="ink" icon="send">{p}</Pill>)}</div>
            </div>
          </div>
          <div className="flex items-center justify-between mt-4 pt-3 border-t border-ink-100 flex-wrap gap-3">
            <div className="flex items-center gap-2 text-[12px] text-ink-500">
              {writer && <Avatar user={writer} size={20}/>}
              <span>Written by <span className="font-semibold text-ink-700">{writer?.name || 'Unknown'}</span></span>
              <span>·</span>
              <span>Submitted {timeAgo(video.updatedAt)}</span>
            </div>
            <div className="flex gap-2">
              <Button size="sm" tone="ghost" icon="external-link" onClick={onOpen}>Detail</Button>
              <Button size="sm" tone="secondary" icon="corner-up-left" onClick={onReject}>Send back…</Button>
              <Button size="sm" tone="brand" icon="check" onClick={onApprove}>
                {tier === 'peer' ? 'Approve · pass to Stage 2' : 'Final approve · release'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}

// SendBackModal — picks a specific assignee + comment.
function SendBackModal({ open, onClose, video, fromStage }) {
  const { sendBack, userById, users } = useApp();
  const [toUserId, setToUserId] = React.useState(null);
  const [reason, setReason] = React.useState('');

  // Build target options. Suggested current assignees come first, with their roles shown.
  const targets = React.useMemo(() => {
    if (!video) return [];
    const list = [];
    const editor = userById(video.editor);
    const writer = userById(video.writer);
    const peer = userById(video.peerApprover);
    if (writer) list.push({ id: writer.id, label: writer.name, sub: 'Content Writer · captions/hashtags', icon: 'pen-tool', preferred: true });
    if (editor) list.push({ id: editor.id, label: editor.name, sub: 'Video Editor · re-cut footage', icon: 'film', preferred: true });
    if (fromStage === 'final' && peer) list.push({ id: peer.id, label: peer.name, sub: 'Peer Reviewer · re-review clinical accuracy', icon: 'user-check', preferred: true });

    // Add alternative writers/editors (in case reviewer wants to reassign).
    (users || []).filter(u => u.active !== false && u.role === 'WRITER' && u.id !== writer?.id).forEach(u => list.push({ id: u.id, label: u.name, sub: 'Content Writer (reassign)', icon: 'pen-tool', preferred: false }));
    (users || []).filter(u => u.active !== false && u.role === 'EDITOR' && u.id !== editor?.id).forEach(u => list.push({ id: u.id, label: u.name, sub: 'Video Editor (reassign)', icon: 'film', preferred: false }));
    return list;
  }, [video, userById, fromStage, users]);

  React.useEffect(() => {
    if (open) {
      setReason('');
      // Sensible default: writer for final-stage, writer for peer-stage (captions are the typical issue).
      const w = video?.writer;
      setToUserId(w || targets[0]?.id || null);
    }
  }, [open, video?.id]);

  if (!video) return null;

  const submit = () => {
    if (!toUserId || !reason.trim()) return;
    sendBack(video, { toUserId, reason, fromStage });
    onClose();
  };

  const selectedUser = userById(toUserId);

  return (
    <Modal open={open} onClose={onClose} title="Send back for changes"
      size="lg"
      footer={<>
        <Button tone="secondary" onClick={onClose}>Cancel</Button>
        <Button tone="warn" icon="corner-up-left" disabled={!toUserId || !reason.trim()} onClick={submit}>
          {selectedUser ? `Send back to ${selectedUser.name.split(' ')[0]}` : 'Send back'}
        </Button>
      </>}>
      <div className="space-y-4">
        <div className="bg-ink-50 rounded-lg p-3 flex items-start gap-3">
          <Thumbnail video={video} className="w-20 flex-shrink-0" overlay={false}/>
          <div className="min-w-0 flex-1">
            <div className="font-semibold text-ink-900 text-[13.5px] leading-snug">{video.title}</div>
            <div className="text-[11.5px] text-ink-500 mt-0.5 flex items-center gap-1.5">
              <span>Currently in {STATUS[video.status].label}</span>
              <span>·</span>
              <span>You are at {APPROVER_TIERS[fromStage].label}</span>
            </div>
          </div>
        </div>

        <Field label="Send back to" required hint="Choose the specific person who should own the next step.">
          <div className="border border-ink-200 rounded-xl divide-y divide-ink-100 max-h-72 overflow-auto scroll-thin">
            {targets.length === 0 && (
              <div className="p-4 text-sm text-ink-400 text-center">No suggested assignees.</div>
            )}
            {targets.map((t, i) => {
              const u = userById(t.id);
              const sectionStart = i === 0 || (targets[i-1].preferred !== t.preferred);
              return (
                <React.Fragment key={t.id + i}>
                  {sectionStart && !t.preferred && (
                    <div className="px-3 py-1.5 bg-ink-50/70 text-[10.5px] font-bold uppercase tracking-widest text-ink-500">Reassign to a different teammate</div>
                  )}
                  <label className={`flex items-center gap-3 p-2.5 cursor-pointer transition ${toUserId === t.id?'bg-brand-50/60':'hover:bg-ink-50'}`}>
                    <input type="radio" name="sendBackTo" checked={toUserId === t.id} onChange={() => setToUserId(t.id)} className="sr-only"/>
                    <Avatar user={u} size={32}/>
                    <div className="flex-1 min-w-0">
                      <div className="text-[13px] font-semibold text-ink-900 truncate">{t.label}</div>
                      <div className="text-[11.5px] text-ink-500 truncate flex items-center gap-1.5">
                        <Icon name={t.icon} size={11}/>
                        <span>{t.sub}</span>
                      </div>
                    </div>
                    <span className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${toUserId === t.id?'border-brand-500':'border-ink-300'}`}>
                      {toUserId === t.id && <span className="w-1.5 h-1.5 bg-brand-500 rounded-full"></span>}
                    </span>
                  </label>
                </React.Fragment>
              );
            })}
          </div>
        </Field>

        <Field label="Reason for changes" required hint="Specific, actionable feedback. The assignee will see this in their notification and in the video's history.">
          <Textarea rows={4} value={reason} onChange={e => setReason(e.target.value)} placeholder={fromStage === 'peer'
            ? "e.g. The 02:14 reference to JAMA needs a more recent citation — 2024 paper preferred."
            : "e.g. The caption mentions a specific brand name — please remove or get sponsorship disclosure."}/>
        </Field>
      </div>
    </Modal>
  );
}

// ----------------------------------------------------------------------------
// Social Media dashboard
// ----------------------------------------------------------------------------
function SocialDashboard() {
  const { videos, navigate, publishVideo, userById } = useApp();
  const queue = videos.filter(v => v.status === 'APPROVED');
  const live = videos.filter(v => v.status === 'PUBLISHED');
  const [publishFor, setPublishFor] = React.useState(null);
  const [pubPlatforms, setPubPlatforms] = React.useState([]);
  const [publishing, setPublishing] = React.useState(false);

  React.useEffect(() => {
    if (publishFor) setPubPlatforms(publishFor.platforms?.length ? publishFor.platforms : ['Instagram','YouTube']);
  }, [publishFor]);

  const togglePub = (p) => setPubPlatforms(pubPlatforms.includes(p) ? pubPlatforms.filter(x=>x!==p) : [...pubPlatforms, p]);

  const doPublish = () => {
    setPublishing(true);
    setTimeout(() => {
      publishVideo(publishFor, pubPlatforms);
      setPublishing(false);
      setPublishFor(null);
    }, 800);
  };

  return (
    <div className="p-6 lg:p-10 max-w-[1280px] mx-auto">
      <PageHeader
        eyebrow="Channel control"
        title={`${queue.length} approved ${queue.length === 1 ? 'video' : 'videos'} ready to publish`}
        subtitle="Schedule or publish immediately to your channels. Captions and hashtags are pre-loaded from the Writer."
      />

      <div className="grid sm:grid-cols-4 gap-3 mb-8">
        <StatTile icon="rocket" label="Ready to publish" value={queue.length} tone="brand"/>
        <StatTile icon="send" label="Live this month" value={live.length} tone="indigo"/>
        <StatTile icon="trending-up" label="Avg. engagement" value="6.8%" hint="vs 3.1% industry" tone="violet"/>
        <StatTile icon="users" label="Total reach (mo)" value="12.4M" tone="ink"/>
      </div>

      <SectionHeader title="Ready for publishing"/>
      {queue.length === 0 ? (
        <Card><EmptyState icon="rocket" title="Queue is clear" body="Once a video is approved, it will appear here for publishing."/></Card>
      ) : (
        <div className="grid lg:grid-cols-2 gap-3">
          {queue.map(v => (
            <Card key={v.id} padding="p-4">
              <div className="flex gap-3">
                <Thumbnail video={v} className="w-32 flex-shrink-0"/>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-ink-900 text-[14px] leading-snug">{v.title}</h4>
                  <p className="text-[12px] text-ink-700 mt-1.5 italic line-clamp-2">"{v.captions}"</p>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {(v.hashtags||[]).slice(0,4).map(h => <Pill key={h} tone="brand">{h}</Pill>)}
                  </div>
                  <div className="flex items-center gap-1.5 mt-2.5">
                    <span className="text-[11px] text-ink-500">Suggested:</span>
                    {(v.platforms||[]).map(p => <Pill key={p} icon={({Instagram:'instagram',YouTube:'youtube',Twitter:'twitter',TikTok:'music',LinkedIn:'linkedin'})[p]||'send'} tone="ink">{p}</Pill>)}
                  </div>
                </div>
              </div>
              <div className="flex justify-end gap-2 mt-3 pt-3 border-t border-ink-100">
                <Button size="sm" tone="ghost" icon="external-link" onClick={() => navigate({ name:'detail', videoId: v.id })}>Detail</Button>
                <Button size="sm" tone="brand" icon="send" onClick={() => setPublishFor(v)}>Publish</Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <div className="mt-10">
        <SectionHeader title="Recently published"/>
        <VideoTable videos={live.slice(0,8)}/>
      </div>

      <Modal open={!!publishFor} onClose={() => !publishing && setPublishFor(null)} title="Publish video"
        footer={<>
          <Button tone="secondary" onClick={() => setPublishFor(null)} disabled={publishing}>Cancel</Button>
          <Button tone="brand" icon="send" onClick={doPublish} disabled={pubPlatforms.length === 0 || publishing}>
            {publishing ? 'Publishing…' : `Publish to ${pubPlatforms.length} channel${pubPlatforms.length!==1?'s':''}`}
          </Button>
        </>}>
        {publishFor && (
          <div className="space-y-4">
            <div className="bg-ink-50 rounded-lg p-3 flex items-start gap-3">
              <Thumbnail video={publishFor} className="w-24 flex-shrink-0"/>
              <div className="min-w-0 flex-1">
                <div className="font-semibold text-ink-900 text-[14px]">{publishFor.title}</div>
                <div className="text-[11.5px] text-ink-500 mt-1">"{publishFor.captions}"</div>
              </div>
            </div>
            <Field label="Channels" required hint="Selected platforms will receive the caption simultaneously.">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {PLATFORMS.map(p => (
                  <button key={p} onClick={() => togglePub(p)} disabled={publishing}
                    className={`flex items-center gap-2 p-3 rounded-lg border-2 transition ${pubPlatforms.includes(p)?'border-brand-500 bg-brand-50/50':'border-ink-200 hover:border-ink-300'}`}>
                    <PlatformIcon name={p}/>
                    <span className="text-[13px] font-semibold flex-1 text-left">{p}</span>
                    {pubPlatforms.includes(p) && <Icon name="check" size={14} className="text-brand-600"/>}
                  </button>
                ))}
              </div>
            </Field>
            {publishing && (
              <div className="bg-brand-50 rounded-lg p-3">
                <div className="flex items-center gap-2 text-[12.5px] text-brand-700 font-semibold mb-2"><Icon name="loader" size={14}/> Publishing to {pubPlatforms.length} channel{pubPlatforms.length!==1?'s':''}…</div>
                <ProgressBar value={70}/>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}

// ----------------------------------------------------------------------------
// Shared list views: My Videos, All Videos, Notifications list
// ----------------------------------------------------------------------------
function MyVideos() {
  const { currentUser, videos } = useApp();
  const mine = videos.filter(v => isVideoForUser(v, currentUser));
  return (
    <div className="p-6 lg:p-10 max-w-[1280px] mx-auto">
      <PageHeader eyebrow={ROLES[currentUser.role].label} title="My Videos" subtitle="Everything assigned to you, across all statuses."/>
      <VideoTable videos={mine}/>
    </div>
  );
}

function AllVideos() {
  const { videos } = useApp();
  const [filter, setFilter] = React.useState('ALL');
  const [q, setQ] = React.useState('');
  const list = videos.filter(v =>
    (filter === 'ALL' || v.status === filter) &&
    (q === '' || v.title.toLowerCase().includes(q.toLowerCase()))
  );
  return (
    <div className="p-6 lg:p-10 max-w-[1280px] mx-auto">
      <PageHeader eyebrow="Admin" title="All Videos" subtitle="Every piece of content moving through the platform."/>
      <Card padding="p-3" className="mb-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[200px]">
            <Icon name="search" size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-400"/>
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search title…"
              className="w-full h-9 pl-8 pr-3 rounded-lg border border-ink-200 text-[13px] focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100"/>
          </div>
          <div className="flex gap-1 flex-wrap">
            <FilterChip active={filter==='ALL'} onClick={() => setFilter('ALL')}>All <span className="text-ink-400 ml-1 font-mono">{videos.length}</span></FilterChip>
            {STATUS_ORDER.map(s => (
              <FilterChip key={s} active={filter===s} onClick={() => setFilter(s)}>
                <span className={`w-1.5 h-1.5 rounded-full ${STATUS[s].dot} mr-1.5`}></span>
                {STATUS[s].label}
                <span className="text-ink-400 ml-1 font-mono">{videos.filter(v=>v.status===s).length}</span>
              </FilterChip>
            ))}
          </div>
        </div>
      </Card>
      <VideoTable videos={list}/>
    </div>
  );
}

function NotificationsPage() {
  const { currentUser, notifications, dispatch, navigate } = useApp();
  const mine = notifications.filter(n => n.for === currentUser.id).sort((a,b) => new Date(b.at) - new Date(a.at));
  const unread = mine.filter(n => !n.read).length;
  return (
    <div className="p-6 lg:p-10 max-w-[920px] mx-auto">
      <PageHeader eyebrow="Inbox" title="Notifications" subtitle={`${unread} unread of ${mine.length} total`}
        actions={<Button tone="secondary" icon="check-check" disabled={unread === 0} onClick={() => dispatch({ type:'MARK_ALL_READ', userId: currentUser.id })}>Mark all read</Button>}/>
      <Card padding="p-0">
        {mine.length === 0 && <div className="py-16"><EmptyState icon="bell-off" title="All caught up" body="No notifications yet."/></div>}
        {mine.map((n, i) => (
          <button key={n.id} onClick={() => { dispatch({ type:'MARK_NOTIFICATIONS_READ', ids:[n.id] }); if (n.videoId) navigate({ name:'detail', videoId: n.videoId }); }}
            className={`w-full flex items-start gap-3 p-4 text-left hover:bg-ink-50 transition ${i!==0?'border-t border-ink-100':''} ${!n.read?'bg-brand-50/40':''}`}>
            <NotifIcon type={n.type}/>
            <div className="flex-1 min-w-0">
              <div className="text-[13.5px] text-ink-800">{n.text}</div>
              <div className="text-[11.5px] text-ink-400 mt-1">{timeAgo(n.at)} · {formatDate(n.at)}</div>
            </div>
            {!n.read && <span className="w-2 h-2 rounded-full bg-brand-500 mt-2.5 flex-shrink-0"></span>}
          </button>
        ))}
      </Card>
    </div>
  );
}

function NotifIcon({ type }) {
  const iconMap = { ASSIGNED:'user-plus', PEER_REVIEW:'user-check', FINAL_REVIEW:'shield-check', REVIEW:'eye', APPROVED:'check-circle-2', PEER_APPROVED:'user-check', FINAL_APPROVED:'shield-check', REJECTED:'x-circle', PUBLISHED:'send', COMMENT:'message-circle', UPLOAD:'upload' };
  const toneMap = { ASSIGNED:'bg-blue-50 text-blue-600', PEER_REVIEW:'bg-amber-50 text-amber-600', FINAL_REVIEW:'bg-orange-50 text-orange-600', REVIEW:'bg-amber-50 text-amber-600', APPROVED:'bg-brand-50 text-brand-600', PEER_APPROVED:'bg-amber-50 text-amber-600', FINAL_APPROVED:'bg-brand-50 text-brand-600', REJECTED:'bg-rose-50 text-rose-600', PUBLISHED:'bg-indigo-50 text-indigo-600', COMMENT:'bg-ink-100 text-ink-600', UPLOAD:'bg-violet-50 text-violet-600' };
  return (
    <div className={`w-10 h-10 rounded-lg flex-shrink-0 flex items-center justify-center ${toneMap[type]||'bg-ink-100 text-ink-600'}`}>
      <Icon name={iconMap[type]||'bell'} size={18}/>
    </div>
  );
}

// ----------------------------------------------------------------------------
// Shared components
// ----------------------------------------------------------------------------
function SectionHeader({ title, hint, action }) {
  return (
    <div className="flex items-end justify-between mb-3.5">
      <div>
        <h3 className="font-bold text-ink-900 text-[15px]">{title}</h3>
        {hint && <div className="text-[12px] text-ink-500 mt-0.5">{hint}</div>}
      </div>
      {action}
    </div>
  );
}

function FilterChip({ active, children, onClick }) {
  return (
    <button onClick={onClick} className={`inline-flex items-center h-8 px-3 rounded-lg text-[12.5px] font-semibold transition ${active?'bg-ink-900 text-white':'bg-ink-50 text-ink-700 hover:bg-ink-100'}`}>{children}</button>
  );
}

function VideoTable({ videos }) {
  const { navigate, userById } = useApp();
  if (videos.length === 0) return <Card><EmptyState icon="film" title="No videos" body="Nothing matches the current filter."/></Card>;
  return (
    <Card padding="p-0">
      <div className="overflow-x-auto scroll-thin">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-ink-50 border-b border-ink-200 text-[11px] uppercase tracking-widest text-ink-500">
              <th className="text-left font-bold px-4 py-2.5">Video</th>
              <th className="text-left font-bold px-4 py-2.5">Status</th>
              <th className="text-left font-bold px-4 py-2.5 hidden md:table-cell">Uploaded by</th>
              <th className="text-left font-bold px-4 py-2.5 hidden lg:table-cell">Assigned</th>
              <th className="text-left font-bold px-4 py-2.5 hidden md:table-cell">Updated</th>
              <th className="text-right font-bold px-4 py-2.5"></th>
            </tr>
          </thead>
          <tbody>
            {videos.map(v => {
              const up = userById(v.uploader);
              const assignee = userById(v.editor || v.writer || v.approver || v.social);
              return (
                <tr key={v.id} onClick={() => navigate({ name:'detail', videoId: v.id })}
                  className="border-b border-ink-100 last:border-0 hover:bg-ink-50/60 cursor-pointer transition">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <Thumbnail video={v} className="w-20 flex-shrink-0" overlay={false}/>
                      <div className="min-w-0">
                        <div className="font-semibold text-ink-900 text-[13px] leading-snug line-clamp-1">{v.title}</div>
                        <div className="text-[11.5px] text-ink-500 mt-0.5 font-mono">{formatDuration(v.duration)}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3"><StatusBadge status={v.status} size="sm"/></td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    {up && <div className="flex items-center gap-2"><Avatar user={up} size={22}/><span className="text-[12.5px] font-medium text-ink-700 truncate">{up.name}</span></div>}
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    {assignee ? (
                      <div className="flex items-center gap-2"><Avatar user={assignee} size={22}/><span className="text-[12.5px] text-ink-700 truncate">{assignee.name}</span></div>
                    ) : <span className="text-[12px] text-ink-400">—</span>}
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell text-[12px] text-ink-500">{timeAgo(v.updatedAt)}</td>
                  <td className="px-4 py-3 text-right">
                    <Icon name="chevron-right" size={14} className="text-ink-400 inline"/>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function ActivityFeed({ userId, limit = 8 }) {
  const { videos, userById } = useApp();
  // Pull recent history entries from videos the user is involved with.
  const events = [];
  videos.forEach(v => {
    if (!isInvolved(v, userId)) return;
    (v.history || []).forEach(h => events.push({ ...h, video: v }));
  });
  events.sort((a,b) => new Date(b.at) - new Date(a.at));
  const recent = events.slice(0, limit);
  return (
    <div className="divide-y divide-ink-100">
      {recent.length === 0 && <div className="p-6 text-center text-sm text-ink-400">No recent activity.</div>}
      {recent.map((e, i) => (
        <div key={i} className="p-3 flex gap-3 items-start">
          <div className={`w-8 h-8 rounded-lg flex-shrink-0 flex items-center justify-center ${actionStyle(e.action).bg}`}>
            <Icon name={actionStyle(e.action).icon} size={14} className={actionStyle(e.action).text}/>
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[12.5px] text-ink-800 leading-snug">
              <span className="font-semibold">{e.actor}</span> {e.label}
            </div>
            <div className="text-[11px] text-ink-400 mt-0.5 truncate">{e.video.title} · {timeAgo(e.at)}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function isInvolved(v, uid) {
  return [v.uploader, v.editor, v.writer, v.peerApprover, v.finalApprover, v.social].includes(uid);
}

function actionStyle(action) {
  switch (action) {
    case 'CREATED':         return { icon:'upload',         bg:'bg-violet-50', text:'text-violet-600' };
    case 'ASSIGNED':        return { icon:'user-plus',      bg:'bg-blue-50',   text:'text-blue-600' };
    case 'EDITED':          return { icon:'scissors',       bg:'bg-blue-50',   text:'text-blue-600' };
    case 'WRITTEN':         return { icon:'pen-tool',       bg:'bg-violet-50', text:'text-violet-600' };
    case 'PEER_APPROVED':   return { icon:'user-check',     bg:'bg-amber-50',  text:'text-amber-600' };
    case 'FINAL_APPROVED':  return { icon:'shield-check',   bg:'bg-brand-50',  text:'text-brand-600' };
    case 'APPROVED':        return { icon:'check-circle-2', bg:'bg-brand-50',  text:'text-brand-600' };
    case 'REJECTED':        return { icon:'x-circle',       bg:'bg-rose-50',   text:'text-rose-600' };
    case 'PUBLISHED':       return { icon:'send',           bg:'bg-indigo-50', text:'text-indigo-600' };
    default:                return { icon:'circle',         bg:'bg-ink-100',   text:'text-ink-600' };
  }
}

// ----------------------------------------------------------------------------
// Upload modal (Doctor)
// ----------------------------------------------------------------------------
function UploadModal({ open, onClose }) {
  const { uploadDoctorVideo, httpMode, toast } = useApp();
  const [stage, setStage] = React.useState('form'); // form | uploading | done
  const [title, setTitle] = React.useState('');
  const [description, setDescription] = React.useState('');
  const [duration, setDuration] = React.useState(280);
  const [progress, setProgress] = React.useState(0);
  const [file, setFile] = React.useState(null);
  const fileRef = React.useRef(null);
  const [dragOver, setDragOver] = React.useState(false);

  React.useEffect(() => {
    if (!open) {
      setStage('form'); setTitle(''); setDescription(''); setDuration(280); setProgress(0); setFile(null); setDragOver(false);
    }
  }, [open]);

  const pick = (f) => {
    if (!f) return;
    if (!/^video\//.test(f.type) && !/\.(mp4|mov|m4v|webm|avi|mkv)$/i.test(f.name)) {
      toast({ tone: 'error', title: 'Unsupported file', message: 'Please choose a video file (.mp4, .mov, …).' });
      return;
    }
    setFile(f);
    if (!title.trim()) setTitle(f.name.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' '));
  };

  const start = async () => {
    if (!title.trim() || !file) return;
    setStage('uploading');
    setProgress(0);
    try {
      await uploadDoctorVideo({ draft: { title: title.trim(), description: description.trim(), duration }, file, onProgress: setProgress });
      setStage('done');
      setTimeout(() => { onClose(); }, 1200);
    } catch (e) {
      setStage('form'); // error toast already shown
    }
  };

  return (
    <Modal open={open} onClose={() => stage !== 'uploading' && onClose()} title="Upload new video"
      footer={stage === 'form' && <>
        <Button tone="secondary" onClick={onClose}>Cancel</Button>
        <Button tone="brand" icon="upload" disabled={!title.trim() || !file} onClick={start}>Start upload</Button>
      </>}>
      {stage === 'form' && (
        <div className="space-y-4">
          <input ref={fileRef} type="file" accept="video/*,.mp4,.mov,.m4v,.webm,.mkv" className="hidden"
            onChange={e => pick(e.target.files?.[0])}/>
          <div
            onClick={() => fileRef.current?.click()}
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={e => { e.preventDefault(); setDragOver(false); pick(e.dataTransfer.files?.[0]); }}
            className={`rounded-xl border-2 border-dashed p-6 text-center cursor-pointer transition ${dragOver ? 'border-brand-400 bg-brand-50' : file ? 'border-brand-300 bg-brand-50/40' : 'border-ink-200 bg-ink-50/50 hover:border-ink-300'}`}>
            {file ? (
              <div className="flex items-center gap-3 text-left">
                <div className="w-11 h-11 rounded-lg bg-white border border-brand-200 flex items-center justify-center flex-shrink-0">
                  <Icon name="file-video-2" size={20} className="text-brand-600"/>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-mono text-[12.5px] text-ink-900 truncate">{file.name}</div>
                  <div className="text-[11.5px] text-ink-500 mt-0.5">{(file.size / 1e6).toFixed(1)} MB · {file.type || 'video'} · <span className="text-brand-600 font-semibold">Replace</span></div>
                </div>
              </div>
            ) : (<>
              <div className="w-12 h-12 mx-auto rounded-xl bg-white border border-ink-200 flex items-center justify-center mb-3">
                <Icon name="film" size={20} className="text-ink-500"/>
              </div>
              <div className="font-semibold text-ink-900 text-[13.5px]">Drop your .mp4 or .mov</div>
              <div className="text-[11.5px] text-ink-500 mt-0.5">Or click to browse — up to 8GB</div>
            </>)}
          </div>
          <Field label="Title" required>
            <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. 5 things every diabetic should ask their doctor"/>
          </Field>
          <Field label="Description" hint="A short summary editors and writers will see.">
            <Textarea rows={3} value={description} onChange={e => setDescription(e.target.value)} placeholder="What's the angle? What should the editor preserve?"/>
          </Field>
          <Field label="Duration (seconds)">
            <Input type="number" value={duration} min={30} max={3600} onChange={e => setDuration(parseInt(e.target.value)||0)}/>
          </Field>
          {!httpMode && <div className="flex items-start gap-2 text-[11px] text-ink-400 bg-ink-50 rounded-lg p-2.5"><Icon name="info" size={12} className="mt-0.5"/><span>Demo mode — the file is processed locally and not sent to a server. Connect the backend to upload to S3.</span></div>}
        </div>
      )}
      {stage === 'uploading' && (
        <div className="py-6 text-center">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-brand-50 text-brand-600 flex items-center justify-center mb-4 pulse-ring">
            <Icon name="upload-cloud" size={28}/>
          </div>
          <div className="font-bold text-ink-900">Uploading "{title}"</div>
          <div className="text-[12.5px] text-ink-500 mt-1">{file ? `${(file.size/1e6).toFixed(1)} MB · ` : ''}Don't close this window…</div>
          <div className="mt-5 max-w-sm mx-auto">
            <ProgressBar value={progress}/>
            <div className="text-[11.5px] text-ink-500 mt-2 font-mono">{Math.round(progress)}%</div>
          </div>
        </div>
      )}
      {stage === 'done' && (
        <div className="py-8 text-center">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-brand-50 text-brand-600 flex items-center justify-center mb-4">
            <Icon name="check-circle-2" size={28}/>
          </div>
          <div className="font-bold text-ink-900">Upload complete</div>
          <div className="text-[12.5px] text-ink-500 mt-1">Routed to editing — you'll be notified when it's ready for review.</div>
        </div>
      )}
    </Modal>
  );
}

// ----------------------------------------------------------------------------
// Edit upload modal (Editor) — simulates uploading the edited cut.
// ----------------------------------------------------------------------------
function EditUploadModal({ open, onClose, video, mode = 'handoff' }) {
  const { uploadEditedCut, httpMode, toast } = useApp();
  const [stage, setStage] = React.useState('form');
  const [notes, setNotes] = React.useState('');
  const [progress, setProgress] = React.useState(0);
  const [file, setFile] = React.useState(null);
  const [nextVer, setNextVer] = React.useState(1);
  const fileRef = React.useRef(null);
  const [dragOver, setDragOver] = React.useState(false);

  // 'handoff' = first edit → advances to Writing. 'revision' = adds V2/V3, keeps status.
  const isRevision = mode === 'revision';

  React.useEffect(() => {
    if (open && video) {
      setStage('form');
      setNotes(isRevision ? '' : 'Color graded · Lower thirds · Captions baked in');
      setProgress(0);
      setFile(null);
      setDragOver(false);
      const editCount = (video.versions || []).filter(x => x.kind === 'edit').length;
      setNextVer(editCount + 1);
    }
  }, [open, video, isRevision]);

  const pick = (f) => {
    if (!f) return;
    if (!/^video\//.test(f.type) && !/\.(mp4|mov|m4v|webm|avi|mkv)$/i.test(f.name)) {
      toast({ tone: 'error', title: 'Unsupported file', message: 'Please choose a video file (.mp4, .mov, …).' });
      return;
    }
    setFile(f);
  };

  if (!video) return null;

  const start = async () => {
    if (!file) return;
    setStage('uploading');
    setProgress(0);
    try {
      await uploadEditedCut({
        video, file, isRevision,
        notes: notes || (isRevision ? 'Revision' : 'Color graded · Lower thirds · Captions baked in'),
        onProgress: setProgress,
      });
      setStage('done');
      setTimeout(onClose, 1100);
    } catch (e) {
      setStage('form');
    }
  };

  const raw = (video.versions || []).find(v => v.kind === 'raw');
  const title = isRevision ? `Upload new version (V${nextVer})` : 'Upload edited cut';

  return (
    <Modal open={open} onClose={() => stage !== 'uploading' && onClose()} title={title}
      footer={stage === 'form' && <>
        <Button tone="secondary" onClick={onClose}>Cancel</Button>
        <Button tone="brand" icon="upload-cloud" disabled={!file} onClick={start}>Start upload</Button>
      </>}>
      {stage === 'form' && (
        <div className="space-y-4">
          <div className="bg-ink-50 border border-ink-200 rounded-xl p-3 flex items-start gap-3">
            <Thumbnail video={video} className="w-24 flex-shrink-0"/>
            <div className="min-w-0 flex-1">
              <div className="font-semibold text-ink-900 text-[13.5px] leading-snug">{video.title}</div>
              {raw && (
                <div className="mt-1.5 flex items-center gap-1.5 text-[11.5px] text-ink-500">
                  <Icon name="file-video" size={12}/>
                  <span>Editing from <span className="font-mono text-ink-700">{raw.fileName}</span></span>
                </div>
              )}
            </div>
          </div>

          <input ref={fileRef} type="file" accept="video/*,.mp4,.mov,.m4v,.webm,.mkv" className="hidden"
            onChange={e => pick(e.target.files?.[0])}/>
          <div
            onClick={() => fileRef.current?.click()}
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={e => { e.preventDefault(); setDragOver(false); pick(e.dataTransfer.files?.[0]); }}
            className={`rounded-xl border-2 border-dashed p-5 cursor-pointer transition ${dragOver ? 'border-brand-400 bg-brand-50' : 'border-brand-300 bg-brand-50/40 hover:bg-brand-50'}`}>
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-lg bg-white border border-brand-200 flex items-center justify-center flex-shrink-0">
                <Icon name="file-video-2" size={20} className="text-brand-600"/>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[10.5px] uppercase tracking-widest font-bold text-brand-700">Edited cut · V{nextVer}</div>
                {file ? (
                  <>
                    <div className="font-mono text-[12.5px] text-ink-900 truncate mt-0.5">{file.name}</div>
                    <div className="flex items-center gap-2 text-[11px] text-ink-500 mt-1">
                      <span>{(file.size / 1e6).toFixed(1)} MB</span>
                      <span>·</span>
                      <span>{file.type || 'video'}</span>
                      <span>·</span>
                      <span className="text-brand-600 font-semibold">Replace file</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="text-[12.5px] text-ink-700 mt-0.5">Click or drop your edited cut here</div>
                    <div className="text-[11px] text-ink-500 mt-1">.mp4 / .mov — H.264 1080p recommended</div>
                  </>
                )}
              </div>
            </div>
          </div>

          <Field label="Edit notes" hint="Optional — the writer and approver will see this with the version.">
            <Textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)} placeholder="e.g. Tightened intro, removed um/uh, added lower-thirds."/>
          </Field>

          <div className="flex items-start gap-2 text-[11.5px] text-ink-500 bg-ink-50 rounded-lg p-2.5">
            <Icon name="info" size={13} className="text-ink-400 mt-0.5"/>
            <span>{isRevision
              ? `This adds V${nextVer} to the version history. The original and all earlier cuts stay on file — nothing is overwritten.`
              : 'The original recording stays on file. Your edited cut is what flows downstream to the writer.'}</span>
          </div>
        </div>
      )}

      {stage === 'uploading' && (
        <div className="py-6 text-center">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-brand-50 text-brand-600 flex items-center justify-center mb-4 pulse-ring">
            <Icon name="upload-cloud" size={28}/>
          </div>
          <div className="font-bold text-ink-900">Uploading <span className="font-mono text-[13px]">{file?.name}</span></div>
          <div className="text-[12.5px] text-ink-500 mt-1">{file ? `${(file.size/1e6).toFixed(1)} MB · ` : ''}Don't close this window…</div>
          <div className="mt-5 max-w-sm mx-auto">
            <ProgressBar value={progress}/>
            <div className="text-[11.5px] text-ink-500 mt-2 font-mono">{Math.round(progress)}%</div>
          </div>
        </div>
      )}

      {stage === 'done' && (
        <div className="py-8 text-center">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-brand-50 text-brand-600 flex items-center justify-center mb-4">
            <Icon name="check-circle-2" size={28}/>
          </div>
          <div className="font-bold text-ink-900">{isRevision ? `Version V${nextVer} uploaded` : 'Edited cut uploaded'}</div>
          <div className="text-[12.5px] text-ink-500 mt-1">{isRevision ? 'Added to the version history.' : 'Routed to the writer for captions.'}</div>
        </div>
      )}
    </Modal>
  );
}

Object.assign(window, {
  Dashboard, MyVideos, AllVideos, NotificationsPage, PageHeader, SectionHeader, StatTile,
  VideoTable, ActivityFeed, UploadModal, EditUploadModal, FilterChip, PlatformIcon, PLATFORMS,
});
