// ============================================================================
// Data layer — mock users, videos, AppContext, localStorage persistence.
// ============================================================================
const { createContext, useContext, useState, useEffect, useReducer, useMemo, useRef, useCallback } = React;

const STATUS = {
  UPLOADED:     { key: 'UPLOADED',     label: 'Uploaded',        badge: 'bg-ink-100 text-ink-700 border-ink-200',         dot: 'bg-ink-400' },
  EDITING:      { key: 'EDITING',      label: 'Editing',         badge: 'bg-blue-50 text-blue-700 border-blue-200',       dot: 'bg-blue-500' },
  WRITING:      { key: 'WRITING',      label: 'Writing',         badge: 'bg-violet-50 text-violet-700 border-violet-200', dot: 'bg-violet-500' },
  PEER_REVIEW:  { key: 'PEER_REVIEW',  label: 'Peer Review',     badge: 'bg-amber-50 text-amber-700 border-amber-200',    dot: 'bg-amber-500' },
  FINAL_REVIEW: { key: 'FINAL_REVIEW', label: 'Final Approval',  badge: 'bg-orange-50 text-orange-700 border-orange-200', dot: 'bg-orange-500' },
  APPROVED:     { key: 'APPROVED',     label: 'Approved',        badge: 'bg-brand-50 text-brand-700 border-brand-200',    dot: 'bg-brand-500' },
  REJECTED:     { key: 'REJECTED',     label: 'Rejected',        badge: 'bg-rose-50 text-rose-700 border-rose-200',       dot: 'bg-rose-500' },
  PUBLISHED:    { key: 'PUBLISHED',    label: 'Published',       badge: 'bg-indigo-50 text-indigo-700 border-indigo-200', dot: 'bg-indigo-500' },
};
const STATUS_ORDER = ['UPLOADED', 'EDITING', 'WRITING', 'PEER_REVIEW', 'FINAL_REVIEW', 'APPROVED', 'PUBLISHED'];

const ROLES = {
  ADMIN:         { key: 'ADMIN',         label: 'Administrator',  desc: 'Manages users, roles and platform settings' },
  DOCTOR:        { key: 'DOCTOR',        label: 'Doctor',         desc: 'Records and uploads clinical content' },
  EDITOR:        { key: 'EDITOR',        label: 'Video Editor',   desc: 'Trims, color-grades and finalizes footage' },
  WRITER:        { key: 'WRITER',        label: 'Content Writer', desc: 'Writes captions, hashtags, descriptions' },
  APPROVER:      { key: 'APPROVER',      label: 'Reviewer',       desc: 'Peer review or final compliance sign-off' },
  SOCIAL:        { key: 'SOCIAL',        label: 'Social Media',   desc: 'Publishes to channels and schedules' },
};

// Approver tiers: 'peer' = Stage 1 (clinical/peer review), 'final' = Stage 2 (compliance / department head)
const APPROVER_TIERS = {
  peer:  { label: 'Peer Review',     short: 'Stage 1', status: 'PEER_REVIEW',  next: 'FINAL_REVIEW', icon: 'user-check' },
  final: { label: 'Final Approval',  short: 'Stage 2', status: 'FINAL_REVIEW', next: 'APPROVED',     icon: 'shield-check' },
};

// Selectable in the role picker / on user create. ADMIN excluded so admins must be promoted explicitly.
const ASSIGNABLE_ROLES = ['DOCTOR', 'EDITOR', 'WRITER', 'APPROVER', 'SOCIAL'];

const USERS = [
  { id: 'ad1', name: 'Sarah Mitchell',     role: 'ADMIN',    specialty: 'Practice Administrator',    initials: 'SM', tone: 'thumb-grad-3', email: 'sarah.mitchell@drmanojhomeopathy.com',  phone: '+91 98480 10100', active: true },
  { id: 'd1', name: 'Dr. Manoj Kuriakose', role: 'DOCTOR',   specialty: 'Homeopathy · Founder',      initials: 'MK', tone: 'thumb-grad-0', email: 'dr.manoj@drmanojhomeopathy.com',        phone: '+91 98480 10124', active: true },
  { id: 'd2', name: 'Dr. Anika Verma',     role: 'DOCTOR',   specialty: 'Skin & Hair Homeopathy',   initials: 'AV', tone: 'thumb-grad-2', email: 'anika.verma@drmanojhomeopathy.com',     phone: '+91 98480 10188', active: true },
  { id: 'd3', name: 'Dr. Sameer Iyer',     role: 'DOCTOR',   specialty: 'Pediatric Homeopathy',     initials: 'SI', tone: 'thumb-grad-4', email: 'sameer.iyer@drmanojhomeopathy.com',     phone: '+91 98480 10211', active: true },
  { id: 'e1', name: 'Priya Shah',          role: 'EDITOR',   specialty: 'Senior Editor',            initials: 'PS', tone: 'thumb-grad-1', email: 'priya.shah@drmanojhomeopathy.com',      phone: '+91 98480 10307', active: true },
  { id: 'e2', name: 'Marcus Chen',         role: 'EDITOR',   specialty: 'Motion Editor',            initials: 'MC', tone: 'thumb-grad-3', email: 'marcus.chen@drmanojhomeopathy.com',     phone: '+91 98480 10342', active: true },
  { id: 'w1', name: 'Lena Okafor',         role: 'WRITER',   specialty: 'Copy Lead',                initials: 'LO', tone: 'thumb-grad-5', email: 'lena.okafor@drmanojhomeopathy.com',     phone: '+91 98480 10418', active: true },
  { id: 'w2', name: 'Diego Alvarez',       role: 'WRITER',   specialty: 'Medical Writer',           initials: 'DA', tone: 'thumb-grad-4', email: 'diego.alvarez@drmanojhomeopathy.com',   phone: '+91 98480 10455', active: true },
  { id: 'a1', name: 'Dr. Hannah Park',     role: 'APPROVER', tier: 'peer',  specialty: 'Clinical Reviewer · BHMS', initials: 'HP', tone: 'thumb-grad-2', email: 'hannah.park@drmanojhomeopathy.com',     phone: '+91 98480 10520', active: true },
  { id: 'a2', name: 'Olivia Tran',         role: 'APPROVER', tier: 'final', specialty: 'Practice Head · Compliance', initials: 'OT', tone: 'thumb-grad-1', email: 'olivia.tran@drmanojhomeopathy.com',     phone: '+91 98480 10566', active: true },
  { id: 's1', name: 'Yusuf Bello',         role: 'SOCIAL',   specialty: 'Channel Manager',          initials: 'YB', tone: 'thumb-grad-0', email: 'yusuf.bello@drmanojhomeopathy.com',     phone: '+91 98480 10612', active: true },
];

// Mock videos covering every status, 16 total.
function _t(daysAgo, h = 10, m = 0) {
  const d = new Date('2026-05-23T14:30:00Z');
  d.setUTCDate(d.getUTCDate() - daysAgo);
  d.setUTCHours(h, m, 0, 0);
  return d.toISOString();
}

const SEED_VIDEOS = [
  { id:'v01', title:'Understanding Diabetes Management', description:'A comprehensive primer on Type II diabetes care: glycemic targets, lifestyle interventions, and how to interpret your CGM.', status:'EDITING',  thumb:0, duration:320, uploader:'d1', editor:'e1', writer:null,  peerApprover:null, finalApprover:null, social:null, createdAt:_t(3,10),  updatedAt:_t(0,14,30), captions:'', hashtags:[], platforms:[], reasons:[] },
  { id:'v02', title:'5 Warning Signs of a Heart Attack', description:'What to recognize, what to do in the first 10 minutes, and when to call emergency services.', status:'FINAL_REVIEW', thumb:1, duration:184, uploader:'d2', editor:'e2', writer:'w1',  peerApprover:'a1', finalApprover:'a2', social:null, createdAt:_t(5,9),   updatedAt:_t(0,11,12), captions:'Know the 5 warning signs that could save a life. Chest pressure isn’t the only signal — fatigue, jaw pain and nausea matter too.', hashtags:['#HeartHealth','#Cardiology','#FirstAid'], platforms:['Instagram','YouTube'], reasons:[] },
  { id:'v03', title:'Childhood Vaccination Schedule Explained', description:'A parent-friendly walkthrough of the 0–18 month immunization schedule and why timing matters.', status:'WRITING',  thumb:2, duration:412, uploader:'d3', editor:'e1', writer:'w2',  peerApprover:null, finalApprover:null, social:null, createdAt:_t(2,8,30), updatedAt:_t(0,9,40), captions:'', hashtags:[], platforms:[], reasons:[] },
  { id:'v04', title:'Hypertension: The Silent Killer',     description:'Why blood pressure matters in your 30s and what numbers to actually track at home.', status:'APPROVED', thumb:3, duration:265, uploader:'d2', editor:'e2', writer:'w1',  peerApprover:'a1', finalApprover:'a2', social:'s1', createdAt:_t(7,11),  updatedAt:_t(0,8,15), captions:'High blood pressure rarely shouts — but it whispers for years. Here’s how to listen.', hashtags:['#Hypertension','#PreventiveCare','#HeartHealth'], platforms:['Instagram','YouTube','Twitter'], reasons:[] },
  { id:'v05', title:'When to Worry About Your Child’s Fever', description:'A pediatrician’s checklist for parents: temperature thresholds, red flags and home care.', status:'PUBLISHED', thumb:4, duration:228, uploader:'d3', editor:'e1', writer:'w2', peerApprover:'a1', finalApprover:'a2', social:'s1', createdAt:_t(14,10), updatedAt:_t(1,16),    captions:'Not every fever is an emergency — but here are the signs that mean call the doctor tonight.', hashtags:['#Pediatrics','#ParentingTips','#KidsHealth'], platforms:['Instagram','YouTube'], reasons:[] },
  { id:'v06', title:'PCOS: Symptoms You Shouldn’t Ignore', description:'A frank conversation about polycystic ovary syndrome — what it is and isn’t.', status:'EDITING',  thumb:5, duration:356, uploader:'d1', editor:'e2', writer:null, peerApprover:null, finalApprover:null, social:null, createdAt:_t(1,9),   updatedAt:_t(0,12),    captions:'', hashtags:[], platforms:[], reasons:[] },
  { id:'v07', title:'Thyroid Health 101', description:'Everything most patients wish their doctor had explained the first time.', status:'WRITING', thumb:0, duration:298, uploader:'d1', editor:'e1', writer:'w1', peerApprover:null, finalApprover:null, social:null, createdAt:_t(4,14),  updatedAt:_t(0,10),    captions:'', hashtags:[], platforms:[], reasons:[] },
  { id:'v08', title:'Sleep Apnea: Are You at Risk?', description:'Snoring isn’t funny when it’s starving your brain of oxygen.', status:'PEER_REVIEW', thumb:1, duration:401, uploader:'d2', editor:'e2', writer:'w2', peerApprover:'a1', finalApprover:null, social:null, createdAt:_t(6,10),  updatedAt:_t(0,13,5),  captions:'If you wake up tired, even after 8 hours — read this thread.', hashtags:['#Sleep','#Wellness','#Health'], platforms:['Twitter','Instagram'], reasons:[] },
  { id:'v09', title:'Reading Your Lab Report Without Panic', description:'The 6 numbers worth understanding before your next annual check-up.', status:'APPROVED', thumb:2, duration:512, uploader:'d1', editor:'e1', writer:'w1', peerApprover:'a1', finalApprover:'a2', social:'s1', createdAt:_t(8,9),  updatedAt:_t(0,7),     captions:'Your lab report is a story. Here’s how to read it.', hashtags:['#LabResults','#PreventiveCare'], platforms:['YouTube'], reasons:[] },
  { id:'v10', title:'Migraine vs. Headache: Know the Difference', description:'How neurologists actually distinguish them — and what you can do tonight.', status:'PUBLISHED', thumb:3, duration:267, uploader:'d2', editor:'e2', writer:'w2', peerApprover:'a1', finalApprover:'a2', social:'s1', createdAt:_t(18,11), updatedAt:_t(3,15),    captions:'Not all head pain is the same. Here’s how to tell — and what works.', hashtags:['#Migraine','#Neurology','#Wellness'], platforms:['Instagram','YouTube','Twitter'], reasons:[] },
  { id:'v11', title:'Iron Deficiency: It’s More Common Than You Think', description:'Fatigue, hair loss, brain fog — sometimes it really is just iron.', status:'UPLOADED', thumb:4, duration:198, uploader:'d3', editor:null, writer:null, peerApprover:null, finalApprover:null, social:null, createdAt:_t(0,9),   updatedAt:_t(0,9),     captions:'', hashtags:[], platforms:[], reasons:[] },
  { id:'v12', title:'Mental Health for New Parents', description:'Why postpartum mood matters — for mothers AND fathers.', status:'WRITING', thumb:5, duration:374, uploader:'d3', editor:'e1', writer:'w2', peerApprover:null, finalApprover:null, social:null, createdAt:_t(3,15),  updatedAt:_t(0,11),    captions:'', hashtags:[], platforms:[], reasons:[] },
  { id:'v13', title:'Cholesterol: The Good, Bad and Misunderstood', description:'A cardiologist debunks 5 of the most common cholesterol myths.', status:'PEER_REVIEW', thumb:0, duration:343, uploader:'d2', editor:'e2', writer:'w1', peerApprover:'a1', finalApprover:null, social:null, createdAt:_t(5,13), updatedAt:_t(0,10,30), captions:'Cholesterol isn’t a number to fear — it’s a number to understand.', hashtags:['#Cholesterol','#HeartHealth','#Cardiology'], platforms:['Instagram','YouTube'], reasons:[] },
  { id:'v14', title:'How to Talk to Your Doctor About Anxiety', description:'A script for the first appointment — what to bring, what to ask, what to expect.', status:'EDITING', thumb:1, duration:289, uploader:'d1', editor:'e1', writer:null, peerApprover:null, finalApprover:null, social:null, createdAt:_t(2,11), updatedAt:_t(0,13),    captions:'', hashtags:[], platforms:[], reasons:[] },
  { id:'v15', title:'Asthma in Adults: Don’t Outgrow It Wrong', description:'Why adult-onset asthma is real, and how it’s mis-diagnosed.', status:'APPROVED', thumb:2, duration:312, uploader:'d3', editor:'e2', writer:'w2', peerApprover:'a1', finalApprover:'a2', social:'s1', createdAt:_t(9,10), updatedAt:_t(0,9,20), captions:'Wheezing as an adult? Don’t shrug it off.', hashtags:['#Asthma','#Respiratory','#AdultHealth'], platforms:['Instagram','Twitter'], reasons:[] },
  { id:'v16', title:'GERD: When Heartburn Is More Than Heartburn', description:'When to escalate from antacids to an endoscopy.', status:'UPLOADED', thumb:3, duration:241, uploader:'d2', editor:null, writer:null, peerApprover:null, finalApprover:null, social:null, createdAt:_t(0,8,30), updatedAt:_t(0,8,30), captions:'', hashtags:[], platforms:[], reasons:[] },
];

// ---------------------------------------------------------------------------
// Data classification (governance) — each video gets a sensitivity label.
// ---------------------------------------------------------------------------
const CLASSIFICATIONS = {
  PHI:      { key:'PHI',      label:'PHI / Restricted', short:'PHI',      desc:'Protected health info — patient-identifiable content', tone:'bg-rose-50 text-rose-700 border-rose-200',     dot:'bg-rose-500',  retentionDays: 2555 },  // 7y HIPAA
  INTERNAL: { key:'INTERNAL', label:'Internal',         short:'Internal', desc:'Internal-only — not for public distribution',          tone:'bg-amber-50 text-amber-700 border-amber-200',  dot:'bg-amber-500', retentionDays: 1095 },  // 3y
  PUBLIC:   { key:'PUBLIC',   label:'Public',           short:'Public',   desc:'Cleared for external publication',                       tone:'bg-brand-50 text-brand-700 border-brand-200',  dot:'bg-brand-500', retentionDays: 730 },   // 2y
};
function _classifyVideo(v) {
  // Once published, content is public-facing. Anything mentioning patient identifiers in clinical detail is PHI-style; the rest is Internal.
  if (v.status === 'PUBLISHED') return 'PUBLIC';
  const phiKeywords = /diabet|migraine|cholesterol|hypertens|pcos|anxiety|asthma|sleep apnea|gerd|lab report|iron deficiency|thyroid/i;
  return phiKeywords.test(v.title + ' ' + (v.description||'')) ? 'PHI' : 'INTERNAL';
}

// Retention countdown helper — days from createdAt until purge.
function retentionRemaining(video) {
  const cls = CLASSIFICATIONS[video.classification || 'INTERNAL'];
  const created = new Date(video.createdAt).getTime();
  const purgeAt = created + cls.retentionDays * 86400000;
  const now = new Date('2026-05-25T14:30:00Z').getTime();
  const daysLeft = Math.ceil((purgeAt - now) / 86400000);
  const pct = Math.max(0, Math.min(100, ((purgeAt - now) / (cls.retentionDays * 86400000)) * 100));
  return { daysLeft, pct, purgeAt: new Date(purgeAt).toISOString(), totalDays: cls.retentionDays };
}

// ---------------------------------------------------------------------------
// Audit log — every privileged action records here.
// ---------------------------------------------------------------------------
function _buildSeedAudit(videos) {
  const out = [];
  videos.forEach(v => {
    (v.history || []).forEach((h, i) => {
      out.push({
        id: `aud_${v.id}_${i}`,
        at: h.at,
        actor: h.actor,
        action: h.action,
        resourceType: 'video',
        resourceId: v.id,
        resourceLabel: v.title,
        outcome: 'success',
        sourceIp: _seedIp(),
        userAgent: 'Web/Chrome 126',
        sessionId: 'sess_seed_' + (h.actor||'').replace(/\W/g,'').toLowerCase().slice(0,12),
      });
    });
  });
  out.sort((a,b) => new Date(b.at) - new Date(a.at));
  return out;
}
function _seedIp() {
  return `10.${Math.floor(Math.random()*16)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`;
}

// Session model — fake JWT-like envelope with expiry.
const SESSION_TTL_MIN = 30;
function _newSession(userId) {
  const now = Date.now();
  return {
    sessionId: 'sess_' + Math.random().toString(36).slice(2, 14),
    userId,
    issuedAt: new Date(now).toISOString(),
    expiresAt: new Date(now + SESSION_TTL_MIN * 60000).toISOString(),
    lastActivity: new Date(now).toISOString(),
    sourceIp: _seedIp(),
    userAgent: 'Web/Chrome 126',
    mfaVerified: true,
  };
}
function _buildHistory(v) {
  const u  = USERS.find(x => x.id === v.uploader);
  const e  = v.editor        && USERS.find(x => x.id === v.editor);
  const w  = v.writer        && USERS.find(x => x.id === v.writer);
  const p  = v.peerApprover  && USERS.find(x => x.id === v.peerApprover);
  const f  = v.finalApprover && USERS.find(x => x.id === v.finalApprover);
  const s  = v.social        && USERS.find(x => x.id === v.social);
  const h = [{ action:'CREATED', actor: u?.name || 'Unknown', label:`uploaded "${v.title}"`, at: v.createdAt }];
  if (e) h.push({ action:'ASSIGNED', actor:'Workflow Bot', label:`assigned to editor ${e.name}`, at: _bump(v.createdAt, 5) });
  if (['WRITING','PEER_REVIEW','FINAL_REVIEW','APPROVED','REJECTED','PUBLISHED'].includes(v.status) && e) h.push({ action:'EDITED', actor: e.name, label:'completed editing', at: _bump(v.createdAt, 60*4) });
  if (w && ['WRITING','PEER_REVIEW','FINAL_REVIEW','APPROVED','REJECTED','PUBLISHED'].includes(v.status)) h.push({ action:'ASSIGNED', actor:'Workflow Bot', label:`assigned to writer ${w.name}`, at: _bump(v.createdAt, 60*4+5) });
  if (['PEER_REVIEW','FINAL_REVIEW','APPROVED','REJECTED','PUBLISHED'].includes(v.status) && w) h.push({ action:'WRITTEN', actor: w.name, label:'submitted captions for review', at: _bump(v.createdAt, 60*8) });
  if (['FINAL_REVIEW','APPROVED','PUBLISHED'].includes(v.status) && p) h.push({ action:'PEER_APPROVED', actor: p.name, label:'cleared peer review (Stage 1)', at: _bump(v.createdAt, 60*9) });
  if (['APPROVED','PUBLISHED'].includes(v.status) && f) h.push({ action:'FINAL_APPROVED', actor: f.name, label:'final approval — cleared for publishing (Stage 2)', at: _bump(v.createdAt, 60*10) });
  if (v.status === 'PUBLISHED' && s) h.push({ action:'PUBLISHED', actor: s.name, label:`published to ${(v.platforms||[]).join(', ') || 'channels'}`, at: v.updatedAt });
  return h;
}
function _bump(iso, mins) {
  const d = new Date(iso);
  d.setUTCMinutes(d.getUTCMinutes() + mins);
  return d.toISOString();
}

// Build initial versions — every video has a raw recording. Once past EDITING,
// the editor has also uploaded an edited cut.
function _buildVersions(v) {
  const slug = v.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 32);
  const versions = [{
    id: v.id + '_raw',
    kind: 'raw',
    label: 'Original recording',
    fileName: `${slug}_raw.mov`,
    sizeMB: Math.round(v.duration * 28 / 10) / 10,
    by: v.uploader,
    at: v.createdAt,
    notes: 'Studio capture · ProRes 422 · 4K 24p',
  }];
  if (['WRITING','PEER_REVIEW','FINAL_REVIEW','APPROVED','REJECTED','PUBLISHED'].includes(v.status) && v.editor) {
    versions.push({
      id: v.id + '_edit1',
      kind: 'edit',
      label: 'Edited cut · v1',
      fileName: `${slug}_edit_v1.mp4`,
      sizeMB: Math.round(v.duration * 6.5 / 10) / 10,
      by: v.editor,
      at: _bump(v.createdAt, 60 * 4),
      notes: 'Color graded · Lower thirds · Captions baked in',
    });
  }
  return versions;
}

// Default version a viewer should see: latest edit if present, else raw.
function defaultVersionId(v) {
  if (!v.versions?.length) return null;
  const edits = v.versions.filter(x => x.kind === 'edit');
  if (edits.length) return edits[edits.length - 1].id;
  return v.versions[0].id;
}

// Build initial comments — a couple per active video.
const SEED_COMMENTS = {
  v01: [
    { id:'c1', author:'e1', text:'Audio levels dipped around 02:14 — re-syncing now.', at:_t(1,11) },
    { id:'c2', author:'d1', text:'Thanks Priya. Can we also tighten the intro?', at:_t(1,12) },
  ],
  v02: [
    { id:'c3', author:'w1', text:'Draft captions are in. Tagged @HannahPark for review.', at:_t(1,9) },
  ],
  v04: [
    { id:'c4', author:'a1', text:'Approved. Strong opening — this should perform.', at:_t(0,8,15) },
  ],
  v08: [
    { id:'c5', author:'w2', text:'Pulled stats from JAMA 2024 — ready for review.', at:_t(1,15) },
  ],
};

const INITIAL_NOTIFICATIONS = [
  { id:'n1', for:'e1', type:'ASSIGNED',  text:'You were assigned to edit "Understanding Diabetes Management"', videoId:'v01', at:_t(3,10,5), read:false },
  { id:'n2', for:'w1', type:'ASSIGNED',  text:'New script needed for "5 Warning Signs of a Heart Attack"',    videoId:'v02', at:_t(4,12),   read:false },
  { id:'n3', for:'a1', type:'PEER_REVIEW', text:'"Cholesterol: The Good, Bad and Misunderstood" is awaiting your peer review', videoId:'v13', at:_t(0,10,30), read:false },
  { id:'n4', for:'s1', type:'APPROVED',  text:'"Reading Your Lab Report Without Panic" has cleared final approval — ready to publish', videoId:'v09', at:_t(0,7), read:false },
  { id:'n5', for:'d2', type:'PUBLISHED', text:'"Migraine vs. Headache" went live on Instagram, YouTube & Twitter', videoId:'v10', at:_t(3,15), read:false },
  { id:'n6', for:'d1', type:'COMMENT',   text:'Priya Shah commented on "Understanding Diabetes Management"', videoId:'v01', at:_t(1,11), read:true },
  { id:'n7', for:'a1', type:'PEER_REVIEW', text:'"Sleep Apnea: Are You at Risk?" is awaiting your peer review', videoId:'v08', at:_t(0,13,5), read:false },
  { id:'n8', for:'a2', type:'FINAL_REVIEW', text:'"5 Warning Signs of a Heart Attack" is awaiting final approval (Stage 2)', videoId:'v02', at:_t(0,11,15), read:false },
];

// ---------------------------------------------------------------------------
// Context
// ---------------------------------------------------------------------------
const AppContext = createContext(null);
const useApp = () => useContext(AppContext);

const LS_KEY = 'clinicast_state_v8';

function loadInitialState() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  // Build initial state
  const videos = SEED_VIDEOS.map(v => ({
    ...v,
    comments: SEED_COMMENTS[v.id] || [],
    history: _buildHistory(v),
    versions: _buildVersions(v),
    classification: _classifyVideo(v),
  }));
  return {
    currentUserId: null,
    users: USERS.map(u => ({ ...u })),
    videos,
    auditLog: _buildSeedAudit(videos),
    session: null,
    notifications: INITIAL_NOTIFICATIONS,
    toasts: [],
    route: { name: 'dashboard', videoId: null },
  };
}

function reducer(state, action) {
  switch (action.type) {
    case 'LOGIN':   return { ...state, currentUserId: action.userId, session: _newSession(action.userId), route: { name:'dashboard', videoId:null } };
    case 'LOGOUT':  return { ...state, currentUserId: null, session: null, route: { name:'dashboard', videoId:null } };
    case 'SESSION_TOUCH': return { ...state, session: state.session ? { ...state.session, lastActivity: new Date().toISOString() } : null };
    case 'AUDIT_APPEND': return { ...state, auditLog: [action.entry, ...state.auditLog].slice(0, 500) };
    case 'HYDRATE': return { ...state, ...action.data };
    case 'NAVIGATE': return { ...state, route: action.route };
    case 'UPDATE_VIDEO': {
      const videos = state.videos.map(v => v.id === action.id ? { ...v, ...action.patch, updatedAt: new Date().toISOString() } : v);
      return { ...state, videos };
    }
    case 'APPEND_HISTORY': {
      const videos = state.videos.map(v => v.id === action.id ? { ...v, history: [...v.history, action.entry], updatedAt: new Date().toISOString() } : v);
      return { ...state, videos };
    }
    case 'ADD_COMMENT': {
      const videos = state.videos.map(v => v.id === action.videoId ? { ...v, comments: [...v.comments, action.comment] } : v);
      return { ...state, videos };
    }
    case 'ADD_VIDEO': {
      return { ...state, videos: [action.video, ...state.videos] };
    }
    case 'PUSH_NOTIFICATIONS': {
      return { ...state, notifications: [...action.notifications, ...state.notifications] };
    }
    case 'MARK_NOTIFICATIONS_READ': {
      const ids = new Set(action.ids);
      return { ...state, notifications: state.notifications.map(n => ids.has(n.id) ? { ...n, read: true } : n) };
    }
    case 'MARK_ALL_READ': {
      return { ...state, notifications: state.notifications.map(n => n.for === action.userId ? { ...n, read: true } : n) };
    }
    case 'PUSH_TOAST': {
      return { ...state, toasts: [...state.toasts, action.toast] };
    }
    case 'DISMISS_TOAST': {
      return { ...state, toasts: state.toasts.filter(t => t.id !== action.id) };
    }
    case 'RESET': {
      const videos = SEED_VIDEOS.map(v => ({
        ...v,
        comments: SEED_COMMENTS[v.id] || [],
        history: _buildHistory(v),
        versions: _buildVersions(v),
        classification: _classifyVideo(v),
      }));
      return { ...state, users: USERS.map(u => ({ ...u })), videos, auditLog: _buildSeedAudit(videos), notifications: INITIAL_NOTIFICATIONS, toasts: [] };
    }
    case 'USER_ADD': {
      return { ...state, users: [...state.users, action.user] };
    }
    case 'USER_UPDATE': {
      return { ...state, users: state.users.map(u => u.id === action.id ? { ...u, ...action.patch } : u) };
    }
    case 'USER_DELETE': {
      return { ...state, users: state.users.filter(u => u.id !== action.id) };
    }
    default: return state;
  }
}

function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, undefined, loadInitialState);

  useEffect(() => {
    try {
      const { toasts, ...persist } = state;
      localStorage.setItem(LS_KEY, JSON.stringify(persist));
    } catch (e) {}
  }, [state]);

  // Clear auth tokens whenever the user is signed out (and revoke server session in HTTP mode).
  const _wasAuthed = useRef(false);
  useEffect(() => {
    if (state.currentUserId) {
      _wasAuthed.current = true;
    } else {
      try {
        localStorage.removeItem('clinicast.access_token');
        localStorage.removeItem('clinicast.refresh_token');
      } catch (e) {}
      if (_wasAuthed.current && httpMode && window.api?.logout) {
        window.api.logout();   // revoke refresh token server-side
      }
      _wasAuthed.current = false;
    }
  }, [state.currentUserId]);

  const currentUser = useMemo(
    () => state.users.find(u => u.id === state.currentUserId) || null,
    [state.currentUserId, state.users]
  );

  // ------- Audit log helper -------
  const logAudit = useCallback((action, opts = {}) => {
    const entry = {
      id: 'aud_' + Math.random().toString(36).slice(2, 10),
      at: new Date().toISOString(),
      actor: currentUser?.name || opts.actor || 'Anonymous',
      actorId: currentUser?.id,
      sessionId: state.session?.sessionId,
      sourceIp: state.session?.sourceIp || '0.0.0.0',
      userAgent: state.session?.userAgent || 'Unknown',
      action,
      outcome: opts.outcome || 'success',
      resourceType: opts.resourceType || 'system',
      resourceId: opts.resourceId,
      resourceLabel: opts.resourceLabel,
      metadata: opts.metadata,
    };
    dispatch({ type:'AUDIT_APPEND', entry });
  }, [currentUser, state.session]);

  // ------- Helpers -------
  const toast = useCallback((opts) => {
    const t = { id: 'tst_' + Math.random().toString(36).slice(2), tone: 'success', duration: 3500, ...opts };
    dispatch({ type: 'PUSH_TOAST', toast: t });
    setTimeout(() => dispatch({ type: 'DISMISS_TOAST', id: t.id }), t.duration);
  }, []);

  const navigate = useCallback((route) => dispatch({ type:'NAVIGATE', route }), []);

  const notify = useCallback((targets) => {
    const now = new Date().toISOString();
    const list = (Array.isArray(targets) ? targets : [targets]).map(t => ({
      id: 'n_' + Math.random().toString(36).slice(2),
      at: now, read: false, ...t,
    }));
    dispatch({ type:'PUSH_NOTIFICATIONS', notifications: list });
  }, []);

  const appendHistory = useCallback((id, entry) => dispatch({ type:'APPEND_HISTORY', id, entry: { ...entry, at: new Date().toISOString() } }), []);

  // ------- Workflow Actions -------
  const moveVideo = useCallback((id, nextStatus, extra = {}) => {
    dispatch({ type:'UPDATE_VIDEO', id, patch: { status: nextStatus, ...extra } });
  }, []);

  const completeEditing = useCallback((video, versionMeta) => {
    // Append the editor's uploaded cut as a new version.
    const editCount = (video.versions || []).filter(x => x.kind === 'edit').length;
    const newVersion = {
      id: 'ver_' + Math.random().toString(36).slice(2, 8),
      kind: 'edit',
      label: `Edited cut · v${editCount + 1}`,
      fileName: versionMeta?.fileName || `${video.id}_edit_v${editCount + 1}.mp4`,
      sizeMB: versionMeta?.sizeMB || Math.round(video.duration * 6.5 / 10) / 10,
      by: currentUser.id,
      at: new Date().toISOString(),
      notes: versionMeta?.notes || 'Color graded · Lower thirds · Captions baked in',
    };
    dispatch({ type:'UPDATE_VIDEO', id: video.id, patch: {
      status: 'WRITING',
      versions: [...(video.versions || []), newVersion],
    }});
    appendHistory(video.id, { action:'EDITED', actor: currentUser?.name || 'Editor', label: `uploaded edited cut · v${editCount + 1}` });
    logAudit('VIDEO_VERSION_UPLOAD', { resourceType:'video', resourceId: video.id, resourceLabel: video.title, metadata: { versionId: newVersion.id, sizeMB: newVersion.sizeMB } });
    if (video.writer) {
      notify({ for: video.writer, type:'ASSIGNED', text:`"${video.title}" is ready for captions`, videoId: video.id });
    }
    toast({ tone:'success', title:'Edited cut uploaded', message:`"${video.title}" moved to Writing.` });
    return newVersion;
  }, [currentUser, appendHistory, notify, toast]);

  // Add another edited version WITHOUT changing the workflow status.
  // Used for V2, V3 revisions the editor uploads after the initial handoff.
  const addVersion = useCallback((video, versionMeta) => {
    const editCount = (video.versions || []).filter(x => x.kind === 'edit').length;
    const newVersion = {
      id: 'ver_' + Math.random().toString(36).slice(2, 8),
      kind: 'edit',
      label: `Edited cut · v${editCount + 1}`,
      fileName: versionMeta?.fileName || `${video.id}_edit_v${editCount + 1}.mp4`,
      sizeMB: versionMeta?.sizeMB || Math.round(video.duration * 6.5 / 10) / 10,
      by: currentUser.id,
      at: new Date().toISOString(),
      notes: versionMeta?.notes || 'Revision',
    };
    dispatch({ type:'UPDATE_VIDEO', id: video.id, patch: {
      versions: [...(video.versions || []), newVersion],
    }});
    appendHistory(video.id, { action:'EDITED', actor: currentUser?.name || 'Editor', label: `uploaded new version · v${editCount + 1}` });
    logAudit('VIDEO_VERSION_UPLOAD', { resourceType:'video', resourceId: video.id, resourceLabel: video.title, metadata: { versionId: newVersion.id, sizeMB: newVersion.sizeMB, revision: true } });
    // Let downstream owners know a newer cut exists.
    const target = video.writer || video.peerApprover || video.finalApprover;
    if (target && target !== currentUser.id) {
      notify({ for: target, type:'ASSIGNED', text:`New cut (v${editCount + 1}) uploaded for "${video.title}"`, videoId: video.id });
    }
    toast({ tone:'success', title:`Version v${editCount + 1} uploaded`, message:`Added to "${video.title}" version history.` });
    return newVersion;
  }, [currentUser, appendHistory, notify, toast, logAudit]);

  const submitForReview = useCallback((video, patch) => {
    const peerApprover = video.peerApprover || 'a1';
    dispatch({ type:'UPDATE_VIDEO', id: video.id, patch: { status:'PEER_REVIEW', peerApprover, ...patch } });
    appendHistory(video.id, { action:'WRITTEN', actor: currentUser?.name || 'Writer', label:'submitted captions for peer review' });
    const reviewer = state.users.find(u => u.id === peerApprover);
    notify({ for: peerApprover, type:'PEER_REVIEW', text:`"${video.title}" is awaiting your peer review`, videoId: video.id });
    toast({ tone:'success', title:'Submitted for peer review', message:`"${video.title}" sent to ${reviewer?.name || 'Stage 1'}.` });
  }, [currentUser, appendHistory, notify, toast]);

  // Stage 1: peer review approves → advances to FINAL_REVIEW.
  const peerApprove = useCallback((video) => {
    const finalApprover = video.finalApprover || 'a2';
    dispatch({ type:'UPDATE_VIDEO', id: video.id, patch: { status: 'FINAL_REVIEW', finalApprover } });
    appendHistory(video.id, { action:'PEER_APPROVED', actor: currentUser?.name || 'Reviewer', label:'cleared peer review (Stage 1)' });
    logAudit('PEER_APPROVE', { resourceType:'video', resourceId: video.id, resourceLabel: video.title, metadata: { stage: 1 } });
    const final = state.users.find(u => u.id === finalApprover);
    notify({ for: finalApprover, type:'FINAL_REVIEW', text:`"${video.title}" is awaiting final approval (Stage 2)`, videoId: video.id });
    notify({ for: video.uploader, type:'PEER_APPROVED', text:`"${video.title}" cleared peer review — now with ${final?.name || 'Stage 2'}`, videoId: video.id });
    toast({ tone:'success', title:'Peer review cleared', message:`Routed to ${final?.name || 'Stage 2'} for final approval.` });
  }, [currentUser, appendHistory, notify, toast]);

  // Stage 2: final approval → APPROVED, social can publish.
  const finalApprove = useCallback((video) => {
    const social = video.social || 's1';
    dispatch({ type:'UPDATE_VIDEO', id: video.id, patch: { status: 'APPROVED', social } });
    appendHistory(video.id, { action:'FINAL_APPROVED', actor: currentUser?.name || 'Approver', label:'final approval — cleared for publishing (Stage 2)' });
    logAudit('FINAL_APPROVE', { resourceType:'video', resourceId: video.id, resourceLabel: video.title, metadata: { stage: 2 } });
    notify([
      { for: social, type:'APPROVED', text:`"${video.title}" has cleared final approval — ready to publish`, videoId: video.id },
      { for: video.uploader, type:'APPROVED', text:`Your video "${video.title}" has cleared both review stages`, videoId: video.id },
      ...(video.peerApprover ? [{ for: video.peerApprover, type:'APPROVED', text:`Final approval granted on "${video.title}"`, videoId: video.id }] : []),
    ]);
    toast({ tone:'success', title:'Approved', message:`"${video.title}" is ready for publishing.` });
  }, [currentUser, appendHistory, notify, toast]);

  // Generic reject with target assignee + reason. Routes to the right status based on assignee role/tier.
  const sendBack = useCallback((video, { toUserId, reason, fromStage }) => {
    const target = state.users.find(u => u.id === toUserId);
    if (!target) return;
    let nextStatus = 'EDITING';
    const patch = { reasons: [...(video.reasons||[]), { reason, by: currentUser?.name, fromStage, toUserId, at: new Date().toISOString() }] };
    if (target.role === 'EDITOR') {
      nextStatus = 'EDITING';
      patch.editor = toUserId;
    } else if (target.role === 'WRITER') {
      nextStatus = 'WRITING';
      patch.writer = toUserId;
    } else if (target.role === 'APPROVER' && target.tier === 'peer') {
      nextStatus = 'PEER_REVIEW';
      patch.peerApprover = toUserId;
    }
    patch.status = nextStatus;
    dispatch({ type:'UPDATE_VIDEO', id: video.id, patch });
    appendHistory(video.id, { action:'REJECTED', actor: currentUser?.name || 'Reviewer', label:`sent back to ${target.name} (${ROLES[target.role].label}${target.tier?` · ${APPROVER_TIERS[target.tier].short}`:''}) — ${reason}` });
    notify({ for: toUserId, type:'REJECTED', text:`"${video.title}" needs changes: ${reason}`, videoId: video.id });
    if (video.uploader !== currentUser?.id) {
      notify({ for: video.uploader, type:'REJECTED', text:`Changes requested on "${video.title}"`, videoId: video.id });
    }
    toast({ tone:'warn', title:'Sent back', message:`Routed to ${target.name}.` });
  }, [currentUser, appendHistory, notify, toast]);

  const publishVideo = useCallback((video, platforms) => {
    dispatch({ type:'UPDATE_VIDEO', id: video.id, patch: { status:'PUBLISHED', platforms, classification:'PUBLIC' } });
    appendHistory(video.id, { action:'PUBLISHED', actor: currentUser?.name || 'Social', label:`published to ${platforms.join(', ')}` });
    logAudit('PUBLISH', { resourceType:'video', resourceId: video.id, resourceLabel: video.title, metadata: { platforms } });
    notify({ for: video.uploader, type:'PUBLISHED', text:`"${video.title}" went live on ${platforms.join(', ')}`, videoId: video.id });
    toast({ tone:'success', title:'Published 🎉', message:`Live on ${platforms.join(', ')}.` });
  }, [currentUser, appendHistory, notify, toast]);

  const addComment = useCallback((videoId, text) => {
    if (!text.trim() || !currentUser) return;
    const comment = { id:'c_'+Math.random().toString(36).slice(2), author: currentUser.id, text: text.trim(), at: new Date().toISOString() };
    dispatch({ type:'ADD_COMMENT', videoId, comment });
    // Notify uploader if not self
    const video = state.videos.find(v => v.id === videoId);
    if (video && video.uploader !== currentUser.id) {
      notify({ for: video.uploader, type:'COMMENT', text:`${currentUser.name} commented on "${video.title}"`, videoId });
    }
  }, [currentUser, notify, state.videos]);

  const uploadVideo = useCallback((draft) => {
    const id = 'v_' + Math.random().toString(36).slice(2, 8);
    const editor = 'e' + (Math.random() < 0.5 ? 1 : 2);
    const slug = draft.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 32);
    const now = new Date().toISOString();
    const rawVersion = {
      id: id + '_raw',
      kind: 'raw',
      label: 'Original recording',
      fileName: draft.fileName || `${slug || 'recording'}_raw.mov`,
      sizeMB: Math.round((draft.duration || 240) * 28 / 10) / 10,
      by: currentUser.id,
      at: now,
      notes: 'Studio capture · ProRes 422 · 4K 24p',
    };
    const video = {
      id, title: draft.title, description: draft.description || 'New video upload.',
      status: 'EDITING', thumb: Math.floor(Math.random()*6), duration: draft.duration || 240,
      uploader: currentUser.id, editor, writer: null, approver: null, social: null,
      createdAt: now, updatedAt: now,
      captions:'', hashtags:[], platforms:[], reasons:[],
      comments: [], versions: [rawVersion],
      classification: 'INTERNAL',
      history: [
        { action:'CREATED',  actor: currentUser.name, label:`uploaded "${draft.title}"`, at: now },
        { action:'ASSIGNED', actor:'Workflow Bot', label:`assigned to editor ${state.users.find(u=>u.id===editor)?.name || 'editor'}`, at: now },
      ],
    };
    dispatch({ type:'ADD_VIDEO', video });
    logAudit('VIDEO_UPLOAD', { resourceType:'video', resourceId: id, resourceLabel: draft.title, metadata: { classification: video.classification, sizeMB: rawVersion.sizeMB } });
    notify({ for: editor, type:'ASSIGNED', text:`You were assigned to edit "${draft.title}"`, videoId: id });
    toast({ tone:'success', title:'Upload complete', message:`"${draft.title}" routed to editing.` });
    return video;
  }, [currentUser, notify, toast]);

  const userById = useCallback(
    (id) => state.users.find(u => u.id === id) || null,
    [state.users]
  );

  // ------- Admin / user management -------
  const createUser = useCallback((draft) => {
    const prefix = ({ DOCTOR:'d', EDITOR:'e', WRITER:'w', APPROVER:'a', SOCIAL:'s', ADMIN:'ad' })[draft.role] || 'u';
    const id = prefix + Math.random().toString(36).slice(2, 6);
    const initials = draft.name.split(' ').filter(Boolean).map(s => s[0]).join('').slice(0,2).toUpperCase() || '??';
    const tone = `thumb-grad-${Math.floor(Math.random() * 6)}`;
    const user = {
      id, initials, tone, active: true,
      name: draft.name.trim(),
      role: draft.role,
      tier: draft.role === 'APPROVER' ? (draft.tier || 'peer') : undefined,
      specialty: draft.specialty?.trim() || ROLES[draft.role].label,
      email: draft.email.trim().toLowerCase(),
      phone: draft.phone.trim(),
    };
    dispatch({ type: 'USER_ADD', user });
    if (window.Auth) window.Auth.registerUser(user.email, window.Auth.DEFAULT_PASSWORD);
    toast({ tone:'success', title:'User added', message:`${user.name} can now sign in as ${ROLES[user.role].label}.` });
    return user;
  }, [toast]);

  const updateUser = useCallback((id, patch) => {
    dispatch({ type: 'USER_UPDATE', id, patch });
    toast({ tone:'success', title:'User updated', message:'Changes saved.' });
  }, [toast]);

  const deleteUser = useCallback((id) => {
    const u = state.users.find(x => x.id === id);
    if (!u) return;
    // Don't delete if user has assignments; just deactivate.
    const assigned = state.videos.some(v =>
      [v.uploader, v.editor, v.writer, v.peerApprover, v.finalApprover, v.social].includes(id)
    );
    if (assigned) {
      dispatch({ type: 'USER_UPDATE', id, patch: { active: false } });
      toast({ tone:'warn', title:'User deactivated', message:`${u.name} has open assignments — deactivated instead of deleted.` });
      return;
    }
    dispatch({ type: 'USER_DELETE', id });
    if (window.Auth && u.email) window.Auth.removeUser(u.email);
    toast({ tone:'success', title:'User deleted', message:`${u.name} was removed.` });
  }, [state.users, state.videos, toast]);

  // ===========================================================================
  // BACKEND WIRING
  // When window.api.mode === 'http' (set via window.clinicast.setMode('http', url)),
  // every mutation routes through the REST API instead of localStorage, and the
  // UI re-hydrates from the server (the source of truth). In 'local' mode the
  // original in-browser logic below runs unchanged.
  // ===========================================================================
  const httpMode = typeof window !== 'undefined' && window.api && window.api.mode === 'http';

  const syncFromServer = useCallback(async () => {
    if (!httpMode) return;
    try {
      const [videos, users, notifications] = await Promise.all([
        window.api.listVideos(),
        window.api.listUsers(),
        window.api.listNotifications(),
      ]);
      const data = {};
      if (Array.isArray(videos)) data.videos = videos;
      if (Array.isArray(users)) data.users = users;
      if (Array.isArray(notifications)) data.notifications = notifications;
      dispatch({ type: 'HYDRATE', data });
    } catch (e) {
      toast({ tone: 'error', title: 'Sync failed', message: e.message || 'Could not reach the API.' });
    }
  }, [httpMode, toast]);

  // Wrap a local helper so it calls the backend (then re-syncs) when connected.
  const wrap = (local, remote) => async (...args) => {
    if (!httpMode) return local(...args);
    try {
      const result = await remote(...args);
      await syncFromServer();
      return result;
    } catch (e) {
      toast({ tone: 'error', title: 'Action failed', message: e.message || 'Server rejected the request.' });
      throw e;
    }
  };

  // Hydrate real data from the backend whenever we're connected + signed in.
  useEffect(() => {
    if (httpMode && state.currentUserId) syncFromServer();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [httpMode, state.currentUserId]);

  // ---------------------------------------------------------------------------
  // REAL FILE UPLOAD ORCHESTRATION
  // PUTs the actual file bytes straight to S3 via a presigned URL, with a real
  // progress callback driven by upload progress (XHR — fetch can't report it).
  // In local/demo mode there's no backend, so we simulate the same progress
  // curve and record the picked file's real name/size as metadata.
  // ---------------------------------------------------------------------------
  function putToStorage(url, file, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('PUT', url);
      if (file.type) xhr.setRequestHeader('Content-Type', file.type);
      xhr.upload.onprogress = (e) => { if (e.lengthComputable && onProgress) onProgress((e.loaded / e.total) * 100); };
      xhr.onload = () => (xhr.status >= 200 && xhr.status < 300)
        ? resolve()
        : reject(new Error(`S3 rejected the upload (HTTP ${xhr.status}). Check the bucket policy / region.`));
      xhr.onerror = () => reject(new Error('Upload network error — usually a missing bucket CORS rule for this origin.'));
      xhr.ontimeout = () => reject(new Error('Upload timed out.'));
      xhr.send(file);
    });
  }
  function simulateProgress(onProgress, ms) {
    return new Promise((resolve) => {
      const t0 = Date.now();
      const tick = () => {
        const p = Math.min(100, ((Date.now() - t0) / ms) * 100);
        onProgress && onProgress(p);
        if (p < 100) requestAnimationFrame(tick); else resolve();
      };
      requestAnimationFrame(tick);
    });
  }

  // Doctor: create the video record, then upload the raw recording to S3.
  const uploadDoctorVideo = async ({ draft, file, onProgress }) => {
    if (!httpMode) {
      await simulateProgress(onProgress, 2600);
      return uploadVideo({ ...draft, fileName: file?.name, sizeMB: file ? Math.round(file.size / 1e5) / 10 : undefined });
    }
    try {
      const video = await window.api.createVideo(draft);
      const { url, key, bucket } = await window.api.requestUploadUrl(video.id, 'raw', file.name, file.size, file.type || 'video/mp4');
      await putToStorage(url, file, onProgress);
      await window.api.finalizeVersion(video.id, {
        kind: 'raw', label: 'Original recording', fileName: file.name,
        storageKey: key, storageBucket: bucket, sizeBytes: file.size, mime: file.type || 'video/mp4',
        notes: 'Original upload',
      });
      await syncFromServer();
      return video;
    } catch (e) {
      toast({ tone: 'error', title: 'Upload failed', message: e.message });
      throw e;
    }
  };

  // Editor: upload an edited cut to S3, finalize the version, then (for a
  // first handoff) advance the workflow to WRITING.
  const uploadEditedCut = async ({ video, file, notes, isRevision, onProgress }) => {
    if (!httpMode) {
      await simulateProgress(onProgress, 2200);
      const meta = { fileName: file?.name, sizeMB: file ? Math.round(file.size / 1e5) / 10 : undefined, notes };
      return isRevision ? addVersion(video, meta) : completeEditing(video, meta);
    }
    try {
      const { url, key, bucket } = await window.api.requestUploadUrl(video.id, 'edit', file.name, file.size, file.type || 'video/mp4');
      await putToStorage(url, file, onProgress);
      await window.api.finalizeVersion(video.id, {
        kind: 'edit', label: notes || 'Edited cut', fileName: file.name,
        storageKey: key, storageBucket: bucket, sizeBytes: file.size, mime: file.type || 'video/mp4', notes,
      });
      if (!isRevision) await window.api.completeEditing(video.id, { notes });
      await syncFromServer();
    } catch (e) {
      toast({ tone: 'error', title: 'Upload failed', message: e.message });
      throw e;
    }
  };

  const value = {
    ...state, dispatch, currentUser, userById,
    toast, notify, navigate, appendHistory, moveVideo, logAudit,
    httpMode, syncFromServer,
    uploadDoctorVideo, uploadEditedCut,
    // Mutations — local in demo mode, REST calls against SQL/S3 in HTTP mode.
    completeEditing: wrap(completeEditing, (video, meta) => window.api.completeEditing(video.id, meta)),
    addVersion:      wrap(addVersion,      (video, meta) => window.api.finalizeVersion(video.id, { kind: 'edit', ...meta })),
    submitForReview: wrap(submitForReview, (video, patch) => window.api.submitForReview(video.id, patch)),
    peerApprove:     wrap(peerApprove,     (video) => window.api.peerApprove(video.id)),
    finalApprove:    wrap(finalApprove,    (video) => window.api.finalApprove(video.id)),
    sendBack:        wrap(sendBack,        (video, payload) => window.api.sendBack(video.id, payload)),
    publishVideo:    wrap(publishVideo,    (video, platforms) => window.api.publish(video.id, { platforms })),
    addComment:      wrap(addComment,      (videoId, text) => window.api.createComment(videoId, text)),
    uploadVideo:     wrap(uploadVideo,     (draft) => window.api.createVideo(draft)),
    createUser:      wrap(createUser,      (draft) => window.api.createUser(draft)),
    updateUser:      wrap(updateUser,      (id, patch) => window.api.updateUser(id, patch)),
    deleteUser:      wrap(deleteUser,      (id) => window.api.deleteUser(id)),
  };

  // Bind the LocalAdapter so window.api.* delegates to the live reducer + helpers (local mode only).
  useEffect(() => {
    if (typeof window !== 'undefined' && window.api && window.api.__bind) {
      window.api.__bind({
        dispatch,
        getState: () => state,
        helpers: {
          createUser, updateUser, deleteUser,
          uploadVideo, completeEditing, submitForReview,
          peerApprove, finalApprove, sendBack, publishVideo,
          addComment,
        },
      });
    }
  });
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

// ---------------------------------------------------------------------------
// Formatters
// ---------------------------------------------------------------------------
function formatDuration(sec) {
  const m = Math.floor(sec/60); const s = sec%60;
  return `${m}:${String(s).padStart(2,'0')}`;
}
function timeAgo(iso) {
  const now = new Date('2026-05-23T14:30:00Z').getTime();
  const t = new Date(iso).getTime();
  const diff = Math.max(0, now - t);
  const m = Math.floor(diff/60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m/60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h/24);
  if (d < 7) return `${d}d ago`;
  return new Date(iso).toLocaleDateString('en-US', { month:'short', day:'numeric' });
}
function formatDate(iso) {
  return new Date(iso).toLocaleString('en-US', { month:'short', day:'numeric', hour:'numeric', minute:'2-digit' });
}

Object.assign(window, {
  STATUS, STATUS_ORDER, ROLES, ASSIGNABLE_ROLES, APPROVER_TIERS, USERS,
  CLASSIFICATIONS, retentionRemaining, SESSION_TTL_MIN,
  AppContext, AppProvider, useApp,
  formatDuration, timeAgo, formatDate, defaultVersionId,
});
