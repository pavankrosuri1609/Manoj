// ============================================================================
// Login screen — role + user picker, with separate Admin sign-in tab.
// ============================================================================
function LoginScreen() {
  const { dispatch, toast, users, httpMode } = useApp();
  const [mode, setMode] = React.useState('team');  // 'team' | 'admin' | 'forgot' | 'reset'
  const [role, setRole] = React.useState('DOCTOR');
  const [pickedId, setPickedId] = React.useState('d1');
  const [pending, setPending] = React.useState(false);
  const [teamPassword, setTeamPassword] = React.useState('demo1234');
  const [teamError, setTeamError] = React.useState('');
  const [adminEmail, setAdminEmail] = React.useState('sarah.mitchell@drmanojhomeopathy.com');
  const [adminPassword, setAdminPassword] = React.useState('');
  const [adminError, setAdminError] = React.useState('');
  const [resetCtx, setResetCtx] = React.useState(null); // { token, email } for the reset screen

  // Production sign-in (email + password for any role). Used when connected to
  // the backend — the server determines the user's role from the SQL record.
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [signInError, setSignInError] = React.useState('');
  const signIn = async () => {
    setSignInError('');
    if (!email.trim() || !password) { setSignInError('Email and password are required.'); return; }
    setPending(true);
    try {
      const user = await window.api.login({ email: email.trim(), password });
      dispatch({ type:'LOGIN', userId: user.id });
      toast({ tone:'success', title:`Welcome, ${(user.name||'').split(' ')[0]}`, message:`Signed in as ${ROLES[user.role]?.label || user.role}.` });
    } catch (e) {
      setSignInError(e.message || 'Sign-in failed. Check your email and password.');
    } finally { setPending(false); }
  };

  // Seed real (hashed) credentials for every known account, once.
  React.useEffect(() => {
    if (window.Auth && users?.length) {
      window.Auth.ensureSeeded(users.map(u => u.email).filter(Boolean));
    }
  }, [users]);

  const usersInRole = (users || []).filter(u => u.role === role && u.active !== false);
  React.useEffect(() => {
    if (!usersInRole.find(u => u.id === pickedId)) {
      setPickedId(usersInRole[0]?.id || '');
    }
  }, [role, users]);

  // Persist tokens + hand the verified userId to the app reducer.
  const finishLogin = (email, session) => {
    const u = (users || []).find(x => x.email?.toLowerCase() === email.toLowerCase());
    if (!u) return;
    try {
      localStorage.setItem('clinicast.access_token', session.accessToken);
      localStorage.setItem('clinicast.refresh_token', session.refreshToken);
    } catch (e) {}
    dispatch({ type:'LOGIN', userId: u.id });
    toast({ tone:'success', title:`Welcome, ${u.name.split(' ')[0]}`, message:`Signed in as ${ROLES[u.role].label}.` });
  };

  const signInTeam = async () => {
    setTeamError('');
    const u = usersInRole.find(x => x.id === pickedId);
    if (!u) { setTeamError('Select a user to continue.'); return; }
    setPending(true);
    try {
      if (httpMode) {
        // Real backend auth — verifies against the SQL users table, issues a JWT.
        const user = await window.api.login({ email: u.email, password: teamPassword });
        dispatch({ type:'LOGIN', userId: user?.id || u.id });
        toast({ tone:'success', title:`Welcome, ${(user?.name || u.name).split(' ')[0]}`, message:`Signed in as ${ROLES[u.role].label}.` });
      } else {
        const session = await window.Auth.login(u.email, teamPassword);
        finishLogin(u.email, session);
      }
    } catch (e) {
      setTeamError(e.message || 'Sign-in failed.');
    } finally { setPending(false); }
  };

  const signInAdmin = async () => {
    setAdminError('');
    const match = (users || []).find(u => u.role === 'ADMIN' && u.email.toLowerCase() === adminEmail.trim().toLowerCase() && u.active !== false);
    if (!httpMode && !match) { setAdminError('No active administrator with that email.'); return; }
    if (!adminPassword.trim()) { setAdminError('Password is required.'); return; }
    setPending(true);
    try {
      if (httpMode) {
        // Real backend auth. The server enforces the ADMIN role server-side.
        const user = await window.api.login({ email: adminEmail.trim(), password: adminPassword });
        if (user && user.role !== 'ADMIN') { setAdminError('That account is not an administrator.'); setPending(false); return; }
        dispatch({ type:'LOGIN', userId: user?.id || match?.id });
        toast({ tone:'success', title:`Welcome, ${(user?.name || match?.name || 'Admin').split(' ')[0]}`, message:'Signed in as Administrator.' });
      } else {
        const session = await window.Auth.login(adminEmail.trim(), adminPassword);
        finishLogin(adminEmail.trim(), session);
      }
    } catch (e) {
      setAdminError(e.message || 'Sign-in failed.');
    } finally { setPending(false); }
  };

  const goReset = (token, email) => { setResetCtx({ token, email }); setMode('reset'); };

  return (
    <div className="min-h-screen w-full grid lg:grid-cols-[1fr_1fr]">
      {/* Left — brand panel */}
      <div className="relative hidden lg:flex flex-col justify-between p-12 bg-ink-900 text-white overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-[0.06]"></div>
        <div className="absolute -right-32 -top-32 w-[480px] h-[480px] rounded-full bg-brand-500/20 blur-3xl"></div>
        <div className="absolute -left-32 bottom-0 w-[420px] h-[420px] rounded-full bg-brand-700/30 blur-3xl"></div>

        <div className="relative z-10 flex items-center gap-2.5">
          <Logo size={34} variant="light"/>
          <span className="font-serif font-semibold text-[19px] tracking-tight leading-none">Dr. Manoj's <span className="text-brand-300">Homeopathy</span></span>
        </div>

        <div className="relative z-10 max-w-md">
          <div className="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-widest text-brand-300 bg-white/5 border border-white/10 rounded-full px-3 py-1 mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-400 pulse-ring"></span>
            Care Content Workflow
          </div>
          <h1 className="font-serif text-[44px] leading-[1.06] font-bold tracking-tight">
            Trusted homeopathic care,<br/>
            <span className="text-brand-300">shared through the right hands.</span>
          </h1>
          <p className="text-ink-300 mt-5 text-[15px] leading-relaxed max-w-sm">
            From the consultation room to the feed — every patient-education clip moves through editing, scripting, clinical review and publishing in one continuous, auditable workflow.
          </p>

          <div className="mt-10 grid grid-cols-2 gap-3 max-w-sm">
            <StatCard label="Avg. cycle" value="48h" hint="Upload → publish"/>
            <StatCard label="Since" value="1992" hint="Banjara Hills, Hyderabad"/>
            <StatCard label="Patients" value="1.2M+" hint="Treated holistically"/>
            <StatCard label="Review" value="100%" hint="Clinically verified"/>
          </div>
        </div>

        <div className="relative z-10 text-[12px] text-ink-400">
          © 2026 Dr. Manoj's Homeopathy · Holistic care content, reviewed and published with care.
        </div>
      </div>

      {/* Right — sign-in card */}
      <div className="flex items-center justify-center p-6 lg:p-12 bg-ink-50">
        <div className="w-full max-w-[460px] anim-slide-up">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <Logo size={30}/>
            <span className="font-serif font-semibold text-[18px] tracking-tight">Dr. Manoj's Homeopathy</span>
          </div>

          {/* PRODUCTION: a single email + password sign-in for every role. */}
          {httpMode && (mode === 'team' || mode === 'admin') && (
            <ProductionSignIn
              email={email} setEmail={setEmail}
              password={password} setPassword={setPassword}
              error={signInError} pending={pending}
              onSubmit={signIn} onForgot={() => setMode('forgot')}
            />
          )}

          {/* DEMO: role + account picker tabs (in-browser preview only). */}
          {!httpMode && (mode === 'team' || mode === 'admin') && (
            <div className="inline-flex p-1 bg-white border border-ink-200 rounded-xl mb-6">
              <button onClick={() => setMode('team')} className={`flex items-center gap-2 px-3.5 h-9 rounded-lg text-[13px] font-semibold transition ${mode==='team'?'bg-ink-900 text-white shadow-card':'text-ink-600 hover:text-ink-900'}`}>
                <Icon name="users" size={14}/> Team sign-in
              </button>
              <button onClick={() => setMode('admin')} className={`flex items-center gap-2 px-3.5 h-9 rounded-lg text-[13px] font-semibold transition ${mode==='admin'?'bg-ink-900 text-white shadow-card':'text-ink-600 hover:text-ink-900'}`}>
                <Icon name="shield" size={14}/> Administrator
              </button>
            </div>
          )}

          {!httpMode && mode === 'team' && (
            <TeamSignIn
              role={role} setRole={setRole}
              pickedId={pickedId} setPickedId={setPickedId}
              usersInRole={usersInRole}
              password={teamPassword} setPassword={setTeamPassword}
              error={teamError}
              pending={pending}
              onSubmit={signInTeam}
              onForgot={() => setMode('forgot')}
            />
          )}

          {!httpMode && mode === 'admin' && (
            <AdminSignIn
              email={adminEmail} setEmail={setAdminEmail}
              password={adminPassword} setPassword={setAdminPassword}
              error={adminError}
              pending={pending}
              onSubmit={signInAdmin}
              onForgot={() => setMode('forgot')}
              users={users}
            />
          )}

          {mode === 'forgot' && (
            <ForgotPassword
              users={users}
              httpMode={httpMode}
              onBack={() => setMode(httpMode ? 'team' : 'team')}
              onProceedToReset={goReset}
              toast={toast}
            />
          )}

          {mode === 'reset' && (
            <ResetPassword
              ctx={resetCtx}
              onDone={() => { setMode('team'); setResetCtx(null); }}
              toast={toast}
            />
          )}

          <div className="mt-5 text-center text-[11.5px] text-ink-400">
            {httpMode
              ? 'Secured with JWT access tokens · PBKDF2-hashed passwords'
              : 'Real JWT auth · PBKDF2-hashed passwords · Preview store in your browser'}
          </div>
        </div>
      </div>
    </div>
  );
}

function ProductionSignIn({ email, setEmail, password, setPassword, error, pending, onSubmit, onForgot }) {
  return (
    <div>
      <h2 className="text-2xl font-bold text-ink-900 tracking-tight">Sign in</h2>
      <p className="text-ink-500 text-sm mt-1">Enter your work email and password to continue.</p>

      <form onSubmit={(e) => { e.preventDefault(); onSubmit(); }} className="space-y-4 mt-6">
        <Field label="Email" required>
          <div className="relative">
            <Icon name="mail" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
            <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="name@drmanojhomeopathy.com" className="pl-9" type="email" autoFocus/>
          </div>
        </Field>
        <Field label="Password" required>
          <div className="relative">
            <Icon name="lock" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
            <Input value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="pl-9" type="password"/>
          </div>
        </Field>

        {error && (
          <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 flex gap-2 text-[12.5px] text-rose-700">
            <Icon name="alert-circle" size={14} className="mt-0.5 flex-shrink-0"/>
            <span>{error}</span>
          </div>
        )}

        <div className="flex items-center justify-end text-[11.5px]">
          <button type="button" onClick={onForgot} className="font-semibold text-brand-600 hover:text-brand-700">Forgot password?</button>
        </div>

        <Button full size="lg" tone="brand" type="submit" disabled={pending} iconRight={pending?undefined:'arrow-right'}>
          {pending ? 'Signing in…' : 'Sign in'}
        </Button>
      </form>
    </div>
  );
}

function TeamSignIn({ role, setRole, pickedId, setPickedId, usersInRole, password, setPassword, error, pending, onSubmit, onForgot }) {
  // Only show roles a person picks themselves — ADMIN is via the Administrator tab.
  const teamRoles = ASSIGNABLE_ROLES.map(k => ROLES[k]);
  return (
    <div>
      <h2 className="text-2xl font-bold text-ink-900 tracking-tight">Sign in</h2>
      <p className="text-ink-500 text-sm mt-1">Pick your role and account, then sign in. State persists locally.</p>

      <div className="mt-6">
        <div className="text-[12px] font-semibold text-ink-700 mb-2">Choose your role</div>
        <div className="grid grid-cols-2 gap-2">
          {teamRoles.map(r => (
            <button key={r.key} onClick={() => setRole(r.key)}
              className={`text-left p-3 rounded-xl border-2 transition ${role===r.key?'border-brand-500 bg-brand-50/50':'border-ink-200 bg-white hover:border-ink-300'}`}>
              <div className="flex items-center gap-2">
                <RoleIcon role={r.key} active={role===r.key}/>
                <div className="font-semibold text-[13px] text-ink-900">{r.label}</div>
              </div>
              <div className="text-[11px] text-ink-500 mt-1 leading-snug">{r.desc}</div>
            </button>
          ))}
          <div className="p-3 rounded-xl border-2 border-dashed border-ink-200 flex items-center justify-center text-[11.5px] text-ink-400">
            <Icon name="users" size={14} className="mr-1.5"/>
            {usersInRole.length} member{usersInRole.length!==1?'s':''}
          </div>
        </div>
      </div>

      <div className="mt-5">
        <div className="text-[12px] font-semibold text-ink-700 mb-2">Account</div>
        <div className="flex flex-col gap-1.5 max-h-52 overflow-auto scroll-thin pr-1">
          {usersInRole.length === 0 && (
            <div className="text-[12.5px] text-ink-400 italic text-center py-4">No active users with this role.</div>
          )}
          {usersInRole.map(u => (
            <label key={u.id} className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition ${pickedId===u.id?'border-brand-500 bg-brand-50/40':'border-ink-200 bg-white hover:border-ink-300'}`}>
              <input type="radio" name="user" checked={pickedId===u.id} onChange={()=>setPickedId(u.id)} className="sr-only"/>
              <Avatar user={u} size={36}/>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-[13px] text-ink-900 truncate">{u.name}</div>
                <div className="text-[11.5px] text-ink-500 truncate font-mono">{u.email}</div>
              </div>
              <span className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${pickedId===u.id?'border-brand-500':'border-ink-300'}`}>
                {pickedId===u.id && <span className="w-1.5 h-1.5 bg-brand-500 rounded-full"></span>}
              </span>
            </label>
          ))}
        </div>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); onSubmit(); }} className="mt-4">
        <Field label="Password" required>
          <div className="relative">
            <Icon name="lock" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
            <Input value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="pl-9" type="password"/>
          </div>
        </Field>

        {error && (
          <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 flex gap-2 text-[12.5px] text-rose-700 mt-3">
            <Icon name="alert-circle" size={14} className="mt-0.5 flex-shrink-0"/>
            <span>{error}</span>
          </div>
        )}

        <div className="flex items-center justify-between text-[11.5px] mt-3">
          <span className="text-ink-400">Demo password: <code className="font-mono text-ink-600">demo1234</code></span>
          <button type="button" onClick={onForgot} className="font-semibold text-brand-600 hover:text-brand-700">Forgot password?</button>
        </div>

        <div className="mt-4">
          <Button full size="lg" tone="brand" type="submit" disabled={!pickedId||pending} iconRight={pending?undefined:'arrow-right'}>
            {pending ? 'Signing in…' : `Sign in as ${ROLES[role].label}`}
          </Button>
        </div>
      </form>
    </div>
  );
}

function AdminSignIn({ email, setEmail, password, setPassword, error, pending, onSubmit, onForgot, users }) {
  const admins = (users || []).filter(u => u.role === 'ADMIN');
  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <div className="w-9 h-9 rounded-xl bg-ink-900 text-white flex items-center justify-center">
          <Icon name="shield" size={16}/>
        </div>
        <div>
          <h2 className="text-2xl font-bold text-ink-900 tracking-tight leading-none">Administrator sign-in</h2>
          <p className="text-ink-500 text-[12.5px] mt-1">Privileged access — user management, roles, and platform settings.</p>
        </div>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); onSubmit(); }} className="space-y-4 mt-6">
        <Field label="Administrator email" required>
          <div className="relative">
            <Icon name="mail" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
            <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="admin@drmanojhomeopathy.com" className="pl-9" type="email"/>
          </div>
        </Field>
        <Field label="Password" required>
          <div className="relative">
            <Icon name="lock" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
            <Input value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="pl-9" type="password"/>
          </div>
        </Field>

        {error && (
          <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 flex gap-2 text-[12.5px] text-rose-700">
            <Icon name="alert-circle" size={14} className="mt-0.5 flex-shrink-0"/>
            <span>{error}</span>
          </div>
        )}

        <div className="flex items-center justify-between text-[11.5px] text-ink-500">
          <label className="flex items-center gap-2 cursor-pointer">
            <Checkbox checked={true} onChange={()=>{}}/>
            <span>Trust this device for 24h</span>
          </label>
          <button type="button" onClick={onForgot} className="font-semibold text-brand-600 hover:text-brand-700">Forgot password?</button>
        </div>

        <Button full size="lg" tone="primary" type="submit" disabled={pending} iconRight={pending?undefined:'arrow-right'}>
          {pending ? 'Signing in…' : 'Sign in as Administrator'}
        </Button>
      </form>

      {admins.length > 0 && (
        <div className="mt-5 bg-ink-100/70 border border-ink-200 rounded-xl p-3">
          <div className="text-[11px] uppercase tracking-widest font-bold text-ink-500 mb-2">Demo administrators · password <code className="font-mono">demo1234</code></div>
          <div className="flex flex-col gap-1.5">
            {admins.map(a => (
              <button key={a.id} type="button" onClick={() => setEmail(a.email)}
                className="flex items-center gap-2.5 text-left p-1.5 rounded-lg hover:bg-white transition">
                <Avatar user={a} size={26}/>
                <div className="flex-1 min-w-0">
                  <div className="text-[12.5px] font-semibold text-ink-900 truncate">{a.name}</div>
                  <div className="text-[11px] text-ink-500 truncate font-mono">{a.email}</div>
                </div>
                <Icon name="arrow-up-left" size={12} className="text-ink-400"/>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------------
// Forgot password — request a reset link (step 1)
// ----------------------------------------------------------------------------
function ForgotPassword({ users, httpMode, onBack, onProceedToReset, toast }) {
  const [email, setEmail] = React.useState('');
  const [pending, setPending] = React.useState(false);
  const [sent, setSent] = React.useState(false);
  const [devToken, setDevToken] = React.useState(null);

  // In production there is no client-side reset store; password resets are
  // administrator-initiated (see DEPLOYMENT.md). Show the right guidance.
  if (httpMode) {
    return (
      <div>
        <button onClick={onBack} className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-ink-500 hover:text-ink-900 mb-4">
          <Icon name="arrow-left" size={14}/> Back to sign in
        </button>
        <div className="flex items-center gap-2 mb-4">
          <div className="w-9 h-9 rounded-xl bg-ink-900 text-white flex items-center justify-center"><Icon name="key-round" size={16}/></div>
          <div>
            <h2 className="text-2xl font-bold text-ink-900 tracking-tight leading-none">Reset your password</h2>
            <p className="text-ink-500 text-[12.5px] mt-1">Password resets are handled by your administrator.</p>
          </div>
        </div>
        <div className="mt-6 bg-brand-50 border border-brand-200 rounded-xl p-4 flex gap-3">
          <Icon name="shield" size={18} className="text-brand-600 mt-0.5 flex-shrink-0"/>
          <div className="text-[13px] text-ink-700 leading-relaxed">
            Contact your practice administrator to reset your password. For security, resets are issued by an administrator rather than self-service email.
          </div>
        </div>
        <button onClick={onBack} className="w-full text-center text-[12.5px] font-semibold text-ink-500 hover:text-ink-900 mt-5">Back to sign in</button>
      </div>
    );
  }

  const submit = async () => {
    setPending(true);
    try {
      const res = await window.Auth.requestPasswordReset(email.trim());
      setSent(true);
      setDevToken(res.devToken); // in prod this is emailed, never shown
    } catch (e) {
      setSent(true); // same response regardless, to avoid user enumeration
    } finally { setPending(false); }
  };

  return (
    <div>
      <button onClick={onBack} className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-ink-500 hover:text-ink-900 mb-4">
        <Icon name="arrow-left" size={14}/> Back to sign in
      </button>
      <div className="flex items-center gap-2 mb-4">
        <div className="w-9 h-9 rounded-xl bg-ink-900 text-white flex items-center justify-center"><Icon name="key-round" size={16}/></div>
        <div>
          <h2 className="text-2xl font-bold text-ink-900 tracking-tight leading-none">Reset your password</h2>
          <p className="text-ink-500 text-[12.5px] mt-1">We'll send a secure, time-limited reset link to your email.</p>
        </div>
      </div>

      {!sent ? (
        <form onSubmit={(e) => { e.preventDefault(); submit(); }} className="space-y-4 mt-6">
          <Field label="Account email" required>
            <div className="relative">
              <Icon name="mail" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
              <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="name@drmanojhomeopathy.com" className="pl-9" type="email" autoFocus/>
            </div>
          </Field>
          <Button full size="lg" tone="primary" type="submit" disabled={!email.trim() || pending} iconRight={pending?undefined:'send'}>
            {pending ? 'Sending…' : 'Send reset link'}
          </Button>
        </form>
      ) : (
        <div className="mt-6 space-y-4">
          <div className="bg-brand-50 border border-brand-200 rounded-xl p-4 flex gap-3">
            <Icon name="mail-check" size={18} className="text-brand-600 mt-0.5 flex-shrink-0"/>
            <div className="text-[13px] text-ink-700">
              If <span className="font-semibold">{email}</span> matches an account, a reset link is on its way. The link expires in 30 minutes.
            </div>
          </div>

          {devToken ? (
            <div className="bg-ink-900 text-white rounded-xl p-4">
              <div className="text-[10.5px] uppercase tracking-widest font-bold text-brand-300 mb-1.5 flex items-center gap-1.5">
                <Icon name="terminal" size={12}/> Dev mode · no real email
              </div>
              <div className="text-[12px] text-ink-300 mb-3">In production this link is emailed. For the demo, continue directly:</div>
              <Button full tone="brand" icon="arrow-right" onClick={() => onProceedToReset(devToken, email.trim())}>Open reset link</Button>
            </div>
          ) : (
            <div className="text-[12.5px] text-ink-400 text-center">
              No account matched that email. <button onClick={() => setSent(false)} className="font-semibold text-brand-600 hover:text-brand-700">Try again</button>
            </div>
          )}

          <button onClick={onBack} className="w-full text-center text-[12.5px] font-semibold text-ink-500 hover:text-ink-900">Back to sign in</button>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------------
// Reset password — set a new password with a valid token (step 2)
// ----------------------------------------------------------------------------
function ResetPassword({ ctx, onDone, toast }) {
  const [pw, setPw] = React.useState('');
  const [confirm, setConfirm] = React.useState('');
  const [pending, setPending] = React.useState(false);
  const [error, setError] = React.useState('');
  const [done, setDone] = React.useState(false);

  const tokenState = React.useMemo(() => window.Auth.validateResetToken(ctx?.token), [ctx]);
  const issues = window.Auth.passwordIssues(pw);
  const strength = window.Auth.passwordStrength(pw);
  const strengthLabel = ['Very weak','Weak','Fair','Good','Strong'][strength];
  const strengthColor = ['bg-rose-500','bg-rose-500','bg-amber-500','bg-brand-400','bg-brand-600'][strength];

  const submit = async () => {
    setError('');
    if (issues.length) { setError('Password too weak: ' + issues.join(', ')); return; }
    if (pw !== confirm) { setError('Passwords do not match.'); return; }
    setPending(true);
    try {
      await window.Auth.resetPassword(ctx.token, pw);
      setDone(true);
      toast({ tone:'success', title:'Password updated', message:'You can now sign in with your new password.' });
      setTimeout(onDone, 1600);
    } catch (e) {
      setError(e.message || 'Could not reset password.');
    } finally { setPending(false); }
  };

  if (!tokenState.valid) {
    const msg = { invalid:'This reset link is invalid.', used:'This reset link has already been used.', expired:'This reset link has expired.' }[tokenState.reason] || 'This reset link cannot be used.';
    return (
      <div>
        <div className="flex items-center gap-2 mb-4">
          <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center"><Icon name="alert-triangle" size={16}/></div>
          <h2 className="text-2xl font-bold text-ink-900 tracking-tight">Link unavailable</h2>
        </div>
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 text-[13px] text-rose-700">{msg}</div>
        <Button full size="lg" tone="secondary" className="mt-4" icon="arrow-left" onClick={onDone}>Back to sign in</Button>
      </div>
    );
  }

  if (done) {
    return (
      <div className="text-center py-10">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-brand-50 text-brand-600 flex items-center justify-center mb-4"><Icon name="check-circle-2" size={28}/></div>
        <div className="font-bold text-ink-900 text-lg">Password updated</div>
        <div className="text-[13px] text-ink-500 mt-1">Redirecting you to sign in…</div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <div className="w-9 h-9 rounded-xl bg-ink-900 text-white flex items-center justify-center"><Icon name="lock" size={16}/></div>
        <div>
          <h2 className="text-2xl font-bold text-ink-900 tracking-tight leading-none">Set a new password</h2>
          <p className="text-ink-500 text-[12.5px] mt-1">For <span className="font-mono">{ctx.email}</span></p>
        </div>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); submit(); }} className="space-y-4 mt-6">
        <Field label="New password" required>
          <div className="relative">
            <Icon name="lock" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
            <Input value={pw} onChange={e => setPw(e.target.value)} placeholder="At least 8 chars, mixed case + number" className="pl-9" type="password" autoFocus/>
          </div>
          {pw && (
            <div className="mt-2">
              <div className="flex gap-1">
                {[0,1,2,3].map(i => (
                  <div key={i} className={`h-1 flex-1 rounded-full ${i < strength ? strengthColor : 'bg-ink-200'}`}></div>
                ))}
              </div>
              <div className="text-[11px] text-ink-500 mt-1">Strength: <span className="font-semibold">{strengthLabel}</span></div>
            </div>
          )}
        </Field>
        <Field label="Confirm password" required>
          <div className="relative">
            <Icon name="lock" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400"/>
            <Input value={confirm} onChange={e => setConfirm(e.target.value)} placeholder="Re-enter password" className="pl-9" type="password"/>
          </div>
        </Field>

        {error && (
          <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 flex gap-2 text-[12.5px] text-rose-700">
            <Icon name="alert-circle" size={14} className="mt-0.5 flex-shrink-0"/>
            <span>{error}</span>
          </div>
        )}

        <Button full size="lg" tone="primary" type="submit" disabled={pending} iconRight={pending?undefined:'check'}>
          {pending ? 'Updating…' : 'Update password'}
        </Button>
      </form>
    </div>
  );
}

function StatCard({ label, value, hint }) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-3 backdrop-blur-sm">
      <div className="text-[11px] uppercase tracking-widest text-ink-400 font-semibold">{label}</div>
      <div className="text-2xl font-extrabold mt-0.5 tracking-tight">{value}</div>
      <div className="text-[11px] text-ink-400 mt-0.5">{hint}</div>
    </div>
  );
}

function RoleIcon({ role, active }) {
  const map = {
    ADMIN:'shield', DOCTOR:'stethoscope', EDITOR:'film', WRITER:'pen-tool', APPROVER:'shield-check', SOCIAL:'send',
  };
  return (
    <span className={`w-7 h-7 rounded-lg flex items-center justify-center ${active?'bg-brand-500 text-white':'bg-ink-100 text-ink-600'}`}>
      <Icon name={map[role]||'user'} size={14}/>
    </span>
  );
}
function Logo({ size = 28, variant='dark' }) {
  // M⁺ ring mark — sky-blue ring, bold rounded M with a + superscript.
  const ring = variant === 'light' ? '#79CBED' : '#54B8E8';
  const mark = variant === 'light' ? '#EAF7FD' : '#2BA1DC';
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <circle cx="16" cy="16" r="13.4" fill="none" stroke={ring} strokeWidth="2.6"/>
      <text x="14.5" y="21.6" textAnchor="middle" fontFamily="'Plus Jakarta Sans', sans-serif" fontWeight="800" fontSize="15" fill={mark}>M</text>
      <text x="24" y="12.8" textAnchor="middle" fontFamily="'Plus Jakarta Sans', sans-serif" fontWeight="800" fontSize="8.5" fill={mark}>+</text>
    </svg>
  );
}

Object.assign(window, { LoginScreen, Logo, RoleIcon });
