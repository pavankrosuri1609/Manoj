// ============================================================================
// PRODUCTION CONFIGURATION — Dr. Manoj's Homeopathy
// ----------------------------------------------------------------------------
// This is the ONE file you edit to take the app live. No code changes, no
// console commands.
//
//   • To run against your real backend (MySQL + S3):
//       set API_BASE_URL to your API's URL, e.g.
//         "/api"                              (frontend served on the same host)
//         "https://api.drmanojhomeopathy.com/api"   (separate API host)
//
//   • To run the self-contained in-browser preview (no backend required):
//       leave API_BASE_URL = ""
//
// When API_BASE_URL is set, the app authenticates every user against the SQL
// users table (real JWT) and reads/writes all data through the API. The
// in-browser preview store is used ONLY when API_BASE_URL is empty.
// ============================================================================
window.CLINICAST_CONFIG = {
  API_BASE_URL: "",
};
