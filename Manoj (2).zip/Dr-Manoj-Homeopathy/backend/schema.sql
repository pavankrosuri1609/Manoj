-- ============================================================================
-- Clinicast — Doctor Content Workflow Platform
-- MySQL 8.0+ schema (utf8mb4, InnoDB, strict mode)
-- Maps 1:1 to the data model used by the React frontend.
-- ============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP DATABASE IF EXISTS clinicast;
CREATE DATABASE clinicast
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;
USE clinicast;

-- ============================================================================
-- 1. USERS  (the RBAC source-of-truth)
-- ============================================================================
CREATE TABLE users (
  id              CHAR(24)     NOT NULL,                 -- ULID/UUID-ish opaque id
  name            VARCHAR(120) NOT NULL,
  email           VARCHAR(190) NOT NULL,                 -- 190 to allow utf8mb4 + index
  phone           VARCHAR(40)  NULL,
  role            ENUM('ADMIN','DOCTOR','EDITOR','WRITER','APPROVER','SOCIAL') NOT NULL,
  approver_tier   ENUM('peer','final') NULL,             -- only when role = APPROVER
  specialty       VARCHAR(160) NULL,
  initials        VARCHAR(4)   NULL,
  tone            VARCHAR(24)  NULL,                     -- thumb-grad-N
  password_hash   VARCHAR(255) NULL,                     -- bcrypt/argon2
  mfa_secret      VARCHAR(64)  NULL,                     -- TOTP shared secret (encrypted)
  mfa_enabled     TINYINT(1)   NOT NULL DEFAULT 0,
  active          TINYINT(1)   NOT NULL DEFAULT 1,
  failed_login_attempts INT     NOT NULL DEFAULT 0,       -- SEC-4: brute-force lockout
  locked_until    TIMESTAMP    NULL,                      -- SEC-4: account locked until this time
  last_login_at   TIMESTAMP    NULL,
  created_at      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  KEY ix_users_role (role, active),
  KEY ix_users_active (active),
  CONSTRAINT chk_users_tier CHECK (role <> 'APPROVER' OR approver_tier IS NOT NULL)
) ENGINE=InnoDB;

-- ============================================================================
-- 2. VIDEOS  (workflow primary entity)
-- ============================================================================
CREATE TABLE videos (
  id                CHAR(24)     NOT NULL,
  title             VARCHAR(240) NOT NULL,
  description       TEXT         NULL,
  status            ENUM('UPLOADED','EDITING','WRITING','PEER_REVIEW','FINAL_REVIEW',
                         'APPROVED','REJECTED','PUBLISHED') NOT NULL DEFAULT 'UPLOADED',
  classification    ENUM('PHI','INTERNAL','PUBLIC') NOT NULL DEFAULT 'INTERNAL',
  duration_seconds  INT UNSIGNED NOT NULL DEFAULT 0,
  thumb_seed        TINYINT UNSIGNED NOT NULL DEFAULT 0,

  -- Assignments (role-tagged FKs)
  uploader_id       CHAR(24)     NOT NULL,
  editor_id         CHAR(24)     NULL,
  writer_id         CHAR(24)     NULL,
  peer_approver_id  CHAR(24)     NULL,
  final_approver_id CHAR(24)     NULL,
  social_id         CHAR(24)     NULL,

  -- Caption payload (denormalised; small + read-heavy)
  captions          TEXT         NULL,
  hashtags_json     JSON         NULL,                   -- ["#HeartHealth", ...]
  platforms_json    JSON         NULL,                   -- ["Instagram", "YouTube"]

  -- Retention (computed from classification + created_at at write time)
  purge_after       DATE         NULL,

  created_at        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  published_at      TIMESTAMP    NULL,

  PRIMARY KEY (id),
  KEY ix_videos_status      (status, updated_at DESC),
  KEY ix_videos_uploader    (uploader_id, status),
  KEY ix_videos_editor      (editor_id, status),
  KEY ix_videos_writer      (writer_id, status),
  KEY ix_videos_peer        (peer_approver_id, status),
  KEY ix_videos_final       (final_approver_id, status),
  KEY ix_videos_social      (social_id, status),
  KEY ix_videos_classification (classification, purge_after),

  CONSTRAINT fk_videos_uploader FOREIGN KEY (uploader_id)       REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_videos_editor   FOREIGN KEY (editor_id)         REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_videos_writer   FOREIGN KEY (writer_id)         REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_videos_peer     FOREIGN KEY (peer_approver_id)  REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_videos_final    FOREIGN KEY (final_approver_id) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_videos_social   FOREIGN KEY (social_id)         REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================================
-- 3. VIDEO_VERSIONS  (raw recording + edited cuts, both stored in S3/MinIO)
-- ============================================================================
CREATE TABLE video_versions (
  id              CHAR(24)     NOT NULL,
  video_id        CHAR(24)     NOT NULL,
  kind            ENUM('raw','edit') NOT NULL,
  label           VARCHAR(120) NOT NULL,
  file_name       VARCHAR(240) NOT NULL,
  storage_key     VARCHAR(512) NOT NULL,                 -- s3://bucket/path or path in MinIO
  storage_bucket  VARCHAR(120) NULL,
  size_bytes      BIGINT UNSIGNED NOT NULL DEFAULT 0,
  mime_type       VARCHAR(80)  NOT NULL DEFAULT 'video/mp4',
  checksum_sha256 CHAR(64)     NULL,
  notes           VARCHAR(500) NULL,
  uploaded_by     CHAR(24)     NOT NULL,
  uploaded_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_versions_video (video_id, uploaded_at),
  KEY ix_versions_by    (uploaded_by),
  CONSTRAINT fk_versions_video FOREIGN KEY (video_id)    REFERENCES videos(id) ON DELETE CASCADE,
  CONSTRAINT fk_versions_user  FOREIGN KEY (uploaded_by) REFERENCES users(id)  ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ============================================================================
-- 4. COMMENTS
-- ============================================================================
CREATE TABLE comments (
  id          CHAR(24)     NOT NULL,
  video_id    CHAR(24)     NOT NULL,
  author_id   CHAR(24)     NOT NULL,
  body        TEXT         NOT NULL,
  created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_comments_video (video_id, created_at),
  CONSTRAINT fk_comments_video FOREIGN KEY (video_id)  REFERENCES videos(id) ON DELETE CASCADE,
  CONSTRAINT fk_comments_user  FOREIGN KEY (author_id) REFERENCES users(id)  ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ============================================================================
-- 5. WORKFLOW_HISTORY  (per-video state transitions — user-readable timeline)
-- ============================================================================
CREATE TABLE workflow_history (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  video_id     CHAR(24)     NOT NULL,
  action       ENUM('CREATED','ASSIGNED','EDITED','WRITTEN',
                    'PEER_APPROVED','FINAL_APPROVED','APPROVED',
                    'REJECTED','PUBLISHED') NOT NULL,
  actor_id     CHAR(24)     NULL,                        -- NULL = system bot
  actor_name   VARCHAR(120) NOT NULL,
  label        VARCHAR(400) NOT NULL,
  at           TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_history_video (video_id, at),
  CONSTRAINT fk_history_video FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE,
  CONSTRAINT fk_history_user  FOREIGN KEY (actor_id) REFERENCES users(id)  ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================================
-- 6. REJECTION_REASONS  (richer than history rows; ties to send-back action)
-- ============================================================================
CREATE TABLE rejection_reasons (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  video_id     CHAR(24)     NOT NULL,
  reason       TEXT         NOT NULL,
  by_user_id   CHAR(24)     NULL,
  by_name      VARCHAR(120) NOT NULL,
  to_user_id   CHAR(24)     NULL,
  from_stage   ENUM('peer','final') NULL,
  created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_reject_video (video_id, created_at),
  CONSTRAINT fk_reject_video FOREIGN KEY (video_id)   REFERENCES videos(id) ON DELETE CASCADE,
  CONSTRAINT fk_reject_by    FOREIGN KEY (by_user_id) REFERENCES users(id)  ON DELETE SET NULL,
  CONSTRAINT fk_reject_to    FOREIGN KEY (to_user_id) REFERENCES users(id)  ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================================
-- 7. NOTIFICATIONS
-- ============================================================================
CREATE TABLE notifications (
  id           CHAR(24)     NOT NULL,
  user_id      CHAR(24)     NOT NULL,                    -- recipient
  type         ENUM('ASSIGNED','PEER_REVIEW','FINAL_REVIEW','REVIEW',
                    'APPROVED','PEER_APPROVED','FINAL_APPROVED',
                    'REJECTED','PUBLISHED','COMMENT','UPLOAD') NOT NULL,
  text         VARCHAR(500) NOT NULL,
  video_id     CHAR(24)     NULL,
  read_at      TIMESTAMP    NULL,
  created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_notif_user    (user_id, read_at, created_at DESC),
  KEY ix_notif_video   (video_id),
  CONSTRAINT fk_notif_user  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
  CONSTRAINT fk_notif_video FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================================
-- 8. SESSIONS  (JWT refresh tokens / device sessions)
-- ============================================================================
CREATE TABLE sessions (
  id               CHAR(32)     NOT NULL,                -- session id (random)
  user_id          CHAR(24)     NOT NULL,
  refresh_token_h  CHAR(64)     NOT NULL,                -- SHA-256 of refresh token
  issued_at        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at       TIMESTAMP    NOT NULL,
  last_activity_at TIMESTAMP    NULL,
  source_ip        VARCHAR(64)  NULL,
  user_agent       VARCHAR(255) NULL,
  mfa_verified     TINYINT(1)   NOT NULL DEFAULT 0,
  revoked_at       TIMESTAMP    NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sessions_refresh (refresh_token_h),
  KEY ix_sessions_user (user_id, revoked_at),
  KEY ix_sessions_exp  (expires_at),
  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================================
-- 9. AUDIT_LOG  (append-only — HMAC chain enforced in app layer)
-- ============================================================================
CREATE TABLE audit_log (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  at              TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  actor_id        CHAR(24)     NULL,
  actor_name      VARCHAR(120) NOT NULL,
  session_id      CHAR(32)     NULL,
  source_ip       VARCHAR(64)  NULL,
  user_agent      VARCHAR(255) NULL,
  action          VARCHAR(60)  NOT NULL,                 -- VIDEO_UPLOAD, PEER_APPROVE, ...
  outcome         ENUM('success','failure','denied') NOT NULL DEFAULT 'success',
  resource_type   VARCHAR(40)  NULL,                     -- video / user / session
  resource_id     VARCHAR(40)  NULL,
  resource_label  VARCHAR(240) NULL,
  metadata_json   JSON         NULL,
  prev_hmac       CHAR(64)     NULL,                     -- previous row's hmac (chain)
  hmac            CHAR(64)     NULL,                     -- HMAC-SHA256(this row + prev_hmac)
  PRIMARY KEY (id),
  KEY ix_audit_at        (at),
  KEY ix_audit_actor     (actor_id, at),
  KEY ix_audit_action    (action, at),
  KEY ix_audit_resource  (resource_type, resource_id, at),
  CONSTRAINT fk_audit_user FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
-- NOTE: this table is INSERT-only at the app layer. Grant the API user only
-- INSERT + SELECT. Use a separate "audit_reader" role for the Governance page.

-- ============================================================================
-- 10. PERMISSIONS  (RBAC matrix — exposed by /governance/rbac)
-- ============================================================================
CREATE TABLE role_permissions (
  role         ENUM('ADMIN','DOCTOR','EDITOR','WRITER',
                    'APPROVER_PEER','APPROVER_FINAL','SOCIAL') NOT NULL,
  permission   VARCHAR(80) NOT NULL,                     -- e.g. 'video.upload'
  scope        ENUM('full','assigned','own') NOT NULL DEFAULT 'full',
  PRIMARY KEY (role, permission)
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================================
-- SEED — RBAC matrix (same source-of-truth as Governance tab in the UI)
-- ============================================================================
INSERT INTO role_permissions (role, permission, scope) VALUES
-- User management
('ADMIN','users.read','full'),
('ADMIN','users.create','full'),
('ADMIN','users.update','full'),
('ADMIN','users.delete','full'),
-- Video
('ADMIN','video.upload','full'),
('DOCTOR','video.upload','full'),
('ADMIN','video.read.all','full'),
('ADMIN','video.read.own','full'),
('DOCTOR','video.read.own','full'),
('EDITOR','video.read.own','full'),
('WRITER','video.read.own','full'),
('APPROVER_PEER','video.read.own','full'),
('APPROVER_FINAL','video.read.own','full'),
('SOCIAL','video.read.own','full'),
('ADMIN','video.download.raw','full'),
('DOCTOR','video.download.raw','own'),
('EDITOR','video.download.raw','assigned'),
('ADMIN','video.download.edit','full'),
('DOCTOR','video.download.edit','own'),
('EDITOR','video.download.edit','assigned'),
('WRITER','video.download.edit','assigned'),
('APPROVER_PEER','video.download.edit','assigned'),
('APPROVER_FINAL','video.download.edit','assigned'),
('SOCIAL','video.download.edit','assigned'),
('ADMIN','video.upload.edit','full'),
('EDITOR','video.upload.edit','assigned'),
('ADMIN','video.delete','full'),
-- Workflow
('ADMIN','workflow.write_captions','full'),
('WRITER','workflow.write_captions','assigned'),
('ADMIN','workflow.peer_approve','full'),
('APPROVER_PEER','workflow.peer_approve','assigned'),
('ADMIN','workflow.final_approve','full'),
('APPROVER_FINAL','workflow.final_approve','assigned'),
('ADMIN','workflow.send_back','full'),
('APPROVER_PEER','workflow.send_back','assigned'),
('APPROVER_FINAL','workflow.send_back','assigned'),
('ADMIN','workflow.publish','full'),
('SOCIAL','workflow.publish','assigned'),
-- Governance
('ADMIN','audit.read','full'),
('ADMIN','audit.export','full'),
('ADMIN','classification.set','full');

-- ============================================================================
-- SEED — demo users (passwords: bcrypt hashes of 'demo1234', set on first deploy)
-- ============================================================================
INSERT INTO users (id, name, email, phone, role, approver_tier, specialty, initials, tone, active) VALUES
('ad1','Sarah Mitchell',    'sarah.mitchell@drmanojhomeopathy.com','+91 98480 10100','ADMIN',NULL,        'Practice Administrator',         'SM','thumb-grad-3', 1),
('d1', 'Dr. Manoj Kuriakose','dr.manoj@drmanojhomeopathy.com',     '+91 98480 10124','DOCTOR',NULL,       'Homeopathy · Founder',           'MK','thumb-grad-0', 1),
('d2', 'Dr. Anika Verma',   'anika.verma@drmanojhomeopathy.com',   '+91 98480 10188','DOCTOR',NULL,       'Skin & Hair Homeopathy',         'AV','thumb-grad-2', 1),
('d3', 'Dr. Sameer Iyer',   'sameer.iyer@drmanojhomeopathy.com',   '+91 98480 10211','DOCTOR',NULL,       'Pediatric Homeopathy',           'SI','thumb-grad-4', 1),
('e1', 'Priya Shah',        'priya.shah@drmanojhomeopathy.com',    '+91 98480 10307','EDITOR',NULL,       'Senior Editor',                  'PS','thumb-grad-1', 1),
('e2', 'Marcus Chen',       'marcus.chen@drmanojhomeopathy.com',   '+91 98480 10342','EDITOR',NULL,       'Motion Editor',                  'MC','thumb-grad-3', 1),
('w1', 'Lena Okafor',       'lena.okafor@drmanojhomeopathy.com',   '+91 98480 10418','WRITER',NULL,       'Copy Lead',                      'LO','thumb-grad-5', 1),
('w2', 'Diego Alvarez',     'diego.alvarez@drmanojhomeopathy.com', '+91 98480 10455','WRITER',NULL,       'Medical Writer',                 'DA','thumb-grad-4', 1),
('a1', 'Dr. Hannah Park',   'hannah.park@drmanojhomeopathy.com',   '+91 98480 10520','APPROVER','peer',   'Clinical Reviewer · BHMS',       'HP','thumb-grad-2', 1),
('a2', 'Olivia Tran',       'olivia.tran@drmanojhomeopathy.com',   '+91 98480 10566','APPROVER','final',  'Practice Head · Compliance',     'OT','thumb-grad-1', 1),
('s1', 'Yusuf Bello',       'yusuf.bello@drmanojhomeopathy.com',   '+91 98480 10612','SOCIAL',NULL,       'Channel Manager',                'YB','thumb-grad-0', 1);

-- ============================================================================
-- Operational notes
-- ============================================================================
-- 1. Run as a privileged DBA user. Application connects via a least-privilege
--    user that has SELECT/INSERT/UPDATE on most tables but only INSERT+SELECT
--    on `audit_log` (preserves append-only invariant at the DB layer).
--
--    CREATE USER 'clinicast_api'@'%' IDENTIFIED BY '<rotated-secret>';
--    GRANT SELECT, INSERT, UPDATE, DELETE ON clinicast.* TO 'clinicast_api'@'%';
--    REVOKE UPDATE, DELETE ON clinicast.audit_log FROM 'clinicast_api'@'%';
--    CREATE USER 'clinicast_audit'@'%' IDENTIFIED BY '<rotated-secret>';
--    GRANT SELECT ON clinicast.audit_log TO 'clinicast_audit'@'%';
--
-- 2. Retention purge job (daily):
--    DELETE FROM videos WHERE purge_after IS NOT NULL AND purge_after < CURDATE();
--    The cascade clears versions, comments, history.
--
-- 3. Backup: enable mysqldump (logical) nightly + binlog point-in-time
--    recovery (PITR). For AWS, prefer Aurora with continuous backup.
-- ============================================================================
