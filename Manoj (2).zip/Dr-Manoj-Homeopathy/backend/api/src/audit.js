// Audit log — append-only. Every privileged action writes a row here.
// In production: chain HMAC for tamper-evidence, replicate to a WORM store.
import crypto from 'crypto';
import { pool } from './db.js';

export async function appendAudit({
  actorId = null,
  actorName = 'system',
  sessionId = null,
  sourceIp = null,
  userAgent = null,
  action,
  outcome = 'success',
  resourceType = null,
  resourceId = null,
  resourceLabel = null,
  metadata = null,
}) {
  // SEC-3 — serialise the read-prev-then-insert across ALL app instances with a
  // MySQL server-wide named lock, on a single dedicated connection. Without this,
  // two concurrent appends read the same prev_hmac and fork the chain, breaking
  // tamper-evidence. GET_LOCK is connection-scoped, so lock + read + insert +
  // release must all run on the same connection.
  const conn = await pool.getConnection();
  let locked = false;
  try {
    const [[lk]] = await conn.query("SELECT GET_LOCK('clinicast_audit_chain', 10) AS ok");
    locked = lk && lk.ok === 1;
    if (!locked) throw new Error('audit chain lock timeout');

    const [[last]] = await conn.query('SELECT hmac FROM audit_log ORDER BY id DESC LIMIT 1');
    const prev = last?.hmac || null;

    // Compute deterministic body, then HMAC
    const body = JSON.stringify({
      actorId, actorName, sessionId, sourceIp, userAgent,
      action, outcome, resourceType, resourceId, resourceLabel,
      metadata, prev,
    });
    const secret = process.env.AUDIT_HMAC_KEY || process.env.JWT_SECRET || 'dev';
    const hmac = crypto.createHmac('sha256', secret).update(body).digest('hex');

    await conn.query(
      `INSERT INTO audit_log
         (actor_id, actor_name, session_id, source_ip, user_agent, action, outcome,
          resource_type, resource_id, resource_label, metadata_json, prev_hmac, hmac)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [actorId, actorName, sessionId, sourceIp, userAgent, action, outcome,
        resourceType, resourceId, resourceLabel,
        metadata ? JSON.stringify(metadata) : null, prev, hmac]
    );
  } finally {
    if (locked) await conn.query("SELECT RELEASE_LOCK('clinicast_audit_chain')").catch(() => {});
    conn.release();
  }
}

// Verify the HMAC chain is intact (no tampering, no forks). Returns the first
// broken row's id, or null if the whole chain verifies. Run from ops tooling.
export async function verifyAuditChain() {
  const secret = process.env.AUDIT_HMAC_KEY || process.env.JWT_SECRET || 'dev';
  const [rows] = await pool.query(
    `SELECT id, actor_id, actor_name, session_id, source_ip, user_agent, action,
            outcome, resource_type, resource_id, resource_label, metadata_json,
            prev_hmac, hmac FROM audit_log ORDER BY id ASC`
  );
  let prev = null;
  for (const r of rows) {
    const body = JSON.stringify({
      actorId: r.actor_id, actorName: r.actor_name, sessionId: r.session_id,
      sourceIp: r.source_ip, userAgent: r.user_agent, action: r.action,
      outcome: r.outcome, resourceType: r.resource_type, resourceId: r.resource_id,
      resourceLabel: r.resource_label,
      metadata: r.metadata_json ? JSON.parse(r.metadata_json) : null,
      prev,
    });
    const expect = crypto.createHmac('sha256', secret).update(body).digest('hex');
    if (r.prev_hmac !== prev || r.hmac !== expect) return { ok: false, brokenAt: r.id };
    prev = r.hmac;
  }
  return { ok: true, brokenAt: null, verified: rows.length };
}

// Express middleware factory — captures the audit context for downstream handlers.
export function withAuditContext(req, _res, next) {
  req.audit = (opts) => appendAudit({
    actorId: req.user?.id,
    actorName: req.user?.name || 'anonymous',
    sessionId: req.user?.sessionId,
    sourceIp: req.ip,
    userAgent: req.headers['user-agent'],
    ...opts,
  });
  next();
}
