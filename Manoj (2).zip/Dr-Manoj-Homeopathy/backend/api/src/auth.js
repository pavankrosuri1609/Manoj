// JWT issue + verify, password hashing, MFA helpers.
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import speakeasy from 'speakeasy';
import { one } from './db.js';

const IS_PROD = () => process.env.NODE_ENV === 'production';
const SECRET = () => process.env.JWT_SECRET || 'dev_only_change_me';
const ACCESS_TTL = () => Number(process.env.JWT_ACCESS_TTL || 900);
const REFRESH_TTL = () => Number(process.env.JWT_REFRESH_TTL || 2592000);

// ---------------------------------------------------------------------------
// SEC-1 — fail-fast secret validation.
// Called once at boot. In production the app refuses to start with a missing,
// short, or default secret (which would let anyone forge tokens / audit rows),
// or a wildcard CORS origin. In dev it only warns so local runs stay easy.
// ---------------------------------------------------------------------------
export function assertSecureConfig() {
  const problems = [];
  const jwtSecret = process.env.JWT_SECRET || '';
  const auditKey = process.env.AUDIT_HMAC_KEY || process.env.JWT_SECRET || '';
  const cors = (process.env.CORS_ORIGIN || '*').split(',').map(s => s.trim());

  if (!jwtSecret || jwtSecret === 'dev_only_change_me') problems.push('JWT_SECRET is unset or the known default — set a unique random value (openssl rand -hex 64).');
  else if (jwtSecret.length < 32) problems.push('JWT_SECRET is too short — use at least 32 characters.');
  if (!auditKey || auditKey === 'dev') problems.push('AUDIT_HMAC_KEY (or JWT_SECRET) is unset or default — the audit chain would be forgeable.');
  else if (auditKey.length < 32) problems.push('AUDIT_HMAC_KEY is too short — use at least 32 characters.');
  if (cors.includes('*')) problems.push('CORS_ORIGIN is "*" — set an explicit frontend origin allowlist.');

  if (problems.length && IS_PROD()) {
    console.error('\n[security] Refusing to start — insecure configuration:');
    for (const p of problems) console.error('  ✗ ' + p);
    console.error('');
    process.exit(1);
  } else if (problems.length) {
    console.warn('[security] DEV warning — these MUST be fixed before production:');
    for (const p of problems) console.warn('  ⚠ ' + p);
  } else {
    console.log('[security] ✓ secret + CORS configuration validated.');
  }
}

export function hashPassword(plain) {
  return bcrypt.hash(plain, 12);
}
export function verifyPassword(plain, hash) {
  if (!hash) return false;
  return bcrypt.compare(plain, hash);
}

export function signAccessToken({ userId, role, tier, sessionId }) {
  return jwt.sign({ sub: userId, role, tier, sid: sessionId }, SECRET(), {
    expiresIn: ACCESS_TTL(),
    issuer: 'clinicast',
  });
}
export function signRefreshToken({ userId, sessionId }) {
  return jwt.sign({ sub: userId, sid: sessionId, typ: 'refresh' }, SECRET(), {
    expiresIn: REFRESH_TTL(),
    issuer: 'clinicast',
  });
}
export function verifyToken(token) {
  return jwt.verify(token, SECRET(), { issuer: 'clinicast' });
}

export function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export function newSessionId() {
  return crypto.randomBytes(16).toString('hex');
}

export function verifyTotp(secret, code) {
  if (!secret) return true; // MFA not enabled
  return speakeasy.totp.verify({ secret, encoding: 'base32', token: code, window: 1 });
}

// ---------------------------------------------------------------------------
// SEC-2 — session-aware token validation.
// A valid JWT signature is necessary but NOT sufficient: the session must also
// be un-revoked and unexpired, and the user still active. This gives instant
// logout / disable (subject to a short cache) instead of waiting out the token
// TTL. Cached briefly to avoid a DB hit on every request.
// ---------------------------------------------------------------------------
const sessionCache = new Map(); // sid -> { checkedAt, ok }
const SESSION_CACHE_TTL = Number(process.env.SESSION_CACHE_TTL_MS || 30_000);

export function invalidateSession(sid) { sessionCache.delete(sid); }

async function sessionValid(sid, userId) {
  if (!sid) return false;
  const now = Date.now();
  const cached = sessionCache.get(sid);
  if (cached && now - cached.checkedAt < SESSION_CACHE_TTL) return cached.ok;
  const row = await one(
    `SELECT s.revoked_at, s.expires_at, u.active
       FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.id = ? AND s.user_id = ?`,
    [sid, userId]
  );
  const ok = !!row && !row.revoked_at && new Date(row.expires_at) > new Date() && !!row.active;
  sessionCache.set(sid, { checkedAt: now, ok });
  return ok;
}

// Express middleware — requires a valid Bearer token AND a live session.
export async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'NO_TOKEN', message: 'Missing Bearer token' });
  try {
    const payload = verifyToken(token);
    if (payload.typ === 'refresh') return res.status(401).json({ error: 'WRONG_TOKEN_TYPE' });
    // SEC-2: signature alone is not enough — the session must still be live.
    if (!(await sessionValid(payload.sid, payload.sub))) {
      return res.status(401).json({ error: 'SESSION_REVOKED', message: 'Session is no longer valid. Please sign in again.' });
    }
    req.user = {
      id: payload.sub,
      role: payload.role,
      tier: payload.tier,
      sessionId: payload.sid,
    };
    next();
  } catch (e) {
    return res.status(401).json({ error: 'INVALID_TOKEN', message: e.message });
  }
}

// Role/tier guard.
export function requireRole(...allowed) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'NOT_AUTHENTICATED' });
    if (!allowed.includes(req.user.role)) {
      return res.status(403).json({ error: 'FORBIDDEN', message: `Requires role: ${allowed.join('|')}` });
    }
    next();
  };
}

// Approver-tier guard.
export function requireTier(tier) {
  return (req, res, next) => {
    if (req.user.role !== 'APPROVER' || req.user.tier !== tier) {
      return res.status(403).json({ error: 'FORBIDDEN', message: `Requires ${tier} reviewer` });
    }
    next();
  };
}
