// Clinicast API — main entry point.
//
// In dev: `npm run dev` (with --watch). In prod: `node src/server.js`.
// Designed to sit behind an API gateway / load balancer that adds TLS and
// further request shaping (mTLS to backend optional).
import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { ZodError } from 'zod';

import authRoutes from './routes/auth.js';
import userRoutes from './routes/users.js';
import videoRoutes from './routes/videos.js';
import notifRoutes from './routes/notifications.js';
import govRoutes from './routes/governance.js';
import { withAuditContext } from './audit.js';
import { pool } from './db.js';
import { checkStorage } from './storage.js';
import { assertSecureConfig } from './auth.js';

// SEC-1 — refuse to boot in production with a missing/default secret or wildcard CORS.
assertSecureConfig();

const app = express();
const port = Number(process.env.PORT) || 4000;

// --- Hardening ---
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: false, // CSP belongs on the static frontend host
  crossOriginEmbedderPolicy: false,
}));

// CORS — comma-separated origins via env.
const allowed = (process.env.CORS_ORIGIN || '*').split(',').map(s => s.trim());
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowed.includes('*') || allowed.includes(origin)) return cb(null, true);
    cb(new Error('CORS_DENIED'));
  },
  credentials: true,
}));

// Rate limit: per-IP, 200 req/min globally — tighten per-route as needed.
app.use(rateLimit({ windowMs: 60_000, limit: 200, standardHeaders: 'draft-7', legacyHeaders: false }));

app.use(express.json({ limit: '128kb' }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(withAuditContext);

// --- Routes ---
// --- Health: reports BOTH dependencies so you can see exactly what's down ---
app.get('/health', async (_req, res) => {
  const out = { status: 'ok', uptime: process.uptime(), db: 'ok', s3: 'ok' };
  try { await pool.query('SELECT 1'); } catch (e) { out.status = 'degraded'; out.db = e.message; }
  try { await checkStorage(); } catch (e) { out.status = 'degraded'; out.s3 = e.message; }
  res.status(out.status === 'ok' ? 200 : 503).json(out);
});

app.use('/api/auth',          authRoutes);
app.use('/api/users',         userRoutes);
app.use('/api/videos',        videoRoutes);
app.use('/api/notifications', notifRoutes);
app.use('/api/governance',    govRoutes);

// 404
app.use((req, res) => res.status(404).json({ error: 'NOT_FOUND', path: req.path }));

// Error handler — never leak stack traces in production.
app.use((err, req, res, _next) => {
  if (err instanceof ZodError) {
    return res.status(400).json({ error: 'VALIDATION', issues: err.issues });
  }
  console.error('[unhandled]', err.code || err.message, err.stack);
  const safe = process.env.NODE_ENV === 'production'
    ? { error: 'INTERNAL' }
    : { error: err.code || 'INTERNAL', message: err.message };
  res.status(err.status || 500).json(safe);
});

const server = app.listen(port, async () => {
  console.log(`Clinicast API listening on :${port} (env=${process.env.NODE_ENV || 'development'})`);
  // Probe object storage at boot so misconfiguration surfaces immediately
  // (clear message) rather than as a silent 403 on the first upload.
  try {
    await checkStorage();
  } catch (e) {
    console.error('\n[storage] ✗ ' + e.message);
    console.error('[storage] Uploads/downloads will fail until this is fixed. See backend/api/.env.example (Profile A = AWS, Profile B = MinIO).\n');
  }
});

// REL-1 — graceful shutdown. On SIGTERM/SIGINT (rolling deploy, systemd stop),
// stop accepting new connections, let in-flight requests finish, then drain the
// DB pool. A hard timeout guarantees the process still exits if a request hangs.
let shuttingDown = false;
function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`[shutdown] ${signal} received — draining connections…`);
  const force = setTimeout(() => {
    console.error('[shutdown] drain timeout — forcing exit.');
    process.exit(1);
  }, Number(process.env.SHUTDOWN_TIMEOUT_MS || 15000));
  force.unref();
  server.close(async () => {
    try { await pool.end(); } catch (e) { /* already closing */ }
    clearTimeout(force);
    console.log('[shutdown] clean exit.');
    process.exit(0);
  });
}
['SIGTERM', 'SIGINT'].forEach(sig => process.on(sig, () => shutdown(sig)));
