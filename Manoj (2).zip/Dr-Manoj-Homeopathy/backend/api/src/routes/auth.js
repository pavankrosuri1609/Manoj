// /auth/* — login (password + optional MFA), refresh, logout, me, session
import { Router } from 'express';
import { z } from 'zod';
import { ulid } from 'ulid';
import rateLimit from 'express-rate-limit';
import { q, one } from '../db.js';
import {
  hashPassword, verifyPassword, signAccessToken, signRefreshToken,
  verifyToken, hashToken, newSessionId, verifyTotp, requireAuth, invalidateSession,
} from '../auth.js';
import { rowToUser } from '../mappers.js';
import { appendAudit } from '../audit.js';

const router = Router();

// SEC-4 — a strict, dedicated limiter on the login route (on top of the global
// per-IP limit) to blunt online password guessing from a single source.
const loginLimiter = rateLimit({
  windowMs: 60_000,
  limit: Number(process.env.LOGIN_RATE_LIMIT || 10),
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'RATE_LIMITED', message: 'Too many sign-in attempts. Please wait a minute.' },
});

// SEC-4 — per-account lockout tuning.
const LOCK_THRESHOLD = Number(process.env.LOGIN_LOCK_THRESHOLD || 5);   // failures before lock
const LOCK_MINUTES   = Number(process.env.LOGIN_LOCK_MINUTES || 15);    // lock duration

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  mfa_code: z.string().optional(),
});

router.post('/login', loginLimiter, async (req, res, next) => {
  try {
    const body = loginSchema.parse(req.body);
    const user = await one('SELECT * FROM users WHERE email = ? LIMIT 1', [body.email.toLowerCase()]);
    const fail = async (reason, status = 401, error = 'INVALID_CREDENTIALS') => {
      await appendAudit({
        action: 'LOGIN', outcome: 'failure', actorName: body.email,
        actorId: user?.id || null, sourceIp: req.ip, userAgent: req.headers['user-agent'],
        metadata: { reason },
      });
      return res.status(status).json({ error });
    };
    if (!user || !user.active) return fail('user-not-found');

    // SEC-4 — reject while locked (uniform 401 message so we don't reveal lock state to attackers).
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      return fail('account-locked');
    }

    const passwordOk = await verifyPassword(body.password, user.password_hash);
    if (!passwordOk) {
      // SEC-4 — count the failure and lock the account past the threshold.
      const attempts = (user.failed_login_attempts || 0) + 1;
      if (attempts >= LOCK_THRESHOLD) {
        await q('UPDATE users SET failed_login_attempts = ?, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id = ?',
          [attempts, LOCK_MINUTES, user.id]);
        await appendAudit({ action: 'ACCOUNT_LOCKED', outcome: 'failure', actorId: user.id, actorName: user.name,
          sourceIp: req.ip, userAgent: req.headers['user-agent'], metadata: { attempts } });
      } else {
        await q('UPDATE users SET failed_login_attempts = ? WHERE id = ?', [attempts, user.id]);
      }
      return fail('bad-password');
    }
    if (user.mfa_enabled && !verifyTotp(user.mfa_secret, body.mfa_code)) return fail('bad-mfa');

    // Issue session + tokens
    const sessionId = newSessionId();
    const refresh = signRefreshToken({ userId: user.id, sessionId });
    const access  = signAccessToken({ userId: user.id, role: user.role, tier: user.approver_tier, sessionId });
    const ttl = Number(process.env.JWT_REFRESH_TTL || 2592000);
    await q(
      `INSERT INTO sessions (id, user_id, refresh_token_h, expires_at, source_ip, user_agent, mfa_verified)
       VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? SECOND), ?, ?, ?)`,
      [sessionId, user.id, hashToken(refresh), ttl, req.ip, req.headers['user-agent'] || null, user.mfa_enabled ? 1 : 0]
    );
    // SEC-4 — reset the failure counter + clear any lock on success.
    await q('UPDATE users SET last_login_at = NOW(), failed_login_attempts = 0, locked_until = NULL WHERE id = ?', [user.id]);
    await appendAudit({
      action: 'LOGIN', outcome: 'success',
      actorId: user.id, actorName: user.name, sessionId,
      sourceIp: req.ip, userAgent: req.headers['user-agent'],
    });

    res.json({ access_token: access, refresh_token: refresh, user: rowToUser(user) });
  } catch (e) { next(e); }
});

router.post('/refresh', async (req, res, next) => {
  try {
    const rt = req.body?.refresh_token;
    if (!rt) return res.status(400).json({ error: 'MISSING_REFRESH' });
    let payload;
    try { payload = verifyToken(rt); } catch (e) { return res.status(401).json({ error: 'INVALID_REFRESH' }); }
    if (payload.typ !== 'refresh') return res.status(401).json({ error: 'WRONG_TOKEN_TYPE' });

    const sess = await one(
      'SELECT s.*, u.role, u.approver_tier FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ? AND s.refresh_token_h = ? AND s.revoked_at IS NULL AND s.expires_at > NOW()',
      [payload.sid, hashToken(rt)]
    );
    if (!sess) return res.status(401).json({ error: 'SESSION_NOT_FOUND' });

    // Rotate refresh token (defence in depth)
    const newRefresh = signRefreshToken({ userId: sess.user_id, sessionId: sess.id });
    await q('UPDATE sessions SET refresh_token_h = ?, last_activity_at = NOW() WHERE id = ?',
      [hashToken(newRefresh), sess.id]);

    const access = signAccessToken({ userId: sess.user_id, role: sess.role, tier: sess.approver_tier, sessionId: sess.id });
    res.json({ access_token: access, refresh_token: newRefresh });
  } catch (e) { next(e); }
});

router.post('/logout', requireAuth, async (req, res, next) => {
  try {
    await q('UPDATE sessions SET revoked_at = NOW() WHERE id = ?', [req.user.sessionId]);
    invalidateSession(req.user.sessionId); // SEC-2: take effect immediately, not after cache TTL
    await appendAudit({
      action: 'LOGOUT', outcome: 'success',
      actorId: req.user.id, sessionId: req.user.sessionId,
      sourceIp: req.ip, userAgent: req.headers['user-agent'],
    });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.get('/me', requireAuth, async (req, res, next) => {
  try {
    const user = await one('SELECT * FROM users WHERE id = ?', [req.user.id]);
    res.json(rowToUser(user));
  } catch (e) { next(e); }
});

router.get('/session', requireAuth, async (req, res, next) => {
  try {
    const sess = await one('SELECT * FROM sessions WHERE id = ?', [req.user.sessionId]);
    if (!sess) return res.status(404).json({ error: 'NOT_FOUND' });
    res.json({
      sessionId: sess.id,
      userId: sess.user_id,
      issuedAt: sess.issued_at,
      expiresAt: sess.expires_at,
      lastActivity: sess.last_activity_at,
      sourceIp: sess.source_ip,
      userAgent: sess.user_agent,
      mfaVerified: !!sess.mfa_verified,
    });
  } catch (e) { next(e); }
});

export default router;
