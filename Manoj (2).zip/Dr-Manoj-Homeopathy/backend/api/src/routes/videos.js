// /videos/* — list, get, create, workflow transitions, presigned uploads.
import { Router } from 'express';
import { z } from 'zod';
import { ulid } from 'ulid';
import { q, one, tx } from '../db.js';
import { requireAuth, requireTier } from '../auth.js';
import { requirePermission } from '../rbac.js';
import { rowToVideo, rowToVersion, rowToComment, rowToHistory } from '../mappers.js';
import { presignUpload, presignDownload } from '../storage.js';

const router = Router();
router.use(requireAuth);

// Helper: scope a list query to assignments the user can see.
function scopeFilter(user) {
  if (user.role === 'ADMIN') return { sql: '', params: [] };
  const id = user.id;
  // Doctors see what they uploaded; everyone else sees what's assigned to them.
  return {
    sql: ` AND (uploader_id = ? OR editor_id = ? OR writer_id = ? OR peer_approver_id = ? OR final_approver_id = ? OR social_id = ?)`,
    params: [id, id, id, id, id, id],
  };
}

// ---------- LIST ----------
router.get('/', requirePermission('video.read.own'), async (req, res, next) => {
  try {
    const { sql: scopeSql, params: scopeParams } = req.permissionScope === 'full' ? { sql: '', params: [] } : scopeFilter(req.user);
    const conditions = ['1=1'];
    const params = [];
    if (req.query.status) { conditions.push('status = ?'); params.push(req.query.status); }
    const rows = await q(
      `SELECT * FROM videos WHERE ${conditions.join(' AND ')}${scopeSql} ORDER BY updated_at DESC LIMIT 200`,
      [...params, ...scopeParams]
    );
    if (rows.length === 0) return res.json([]);

    // Attach versions / comments / history / reasons so list views (editor queue,
    // kanban, version history) have everything the frontend expects.
    const ids = rows.map(r => r.id);
    const placeholders = ids.map(() => '?').join(',');
    const [versions, comments, history, reasons] = await Promise.all([
      q(`SELECT * FROM video_versions   WHERE video_id IN (${placeholders}) ORDER BY uploaded_at`, ids),
      q(`SELECT * FROM comments         WHERE video_id IN (${placeholders}) ORDER BY created_at`, ids),
      q(`SELECT * FROM workflow_history WHERE video_id IN (${placeholders}) ORDER BY at`, ids),
      q(`SELECT * FROM rejection_reasons WHERE video_id IN (${placeholders}) ORDER BY created_at`, ids),
    ]);
    const group = (arr, key, map) => arr.reduce((acc, row) => {
      (acc[row[key]] = acc[row[key]] || []).push(map(row)); return acc;
    }, {});
    const vByVid = group(versions, 'video_id', rowToVersion);
    const cByVid = group(comments, 'video_id', rowToComment);
    const hByVid = group(history, 'video_id', rowToHistory);
    const rByVid = group(reasons, 'video_id', (r) => ({ reason: r.reason, by: r.by_name, toUserId: r.to_user_id, fromStage: r.from_stage, at: r.created_at }));

    res.json(rows.map(r => ({
      ...rowToVideo(r),
      versions: vByVid[r.id] || [],
      comments: cByVid[r.id] || [],
      history: hByVid[r.id] || [],
      reasons: rByVid[r.id] || [],
    })));
  } catch (e) { next(e); }
});

// ---------- GET ----------
router.get('/:id', requirePermission('video.read.own'), loadVideo, async (req, res, next) => {
  try {
    const v = req.video;
    if (req.permissionScope !== 'full' && !userInvolved(req.user.id, v)) {
      return res.status(403).json({ error: 'FORBIDDEN' });
    }
    const [versions, comments, history] = await Promise.all([
      q('SELECT * FROM video_versions WHERE video_id = ? ORDER BY uploaded_at', [v.id]),
      q('SELECT * FROM comments WHERE video_id = ? ORDER BY created_at', [v.id]),
      q('SELECT * FROM workflow_history WHERE video_id = ? ORDER BY at', [v.id]),
    ]);
    res.json({
      ...rowToVideo(v),
      versions: versions.map(rowToVersion),
      comments: comments.map(rowToComment),
      history: history.map(rowToHistory),
    });
  } catch (e) { next(e); }
});

// ---------- CREATE (doctor uploads a new video record) ----------
const videoCreate = z.object({
  title: z.string().min(3).max(240),
  description: z.string().max(2000).optional(),
  duration: z.number().int().positive().max(36000).optional(),
});

router.post('/', requirePermission('video.upload'), async (req, res, next) => {
  try {
    const body = videoCreate.parse(req.body);
    const id = ulid();
    // Auto-assign an editor (round-robin in production; random here)
    const editors = await q(`SELECT id FROM users WHERE role = 'EDITOR' AND active = 1`);
    const editor = editors[Math.floor(Math.random() * editors.length)]?.id || null;
    const classification = classifyTitle(body.title + ' ' + (body.description || ''));
    const retentionDays = { PHI: 2555, INTERNAL: 1095, PUBLIC: 730 }[classification];

    await tx(async (conn) => {
      await conn.query(
        `INSERT INTO videos (id, title, description, status, classification, duration_seconds, thumb_seed,
                             uploader_id, editor_id, purge_after)
         VALUES (?, ?, ?, 'EDITING', ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ? DAY))`,
        [id, body.title, body.description || null, classification, body.duration || 240,
          Math.floor(Math.random() * 6), req.user.id, editor, retentionDays]
      );
      await conn.query(
        `INSERT INTO workflow_history (video_id, action, actor_id, actor_name, label)
         VALUES (?, 'CREATED', ?, ?, ?)`,
        [id, req.user.id, await actorName(req.user.id), `uploaded "${body.title}"`]
      );
      if (editor) {
        const eName = await actorName(editor);
        await conn.query(
          `INSERT INTO workflow_history (video_id, action, actor_id, actor_name, label)
           VALUES (?, 'ASSIGNED', NULL, 'Workflow Bot', ?)`,
          [id, `assigned to editor ${eName}`]
        );
        await conn.query(
          `INSERT INTO notifications (id, user_id, type, text, video_id) VALUES (?, ?, 'ASSIGNED', ?, ?)`,
          [ulid(), editor, `You were assigned to edit "${body.title}"`, id]
        );
      }
    });
    await req.audit({ action: 'VIDEO_UPLOAD', resourceType: 'video', resourceId: id, resourceLabel: body.title, metadata: { classification } });

    const created = await one('SELECT * FROM videos WHERE id = ?', [id]);
    res.status(201).json(rowToVideo(created));
  } catch (e) { next(e); }
});

// ---------- VERSIONS (presigned uploads) ----------
const uploadUrlSchema = z.object({
  kind: z.enum(['raw','edit']),
  fileName: z.string().min(1).max(200),
  sizeBytes: z.number().int().positive().max(8 * 1024 * 1024 * 1024), // 8 GB
  mime: z.string().regex(/^(video|application)\//).optional(),
});

// Resource-based authz for uploads: the doctor who created the video owns the
// 'raw' recording; the assigned editor owns 'edit' cuts. Admins can do either.
function canUploadKind(user, video, kind) {
  if (user.role === 'ADMIN') return true;
  if (kind === 'raw')  return video.uploader_id === user.id;
  if (kind === 'edit') return video.editor_id === user.id;
  return false;
}

router.post('/:id/versions/upload-url', loadVideo, async (req, res, next) => {
  try {
    const body = uploadUrlSchema.parse(req.body);
    if (!canUploadKind(req.user, req.video, body.kind)) {
      return res.status(403).json({ error: 'FORBIDDEN', message: `Not allowed to upload a ${body.kind} version to this video.` });
    }
    const { url, bucket, key } = await presignUpload({ kind: body.kind, videoId: req.video.id, fileName: body.fileName, mime: body.mime });
    res.json({ url, bucket, key, expiresIn: 300 });
  } catch (e) { next(e); }
});

const versionFinalize = z.object({
  kind: z.enum(['raw','edit']),
  label: z.string().min(1),
  fileName: z.string().min(1),
  storageKey: z.string().min(1),
  storageBucket: z.string().min(1),
  sizeBytes: z.number().int().nonnegative(),
  mime: z.string().optional(),
  checksum: z.string().optional(),
  notes: z.string().max(500).optional(),
});

router.post('/:id/versions', loadVideo, async (req, res, next) => {
  try {
    const body = versionFinalize.parse(req.body);
    if (!canUploadKind(req.user, req.video, body.kind)) {
      return res.status(403).json({ error: 'FORBIDDEN', message: `Not allowed to add a ${body.kind} version to this video.` });
    }
    if (body.kind === 'edit' && req.video.editor_id !== req.user.id && req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'NOT_ASSIGNED' });
    }
    const id = ulid();
    await q(
      `INSERT INTO video_versions (id, video_id, kind, label, file_name, storage_key, storage_bucket, size_bytes, mime_type, checksum_sha256, notes, uploaded_by)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
      [id, req.video.id, body.kind, body.label, body.fileName, body.storageKey, body.storageBucket,
        body.sizeBytes, body.mime || 'video/mp4', body.checksum || null, body.notes || null, req.user.id]
    );
    await req.audit({ action: 'VIDEO_VERSION_UPLOAD', resourceType: 'video', resourceId: req.video.id, resourceLabel: req.video.title, metadata: { versionId: id, kind: body.kind, sizeBytes: body.sizeBytes } });
    const row = await one('SELECT * FROM video_versions WHERE id = ?', [id]);
    res.status(201).json(rowToVersion(row));
  } catch (e) { next(e); }
});

router.get('/versions/:versionId/download-url', requireAuth, async (req, res, next) => {
  try {
    const v = await one(`SELECT v.*, vid.uploader_id, vid.editor_id, vid.writer_id, vid.peer_approver_id, vid.final_approver_id, vid.social_id
                         FROM video_versions v JOIN videos vid ON vid.id = v.video_id WHERE v.id = ? LIMIT 1`, [req.params.versionId]);
    if (!v) return res.status(404).json({ error: 'NOT_FOUND' });
    // Permission check: ADMIN or involved party.
    if (req.user.role !== 'ADMIN' && ![v.uploader_id, v.editor_id, v.writer_id, v.peer_approver_id, v.final_approver_id, v.social_id].includes(req.user.id)) {
      return res.status(403).json({ error: 'FORBIDDEN' });
    }
    const { url } = await presignDownload({ bucket: v.storage_bucket, key: v.storage_key });
    await req.audit({ action: 'VIDEO_DOWNLOAD', resourceType: 'video', resourceId: v.video_id, metadata: { versionId: v.id, kind: v.kind } });
    res.json({ url, expiresIn: 300 });
  } catch (e) { next(e); }
});

// ---------- WORKFLOW TRANSITIONS ----------
router.post('/:id/complete-editing', requirePermission('video.upload.edit'), loadVideo, async (req, res, next) => {
  try {
    if (req.video.editor_id !== req.user.id && req.user.role !== 'ADMIN') return res.status(403).json({ error: 'NOT_ASSIGNED' });
    // Assign a writer on handoff (mirrors editor auto-assignment at create time).
    const writer = req.video.writer_id || (await one(`SELECT id FROM users WHERE role='WRITER' AND active=1 ORDER BY created_at, id LIMIT 1`))?.id;
    await tx(async (conn) => {
      await conn.query(`UPDATE videos SET status = 'WRITING', writer_id = ? WHERE id = ?`, [writer, req.video.id]);
      await conn.query(`INSERT INTO workflow_history (video_id, action, actor_id, actor_name, label) VALUES (?, 'EDITED', ?, ?, 'completed editing')`,
        [req.video.id, req.user.id, await actorName(req.user.id)]);
      if (writer) {
        await conn.query(`INSERT INTO notifications (id, user_id, type, text, video_id) VALUES (?, ?, 'ASSIGNED', ?, ?)`,
          [ulid(), writer, `"${req.video.title}" is ready for captions`, req.video.id]);
      }
    });
    await req.audit({ action: 'COMPLETE_EDITING', resourceType: 'video', resourceId: req.video.id });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

const submitSchema = z.object({
  captions: z.string().min(1),
  hashtags: z.array(z.string()).default([]),
  platforms: z.array(z.string()).min(1),
});

router.post('/:id/submit-for-review', requirePermission('workflow.write_captions'), loadVideo, async (req, res, next) => {
  try {
    if (req.video.writer_id !== req.user.id && req.user.role !== 'ADMIN') return res.status(403).json({ error: 'NOT_ASSIGNED' });
    const body = submitSchema.parse(req.body);
    const peer = req.video.peer_approver_id || (await one(`SELECT id FROM users WHERE role='APPROVER' AND approver_tier='peer' AND active=1 ORDER BY created_at, id LIMIT 1`))?.id;
    await tx(async (conn) => {
      await conn.query(
        `UPDATE videos SET status='PEER_REVIEW', captions=?, hashtags_json=?, platforms_json=?, peer_approver_id=? WHERE id = ?`,
        [body.captions, JSON.stringify(body.hashtags), JSON.stringify(body.platforms), peer, req.video.id]
      );
      await conn.query(`INSERT INTO workflow_history (video_id, action, actor_id, actor_name, label) VALUES (?, 'WRITTEN', ?, ?, 'submitted captions for peer review')`,
        [req.video.id, req.user.id, await actorName(req.user.id)]);
      if (peer) {
        await conn.query(`INSERT INTO notifications (id, user_id, type, text, video_id) VALUES (?, ?, 'PEER_REVIEW', ?, ?)`,
          [ulid(), peer, `"${req.video.title}" is awaiting your peer review`, req.video.id]);
      }
    });
    await req.audit({ action: 'SUBMIT_FOR_REVIEW', resourceType: 'video', resourceId: req.video.id });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.post('/:id/peer-approve', requirePermission('workflow.peer_approve'), requireTier('peer'), loadVideo, async (req, res, next) => {
  try {
    if (req.video.peer_approver_id !== req.user.id && req.user.role !== 'ADMIN') return res.status(403).json({ error: 'NOT_ASSIGNED' });
    const finalApprover = req.video.final_approver_id || (await one(`SELECT id FROM users WHERE role='APPROVER' AND approver_tier='final' AND active=1 ORDER BY created_at, id LIMIT 1`))?.id;
    await tx(async (conn) => {
      await conn.query(`UPDATE videos SET status='FINAL_REVIEW', final_approver_id = ? WHERE id = ?`, [finalApprover, req.video.id]);
      await conn.query(`INSERT INTO workflow_history (video_id, action, actor_id, actor_name, label) VALUES (?, 'PEER_APPROVED', ?, ?, 'cleared peer review (Stage 1)')`,
        [req.video.id, req.user.id, await actorName(req.user.id)]);
      if (finalApprover) {
        await conn.query(`INSERT INTO notifications (id, user_id, type, text, video_id) VALUES (?, ?, 'FINAL_REVIEW', ?, ?)`,
          [ulid(), finalApprover, `"${req.video.title}" is awaiting final approval (Stage 2)`, req.video.id]);
      }
    });
    await req.audit({ action: 'PEER_APPROVE', resourceType: 'video', resourceId: req.video.id, metadata: { stage: 1 } });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.post('/:id/final-approve', requirePermission('workflow.final_approve'), requireTier('final'), loadVideo, async (req, res, next) => {
  try {
    if (req.video.final_approver_id !== req.user.id && req.user.role !== 'ADMIN') return res.status(403).json({ error: 'NOT_ASSIGNED' });
    const social = req.video.social_id || (await one(`SELECT id FROM users WHERE role='SOCIAL' AND active=1 ORDER BY created_at, id LIMIT 1`))?.id;
    await tx(async (conn) => {
      await conn.query(`UPDATE videos SET status='APPROVED', social_id = ? WHERE id = ?`, [social, req.video.id]);
      await conn.query(`INSERT INTO workflow_history (video_id, action, actor_id, actor_name, label) VALUES (?, 'FINAL_APPROVED', ?, ?, 'final approval — cleared for publishing (Stage 2)')`,
        [req.video.id, req.user.id, await actorName(req.user.id)]);
      if (social) {
        await conn.query(`INSERT INTO notifications (id, user_id, type, text, video_id) VALUES (?, ?, 'APPROVED', ?, ?)`,
          [ulid(), social, `"${req.video.title}" has cleared final approval — ready to publish`, req.video.id]);
      }
    });
    await req.audit({ action: 'FINAL_APPROVE', resourceType: 'video', resourceId: req.video.id, metadata: { stage: 2 } });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

const sendBackSchema = z.object({
  toUserId: z.string().min(1),
  reason: z.string().min(3).max(2000),
  fromStage: z.enum(['peer','final']),
});

router.post('/:id/send-back', requirePermission('workflow.send_back'), loadVideo, async (req, res, next) => {
  try {
    const body = sendBackSchema.parse(req.body);
    const target = await one('SELECT * FROM users WHERE id = ?', [body.toUserId]);
    if (!target) return res.status(404).json({ error: 'TARGET_NOT_FOUND' });
    let nextStatus = 'EDITING';
    const patches = [];
    const params = [];
    if (target.role === 'EDITOR') { nextStatus = 'EDITING'; patches.push('editor_id = ?'); params.push(target.id); }
    else if (target.role === 'WRITER') { nextStatus = 'WRITING'; patches.push('writer_id = ?'); params.push(target.id); }
    else if (target.role === 'APPROVER' && target.approver_tier === 'peer') { nextStatus = 'PEER_REVIEW'; patches.push('peer_approver_id = ?'); params.push(target.id); }
    patches.unshift('status = ?'); params.unshift(nextStatus);
    params.push(req.video.id);
    await tx(async (conn) => {
      await conn.query(`UPDATE videos SET ${patches.join(', ')} WHERE id = ?`, params);
      await conn.query(`INSERT INTO rejection_reasons (video_id, reason, by_user_id, by_name, to_user_id, from_stage) VALUES (?,?,?,?,?,?)`,
        [req.video.id, body.reason, req.user.id, await actorName(req.user.id), target.id, body.fromStage]);
      await conn.query(`INSERT INTO workflow_history (video_id, action, actor_id, actor_name, label) VALUES (?, 'REJECTED', ?, ?, ?)`,
        [req.video.id, req.user.id, await actorName(req.user.id), `sent back to ${target.name}: ${body.reason.slice(0,120)}`]);
      await conn.query(`INSERT INTO notifications (id, user_id, type, text, video_id) VALUES (?, ?, 'REJECTED', ?, ?)`,
        [ulid(), target.id, `"${req.video.title}" needs changes: ${body.reason.slice(0,140)}`, req.video.id]);
    });
    await req.audit({ action: 'SEND_BACK', resourceType: 'video', resourceId: req.video.id, metadata: { toUserId: target.id, fromStage: body.fromStage } });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

const publishSchema = z.object({ platforms: z.array(z.string()).min(1) });
router.post('/:id/publish', requirePermission('workflow.publish'), loadVideo, async (req, res, next) => {
  try {
    if (req.video.social_id !== req.user.id && req.user.role !== 'ADMIN') return res.status(403).json({ error: 'NOT_ASSIGNED' });
    const body = publishSchema.parse(req.body);
    await tx(async (conn) => {
      await conn.query(`UPDATE videos SET status='PUBLISHED', classification='PUBLIC', platforms_json=?, published_at=NOW() WHERE id = ?`,
        [JSON.stringify(body.platforms), req.video.id]);
      await conn.query(`INSERT INTO workflow_history (video_id, action, actor_id, actor_name, label) VALUES (?, 'PUBLISHED', ?, ?, ?)`,
        [req.video.id, req.user.id, await actorName(req.user.id), `published to ${body.platforms.join(', ')}`]);
      await conn.query(`INSERT INTO notifications (id, user_id, type, text, video_id) VALUES (?, ?, 'PUBLISHED', ?, ?)`,
        [ulid(), req.video.uploader_id, `"${req.video.title}" went live on ${body.platforms.join(', ')}`, req.video.id]);
    });
    await req.audit({ action: 'PUBLISH', resourceType: 'video', resourceId: req.video.id, metadata: { platforms: body.platforms } });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// ---------- COMMENTS ----------
const commentSchema = z.object({ body: z.string().min(1).max(2000) });
router.get('/:id/comments', loadVideo, async (req, res, next) => {
  try {
    const rows = await q('SELECT * FROM comments WHERE video_id = ? ORDER BY created_at', [req.video.id]);
    res.json(rows.map(rowToComment));
  } catch (e) { next(e); }
});
router.post('/:id/comments', loadVideo, async (req, res, next) => {
  try {
    const { body } = commentSchema.parse(req.body);
    const id = ulid();
    await q(`INSERT INTO comments (id, video_id, author_id, body) VALUES (?,?,?,?)`,
      [id, req.video.id, req.user.id, body]);
    if (req.video.uploader_id !== req.user.id) {
      await q(`INSERT INTO notifications (id, user_id, type, text, video_id) VALUES (?, ?, 'COMMENT', ?, ?)`,
        [ulid(), req.video.uploader_id, `${await actorName(req.user.id)} commented on "${req.video.title}"`, req.video.id]);
    }
    await req.audit({ action: 'COMMENT_ADD', resourceType: 'video', resourceId: req.video.id });
    res.status(201).json({ id });
  } catch (e) { next(e); }
});

// ---------- Helpers ----------
async function loadVideo(req, res, next) {
  try {
    const v = await one('SELECT * FROM videos WHERE id = ?', [req.params.id]);
    if (!v) return res.status(404).json({ error: 'VIDEO_NOT_FOUND' });
    req.video = v;
    next();
  } catch (e) { next(e); }
}

const _nameCache = new Map();
async function actorName(userId) {
  if (_nameCache.has(userId)) return _nameCache.get(userId);
  const r = await one('SELECT name FROM users WHERE id = ?', [userId]);
  const n = r?.name || 'Unknown';
  _nameCache.set(userId, n);
  return n;
}

function userInvolved(uid, v) {
  return [v.uploader_id, v.editor_id, v.writer_id, v.peer_approver_id, v.final_approver_id, v.social_id].includes(uid);
}

function classifyTitle(text) {
  if (/diabet|migraine|cholesterol|hypertens|pcos|anxiety|asthma|sleep apnea|gerd|lab report|iron deficiency|thyroid/i.test(text)) return 'PHI';
  return 'INTERNAL';
}

export default router;
