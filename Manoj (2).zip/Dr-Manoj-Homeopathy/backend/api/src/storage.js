// S3 / MinIO presigner — issues short-lived PUT/GET URLs so the browser uploads
// and downloads video files directly to/from object storage. The API never
// proxies binary content — least privilege at the network layer.
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

// IMPORTANT — AWS S3 vs MinIO:
//   • Real AWS S3   → leave S3_ENDPOINT EMPTY and S3_FORCE_PATH_STYLE=false.
//                     The SDK derives the correct regional, virtual-hosted endpoint
//                     (bucket.s3.<region>.amazonaws.com) and signs it with SigV4.
//   • Self-hosted MinIO → set S3_ENDPOINT=http://host:9000 and S3_FORCE_PATH_STYLE=true.
//
// Passing endpoint:'' or forcePathStyle:true to AWS is the #1 cause of "presign
// succeeds but the upload 403s / signature mismatch". So we only attach those
// options when a custom endpoint is actually configured.
const customEndpoint = (process.env.S3_ENDPOINT || '').trim();

const s3Config = {
  region: process.env.S3_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY,
    secretAccessKey: process.env.S3_SECRET_KEY,
  },
};
if (customEndpoint) {
  // MinIO / S3-compatible store — explicit endpoint + path-style addressing.
  s3Config.endpoint = customEndpoint;
  s3Config.forcePathStyle = process.env.S3_FORCE_PATH_STYLE === 'true';
}
// else: real AWS S3 — no endpoint, virtual-hosted style (forcePathStyle stays false).

const s3 = new S3Client(s3Config);

const bucketFor = (kind) => kind === 'raw'
  ? (process.env.S3_BUCKET_RAW  || 'clinicast-raw')
  : (process.env.S3_BUCKET_EDIT || 'clinicast-edit');

export async function presignUpload({ kind, videoId, fileName, mime }) {
  const bucket = bucketFor(kind);
  const safe = fileName.replace(/[^\w.\-]/g, '_').slice(0, 200);
  const key = `${videoId}/${Date.now()}_${safe}`;
  const cmd = new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    ContentType: mime || 'video/mp4',
    // ServerSideEncryption: 'aws:kms', KMSKeyId: process.env.S3_KMS_KEY_ID, // production
  });
  const url = await getSignedUrl(s3, cmd, { expiresIn: 300 });   // 5 min
  return { url, bucket, key };
}

export async function presignDownload({ bucket, key }) {
  const cmd = new GetObjectCommand({ Bucket: bucket, Key: key });
  const url = await getSignedUrl(s3, cmd, { expiresIn: 300 });
  return { url };
}

// Startup connectivity probe — call from server boot. Fails loudly with an
// actionable message instead of letting uploads silently 403 at runtime.
export async function checkStorage() {
  const mode = customEndpoint ? `custom endpoint ${customEndpoint} (path-style=${s3Config.forcePathStyle})` : `AWS S3 region ${s3Config.region} (virtual-hosted)`;
  if (!process.env.S3_ACCESS_KEY || !process.env.S3_SECRET_KEY) {
    throw new Error('S3 credentials missing — set S3_ACCESS_KEY and S3_SECRET_KEY.');
  }
  if (!customEndpoint && process.env.S3_FORCE_PATH_STYLE === 'true') {
    console.warn('[storage] WARNING: S3_FORCE_PATH_STYLE=true with no S3_ENDPOINT. For real AWS S3 this should be false — presigned uploads will likely 403. Ignoring it.');
  }
  // HeadBucket verifies the bucket exists, the region is correct, and creds can reach it.
  const { HeadBucketCommand } = await import('@aws-sdk/client-s3');
  for (const [label, bucket] of [['RAW', bucketFor('raw')], ['EDIT', bucketFor('edit')]]) {
    try {
      await s3.send(new HeadBucketCommand({ Bucket: bucket }));
    } catch (e) {
      const code = e?.$metadata?.httpStatusCode;
      let hint = '';
      if (code === 301 || /PermanentRedirect|region/i.test(e?.message || '')) hint = ` — wrong S3_REGION for this bucket (a 301 means the bucket lives in a different region).`;
      else if (code === 403) hint = ` — credentials reached AWS but lack s3:ListBucket/s3:HeadBucket on "${bucket}", or the bucket belongs to another account.`;
      else if (code === 404) hint = ` — bucket "${bucket}" does not exist in region ${s3Config.region}.`;
      throw new Error(`S3 ${label} bucket check failed (${mode})${hint} [${e.name}: ${e.message}]`);
    }
  }
  console.log(`[storage] ✓ S3 reachable — ${mode}; buckets OK (${bucketFor('raw')}, ${bucketFor('edit')}).`);
  return true;
}
