// ============================================================================
// Smoke test — end-to-end verification of the live API against a real
// MySQL + S3/MinIO stack. Run AFTER `docker compose up` + `npm run seed`.
//
//   npm run smoke
//   API_URL=https://api.yourhost.com/api npm run smoke   # against a remote env
//
// NOTE: this suite makes many logins from one IP. The per-IP login limiter
// (LOGIN_RATE_LIMIT, default 10/min) would throttle it, so run the API with a
// raised limit for the test, e.g.:
//   LOGIN_RATE_LIMIT=1000 node src/server.js
// The SEC-4 test validates PER-ACCOUNT lockout (independent of the IP limit),
// so raising the IP limit does not weaken what it proves.
//
// It exercises the FULL workflow across every role and prints a pass/fail
// report. Exits 0 if everything passes, 1 otherwise — wire it into CI.
//
// No dependencies: uses Node 20's built-in global fetch.
// ============================================================================

const BASE = process.env.API_URL || 'http://localhost:4000/api';
const PASSWORD = process.env.SMOKE_PASSWORD || 'demo1234';

const ACCOUNTS = {
  admin:  'sarah.mitchell@drmanojhomeopathy.com',
  doctor: 'dr.manoj@drmanojhomeopathy.com',
  editor: 'priya.shah@drmanojhomeopathy.com',
  writer: 'lena.okafor@drmanojhomeopathy.com',
  peer:   'hannah.park@drmanojhomeopathy.com',
  final:  'olivia.tran@drmanojhomeopathy.com',
  social: 'yusuf.bello@drmanojhomeopathy.com',
};

let passed = 0, failed = 0;
const results = [];
function ok(name)        { passed++; results.push(`  \x1b[32m✓\x1b[0m ${name}`); }
function bad(name, err)  { failed++; results.push(`  \x1b[31m✗\x1b[0m ${name} — ${err}`); }
async function check(name, fn) {
  try { await fn(); ok(name); }
  catch (e) { bad(name, e.message || String(e)); }
}

const tokens = {};         // role -> { access, refresh }
async function api(path, { method = 'GET', body, role } = {}) {
  const headers = { 'content-type': 'application/json' };
  if (role && tokens[role]) headers.authorization = `Bearer ${tokens[role].access}`;
  const res = await fetch(`${BASE}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let json = null; try { json = text ? JSON.parse(text) : null; } catch (e) {}
  if (!res.ok) {
    const err = new Error(`HTTP ${res.status} ${json?.error || text?.slice(0, 120) || ''}`);
    err.status = res.status; err.json = json;
    throw err;
  }
  return json;
}
async function login(role) {
  const j = await api('/auth/login', { method: 'POST', body: { email: ACCOUNTS[role], password: PASSWORD } });
  if (!j.access_token || !j.refresh_token || !j.user) throw new Error('missing tokens/user in login response');
  tokens[role] = { access: j.access_token, refresh: j.refresh_token, user: j.user };
  return j.user;
}
// Log in by arbitrary email and stash under the special '_assignedEditor' slot
// (used when the auto-assigned editor isn't the default ACCOUNTS.editor).
async function login2(email) {
  const j = await api('/auth/login', { method: 'POST', body: { email, password: PASSWORD } });
  if (!j.access_token) throw new Error('login2 failed for ' + email);
  tokens['_assignedEditor'] = { access: j.access_token, refresh: j.refresh_token, user: j.user };
  return j.user;
}
function assert(cond, msg) { if (!cond) throw new Error(msg); }

(async () => {
  console.log(`\nClinicast API smoke test → ${BASE}\n`);

  // ---- Health ----
  await check('GET /health returns ok + db reachable', async () => {
    const j = await api('/health');
    assert(j.status === 'ok', `health status was "${j.status}" (is MySQL connected?)`);
  });

  // ---- Auth ----
  await check('Login as every role (password verified against SQL)', async () => {
    for (const role of Object.keys(ACCOUNTS)) await login(role);
  });
  await check('Login rejects a wrong password (401)', async () => {
    try { await api('/auth/login', { method: 'POST', body: { email: ACCOUNTS.doctor, password: 'wrong-password' } }); throw new Error('expected 401'); }
    catch (e) { assert(e.status === 401, `expected 401, got ${e.status}`); }
  });
  await check('Refresh token issues a fresh access token', async () => {
    const j = await api('/auth/refresh', { method: 'POST', body: { refresh_token: tokens.doctor.refresh } });
    assert(j.access_token && j.refresh_token, 'refresh did not return new tokens');
    tokens.doctor.access = j.access_token; tokens.doctor.refresh = j.refresh_token;
  });
  await check('GET /auth/me returns the signed-in user', async () => {
    const me = await api('/auth/me', { role: 'admin' });
    assert(me.role === 'ADMIN', `expected ADMIN, got ${me.role}`);
  });
  await check('Unauthenticated request is rejected (401)', async () => {
    try { await api('/videos'); throw new Error('expected 401'); }
    catch (e) { assert(e.status === 401, `expected 401, got ${e.status}`); }
  });

  // ---- RBAC ----
  await check('RBAC: doctor CANNOT list all users (403)', async () => {
    try { await api('/users', { role: 'doctor' }); throw new Error('expected 403'); }
    catch (e) { assert(e.status === 403 || e.status === 401, `expected 403, got ${e.status}`); }
  });
  await check('RBAC: admin CAN list users', async () => {
    const users = await api('/users', { role: 'admin' });
    assert(Array.isArray(users) && users.length >= 7, 'expected the seeded users');
  });

  // ---- Full workflow ----
  let videoId, editorRole = 'editor';
  await check('Doctor creates a video (status EDITING)', async () => {
    const v = await api('/videos', { method: 'POST', role: 'doctor', body: { title: 'Smoke Test — Managing Seasonal Allergies', description: 'E2E smoke test video', duration: 200 } });
    assert(v.id, 'no video id returned');
    assert(v.status === 'EDITING', `expected EDITING, got ${v.status}`);
    videoId = v.id;
  });
  await check('Doctor uploads the RAW recording to S3 (presign + finalize)', async () => {
    const pre = await api(`/videos/${videoId}/versions/upload-url`, { method: 'POST', role: 'doctor', body: { kind: 'raw', fileName: 'smoke_raw.mov', sizeBytes: 40_000_000, mime: 'video/quicktime' } });
    assert(pre.url && pre.key && pre.bucket, 'no presigned URL for raw upload (S3/MinIO env + bucket?)');
    // PUT the bytes directly to the presigned URL — proves S3 actually accepts the upload.
    const put = await fetch(pre.url, { method: 'PUT', headers: { 'content-type': 'video/quicktime' }, body: new Uint8Array(1024) });
    assert(put.ok, `S3 PUT failed (HTTP ${put.status}) — bucket policy/region/CORS?`);
    const ver = await api(`/videos/${videoId}/versions`, { method: 'POST', role: 'doctor', body: {
      kind: 'raw', label: 'Original recording', fileName: 'smoke_raw.mov',
      storageKey: pre.key, storageBucket: pre.bucket, sizeBytes: 40_000_000, mime: 'video/quicktime',
    } });
    assert(ver.id, 'raw version not finalized');
  });
  await check('Resolve the auto-assigned editor + log in as them', async () => {
    const v = await api(`/videos/${videoId}`, { role: 'doctor' });
    assert(v.editor, 'video has no assigned editor');
    const users = await api('/users', { role: 'admin' });
    const editor = users.find(u => u.id === v.editor);
    assert(editor, 'assigned editor not found in users');
    if (editor.email !== ACCOUNTS.editor) { await login2(editor.email); editorRole = '_assignedEditor'; }
  });
  await check('Editor presigns + uploads the edited cut to S3', async () => {
    const pre = await api(`/videos/${videoId}/versions/upload-url`, { method: 'POST', role: editorRole, body: { kind: 'edit', fileName: 'smoke_edit_v1.mp4', sizeBytes: 12_000_000, mime: 'video/mp4' } });
    assert(typeof pre.url === 'string' && pre.url.length > 0, 'no presigned URL (check S3/MinIO env + bucket)');
    assert(pre.key && pre.bucket, 'presign missing key/bucket');
    const put = await fetch(pre.url, { method: 'PUT', headers: { 'content-type': 'video/mp4' }, body: new Uint8Array(2048) });
    assert(put.ok, `S3 PUT failed (HTTP ${put.status})`);
    globalThis.__ver = pre;
  });
  await check('Editor finalizes the version record', async () => {
    const v = await api(`/videos/${videoId}/versions`, { method: 'POST', role: editorRole, body: {
      kind: 'edit', label: 'Edited cut · v1', fileName: 'smoke_edit_v1.mp4',
      storageKey: globalThis.__ver.key, storageBucket: globalThis.__ver.bucket, sizeBytes: 12_000_000, mime: 'video/mp4',
    } });
    assert(v.id, 'no version id returned');
  });
  await check('Editor completes editing → WRITING', async () => {
    await api(`/videos/${videoId}/complete-editing`, { method: 'POST', role: editorRole });
    const v = await api(`/videos/${videoId}`, { role: editorRole });
    assert(v.status === 'WRITING', `expected WRITING, got ${v.status}`);
    assert(Array.isArray(v.versions) && v.versions.length >= 2, 'detail did not include both raw + edit versions');
  });
  await check('Writer submits captions → PEER_REVIEW', async () => {
    await api(`/videos/${videoId}/submit-for-review`, { method: 'POST', role: 'writer', body: { captions: 'Sneezing every spring? Here is what actually helps.', hashtags: ['#Allergies', '#Homeopathy'], platforms: ['Instagram', 'YouTube'] } });
    const v = await api(`/videos/${videoId}`, { role: 'writer' });
    assert(v.status === 'PEER_REVIEW', `expected PEER_REVIEW, got ${v.status}`);
  });
  await check('Stage-1 reviewer peer-approves → FINAL_REVIEW', async () => {
    await api(`/videos/${videoId}/peer-approve`, { method: 'POST', role: 'peer' });
    const v = await api(`/videos/${videoId}`, { role: 'peer' });
    assert(v.status === 'FINAL_REVIEW', `expected FINAL_REVIEW, got ${v.status}`);
  });
  await check('RBAC: a Stage-1 reviewer CANNOT final-approve (403)', async () => {
    try { await api(`/videos/${videoId}/final-approve`, { method: 'POST', role: 'peer' }); throw new Error('expected 403'); }
    catch (e) { assert(e.status === 403 || e.status === 401, `expected 403, got ${e.status}`); }
  });
  await check('Stage-2 reviewer final-approves → APPROVED', async () => {
    await api(`/videos/${videoId}/final-approve`, { method: 'POST', role: 'final' });
    const v = await api(`/videos/${videoId}`, { role: 'final' });
    assert(v.status === 'APPROVED', `expected APPROVED, got ${v.status}`);
  });
  await check('Social publishes → PUBLISHED (+ classification PUBLIC)', async () => {
    await api(`/videos/${videoId}/publish`, { method: 'POST', role: 'social', body: { platforms: ['Instagram', 'YouTube'] } });
    const v = await api(`/videos/${videoId}`, { role: 'social' });
    assert(v.status === 'PUBLISHED', `expected PUBLISHED, got ${v.status}`);
    assert(v.classification === 'PUBLIC', `expected PUBLIC, got ${v.classification}`);
  });
  await check('Comment thread works + notifies uploader', async () => {
    await api(`/videos/${videoId}/comments`, { method: 'POST', role: 'editor', body: { body: 'Great topic for spring.' } });
    const comments = await api(`/videos/${videoId}/comments`, { role: 'doctor' });
    assert(comments.length >= 1, 'no comments returned');
  });
  await check('Workflow history captured every transition', async () => {
    const v = await api(`/videos/${videoId}`, { role: 'admin' });
    const actions = (v.history || []).map(h => h.action);
    for (const a of ['CREATED', 'EDITED', 'WRITTEN', 'PEER_APPROVED', 'FINAL_APPROVED', 'PUBLISHED']) {
      assert(actions.includes(a), `history missing ${a}`);
    }
  });

  // ---- Notifications ----
  await check('Notifications were generated for the workflow', async () => {
    const n = await api('/notifications', { role: 'social' });
    assert(Array.isArray(n), 'notifications not an array');
  });

  // ---- User management ----
  let newUserId;
  await check('Admin creates a user', async () => {
    const u = await api('/users', { method: 'POST', role: 'admin', body: { name: 'Smoke Test Writer', email: `smoke+${Date.now()}@drmanojhomeopathy.com`, phone: '+91 90000 00000', role: 'WRITER', specialty: 'Test' } });
    assert(u.id, 'no user id returned');
    newUserId = u.id;
  });
  await check('Admin deactivates the user', async () => {
    await api(`/users/${newUserId}`, { method: 'PATCH', role: 'admin', body: { active: false } });
  });
  await check('Admin deletes the user', async () => {
    await api(`/users/${newUserId}`, { method: 'DELETE', role: 'admin' });
  });

  // ---- Governance ----
  await check('Audit log is populated + admin-readable', async () => {
    const audit = await api('/governance/audit', { role: 'admin' });
    assert(Array.isArray(audit) && audit.length > 0, 'audit log empty');
  });
  await check('RBAC matrix endpoint returns permissions', async () => {
    const m = await api('/governance/rbac', { role: 'admin' });
    assert(m, 'no rbac matrix');
  });

  // ---- Logout ----
  await check('Logout revokes the session', async () => {
    await api('/auth/logout', { method: 'POST', role: 'social' });
  });

  // ---- SEC-2: session revocation is enforced on the access token ----
  await check('SEC-2 · access token is rejected immediately after logout', async () => {
    // 'social' just logged out above; its access token is still unexpired but the
    // session is revoked. A protected call MUST now 401 (not wait out the TTL).
    try {
      await api('/notifications', { role: 'social' });
      throw new Error('expected 401 after logout — token still worked (SEC-2 not enforced)');
    } catch (e) {
      assert(e.status === 401, `expected 401 SESSION_REVOKED, got ${e.status}`);
    }
  });

  // ---- SEC-4: per-account lockout after repeated bad passwords ----
  await check('SEC-4 · account locks after repeated failed logins', async () => {
    // Use a disposable account so a real user isn't locked for 15 min (keeps the
    // suite re-runnable in CI). Admin creates it, we hammer it, then delete it.
    const email = `lockout+${Date.now()}@drmanojhomeopathy.com`;
    const victim = await api('/users', { method: 'POST', role: 'admin', body: { name: 'Lockout Victim', email, phone: '+91 90000 00001', role: 'WRITER', specialty: 'Test' } });
    for (let i = 0; i < 7; i++) {
      try { await api('/auth/login', { method: 'POST', body: { email, password: 'definitely-wrong' } }); }
      catch (e) { /* 401/429 expected */ }
    }
    // Even the *correct* password must now be refused while locked. (New users
    // have no password set, so this also can't succeed — either way it must fail.)
    let failedWhileLocked = false;
    try {
      await api('/auth/login', { method: 'POST', body: { email, password: PASSWORD } });
    } catch (e) {
      failedWhileLocked = e.status === 401 || e.status === 429;
    }
    await api(`/users/${victim.id}`, { method: 'DELETE', role: 'admin' }); // cleanup
    assert(failedWhileLocked, 'expected the account to be locked/refused after repeated failures');
  });

  // ---- Report ----
  console.log(results.join('\n'));
  console.log(`\n${failed === 0 ? '\x1b[32m' : '\x1b[31m'}${passed}/${passed + failed} checks passed\x1b[0m\n`);
  process.exit(failed === 0 ? 0 : 1);
})().catch(e => {
  console.error('\n\x1b[31mSmoke test harness crashed:\x1b[0m', e.message);
  console.error('Is the API running and reachable at ' + BASE + '? Did you run `npm run seed`?');
  process.exit(1);
});
