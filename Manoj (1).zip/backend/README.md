# Clinicast Backend

Complete Node.js + MySQL + MinIO backend for the Clinicast workflow platform. Includes JWT auth (access + refresh + rotation), MFA-ready login, RBAC enforcement from the `role_permissions` table, append-only HMAC-chained audit log, presigned S3/MinIO video uploads, and the full workflow state machine.

Boots end-to-end with one command.

## Quick start (local, with Docker)

```bash
cd backend
docker compose up --build
```

That spins up:

| Service | Port | Purpose |
|---|---|---|
| `mysql` | 3306 | Pre-loaded with `schema.sql` (10 tables + RBAC matrix + 11 demo users) |
| `minio` | 9000 (API), 9001 (console) | S3-compatible object storage for video files |
| `api`   | 4000 | The REST API |

In a second terminal, seed bcrypt hashes for the demo users:

```bash
docker compose exec api npm run seed
# Updated 11 user(s). Default password: demo1234
```

Smoke test:

```bash
curl http://localhost:4000/health
# {"status":"ok",...}

curl -X POST http://localhost:4000/api/auth/login \
  -H 'content-type: application/json' \
  -d '{"email":"sarah.mitchell@clinicast.health","password":"demo1234"}'
# { "access_token": "...", "refresh_token": "...", "user": {...} }
```

## Point the frontend at it

Open the React app. In the browser console:

```js
window.clinicast.setMode('http', 'http://localhost:4000/api');
// page reloads, now talking to your real backend
```

Sign in with **any** demo email (`sarah.mitchell@clinicast.health`, `priya.shah@clinicast.health`, `hannah.park@clinicast.health`, …) and password `demo1234`.

To go back to demo mode:

```js
window.clinicast.setMode('local');
```

## What's implemented

### Auth (`/api/auth`)
- `POST /login` — email + password (+ optional TOTP `mfa_code`)
- `POST /refresh` — rotates refresh token on every call (defence in depth)
- `POST /logout` — revokes the session
- `GET /me` — returns the user object
- `GET /session` — live session detail (issued, expires, IP, UA)

Tokens: HS256-signed JWT. Access TTL 15 min, refresh TTL 30 days (env-configurable). Refresh tokens are stored hashed (SHA-256) in the `sessions` table — DB compromise doesn't yield tokens.

### Users (`/api/users`)
- Full RBAC matrix — admins only.
- `GET /` `POST /` `PATCH /:id` `DELETE /:id`
- Delete cascades to deactivate if the user has assignments (prevents FK orphans).

### Videos (`/api/videos`)
- `GET /` — scoped by RBAC (admins see all, others see what they're involved in)
- `GET /:id` — eager-loads versions, comments, history
- `POST /` — doctor uploads, auto-classifies (PHI/Internal), auto-assigns editor, computes `purge_after`
- Workflow transitions: `complete-editing`, `submit-for-review`, `peer-approve`, `final-approve`, `send-back`, `publish` — each enforces role + assignment + tier
- `POST /:id/versions/upload-url` — presigned S3 PUT, 5-min expiry
- `POST /:id/versions` — finalize after browser upload
- `GET /versions/:id/download-url` — presigned S3 GET
- Comments: `GET/POST /:id/comments`

### Notifications (`/api/notifications`)
- `GET /` (mine), `POST /:id/read`, `POST /read-all`

### Governance (`/api/governance`) — admins only
- `GET /audit` — filter by action, actor, date range
- `GET /rbac` — returns the live matrix from the DB
- `GET /posture` — user/MFA/session/audit/classification rollups

## Security defaults

| | |
|---|---|
| Helmet headers | ✓ default set |
| HSTS, X-Frame-Options, Referrer-Policy | ✓ via helmet |
| CORS | env-driven allowlist (`CORS_ORIGIN`) |
| Rate limit | 200 req/min/IP globally (express-rate-limit) |
| JSON body cap | 128 KB |
| SQL injection | parameterized everywhere (mysql2 `?` placeholders) |
| Password hashing | bcryptjs, cost 12 |
| MFA | TOTP via `speakeasy`; enabled per-user |
| Audit chain | every row's `hmac` covers the previous `hmac` |
| DB user privilege | recommended: revoke UPDATE/DELETE on `audit_log` from API user |
| Refresh token storage | SHA-256 hashed, not the token itself |
| Error responses | no stack traces in production |

## Project layout

```
backend/
├── docker-compose.yml          # mysql + minio + minio-init + api
├── schema.sql                  # full DDL + RBAC seed + demo users
└── api/
    ├── Dockerfile
    ├── package.json
    ├── .env.example
    └── src/
        ├── server.js           # express bootstrap
        ├── db.js               # mysql2 pool + tx helper
        ├── auth.js             # JWT + bcrypt + MFA + middleware
        ├── rbac.js             # permission matrix loader + middleware
        ├── audit.js            # HMAC-chained append
        ├── storage.js          # S3/MinIO presigners
        ├── mappers.js          # DB row → API shape
        ├── routes/
        │   ├── auth.js
        │   ├── users.js
        │   ├── videos.js
        │   ├── notifications.js
        │   └── governance.js
        └── scripts/
            └── seed-passwords.js
```

## Production deployment notes

| Concern | Local (compose) | Production |
|---|---|---|
| DB | MySQL container | Aurora MySQL 8, multi-AZ, PITR |
| Object storage | MinIO | S3 with per-classification buckets + object lock |
| Secrets | `.env` file | AWS Secrets Manager / Vault |
| TLS | none | ACM cert on ALB; HSTS preload |
| Auth provider | self-hosted (bcrypt + speakeasy) | swap for Cognito/Auth0 — only `auth.js` changes |
| Audit storage | same DB | replicate to OpenSearch + WORM-mode S3 bucket |
| Backups | docker volume | Aurora continuous + nightly snapshots, 30-day retention |
| Monitoring | morgan stdout | CloudWatch → Datadog/Grafana |
| WAF | none | AWS WAF or Cloudflare with OWASP Core Ruleset |

## Common ops

```bash
# Open a MySQL shell
docker compose exec mysql mysql -u clinicast_api -p change_me_in_prod clinicast

# Tail audit log
docker compose exec mysql mysql -u clinicast_api -p change_me_in_prod clinicast \
  -e 'SELECT at, actor_name, action, resource_id FROM audit_log ORDER BY id DESC LIMIT 20;'

# Reset password for one user (interactive)
docker compose exec api node -e "
import('bcryptjs').then(async (b) => {
  const h = await b.default.hash('newpass', 12);
  const { pool } = await import('./src/db.js');
  await pool.query('UPDATE users SET password_hash = ? WHERE email = ?', [h, 'sarah.mitchell@clinicast.health']);
  console.log('updated'); await pool.end();
});"

# Tear down (preserves volumes)
docker compose down

# Nuke everything including data
docker compose down -v
```
