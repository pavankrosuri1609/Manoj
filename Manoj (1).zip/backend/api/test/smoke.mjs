// ============================================================================
// Smoke test — end-to-end verification of the live API against a real
// MySQL + S3/MinIO stack. Run AFTER `docker compose up` + `npm run seed`.
//
//   npm run smoke
//   API_URL=https://api.yourhost.com/api npm run smoke   # against a remote env
//
// It exercises the FULL workflow across every role and prints a pass/fail
// report. Exits 0 if everything passes, 1 otherwise — wire it into CI.
//
// No dependencies: uses Node 20's built-in global fetch.
// ============================================================================

const BASE = process.env.API_URL || 'http://localhost:4000/api';
const PASSWORD = process.env.SMOKE_PASSWORD || 'demo1234';

const ACCOUNTS = {
  admin:  'sarah.mitchell@drmanojhomeopathy.com',
  doctor: 'dr.manoj@drmanojhomeopathy.com',
  editor: 'priya.shah@drmanojhomeopathy.com',
  writer: 'lena.okafor@drmanojhomeopathy.com',
  peer:   'hannah.park@drmanojhomeopathy.com',
  final:  'olivia.tran@drmanojhomeopathy.com',
  social: 'yusuf.bello@drmanojhomeopathy.com',
};

let passed = 0, failed = 0;
const results = [];
function ok(name)        { passed++; results.push(`  \x1b[32m✓\x1b[0m ${name}`); }
function bad(name, err)  { failed++; results.push(`  \x1b[31m✗\x1b[0m ${name} — ${err}`); }
async function check(name, fn) {
  try { await fn(); ok(name); }
  catch (e) { bad(name, e.message || String(e)); }
}

const tokens = {};         // role -> { access, refresh }
async function api(path, { method = 'GET', body, role } = {}) {
  const headers = { 'content-type': 'application/json' };
  if (role && tokens[role]) headers.authorization = `Bearer ${tokens[role].access}`;
  const res = await fetch(`${BASE}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let json = null; try { json = text ? JSON.parse(text) : null; } catch (e) {}
  if (!res.ok) {
    const err = new Error(`HTTP ${res.status} ${json?.error || text?.slice(0, 120) || ''}`);
    err.status = res.status; err.json = json;
    throw err;
  }
  return json;
}
async function login(role) {
  const j = await api('/auth/login', { method: 'POST', body: { email: ACCOUNTS[role], password: PASSWORD } });
  if (!j.access_token || !j.refresh_token || !j.user) throw new Error('missing tokens/user in login response');
  tokens[role] = { access: j.access_token, refresh: j.refresh_token, user: j.user };
  return j.user;
}
function assert(cond, msg) { if (!cond) throw new Error(msg); }

(async () => {
  console.log(`\nClinicast API smoke test → ${BASE}\n`);

  // ---- Health ----
  await check('GET /health returns ok + db reachable', async () => {
    const j = await api('/health');
    assert(j.status === 'ok', `health status was "${j.status}" (is MySQL connected?)`);
  });

  // ---- Auth ----
  await check('Login as every role (password verified against SQL)', async () => {
    for (const role of Object.keys(ACCOUNTS)) await login(role);
  });
  await check('Login rejects a wrong password (401)', async () => {
    try { await api('/auth/login', { method: 'POST', body: { email: ACCOUNTS.doctor, password: 'wrong-password' } }); throw new Error('expected 401'); }
    catch (e) { assert(e.status === 401, `expected 401, got ${e.status}`); }
  });
  await check('Refresh token issues a fresh access token', async () => {
    const j = await api('/auth/refresh', { method: 'POST', body: { refresh_token: tokens.doctor.refresh } });
    assert(j.access_token && j.refresh_token, 'refresh did not return new tokens');
    tokens.doctor.access = j.access_token; tokens.doctor.refresh = j.refresh_token;
  });
  await check('GET /auth/me returns the signed-in user', async () => {
    const me = await api('/auth/me', { role: 'admin' });
    assert(me.role === 'ADMIN', `expected ADMIN, got ${me.role}`);
  });
  await check('Unauthenticated request is rejected (401)', async () => {
    try { await api('/videos'); throw new Error('expected 401'); }
    catch (e) { assert(e.status === 401, `expected 401, got ${e.status}`); }
  });

  // ---- RBAC ----
  await check('RBAC: doctor CANNOT list all users (403)', async () => {
    try { await api('/users', { role: 'doctor' }); throw new Error('expected 403'); }
    catch (e) { assert(e.status === 403 || e.status === 401, `expected 403, got ${e.status}`); }
  });
  await check('RBAC: admin CAN list users', async () => {
    const users = await api('/users', { role: 'admin' });
    assert(Array.isArray(users) && users.length >= 7, 'expected the seeded users');
  });

  // ---- Full workflow ----
  let videoId;
  await check('Doctor creates a video (status EDITING)', async () => {
    const v = await api('/videos', { method: 'POST', role: 'doctor', body: { title: 'Smoke Test — Managing Seasonal Allergies', description: 'E2E smoke test video', duration: 200 } });
    assert(v.id, 'no video id returned');
    assert(v.status === 'EDITING', `expected EDITING, got ${v.status}`);
    videoId = v.id;
  });
  await check('Editor presigns an S3 upload URL for the edited cut', async () => {
    const r = await api(`/videos/${videoId}/versions/upload-url`, { method: 'POST', role: 'editor', body: { kind: 'edit', fileName: 'smoke_edit_v1.mp4', sizeBytes: 12_000_000, mime: 'video/mp4' } });
    assert(typeof r.url === 'string' && r.url.length > 0, 'no presigned URL (check S3/MinIO env + bucket)');
    assert(r.key && r.bucket, 'presign missing key/bucket');
    globalThis.__ver = r;
  });
  await check('Editor finalizes the version record', async () => {
    const v = await api(`/videos/${videoId}/versions`, { method: 'POST', role: 'editor', body: {
      kind: 'edit', label: 'Edited cut · v1', fileName: 'smoke_edit_v1.mp4',
      storageKey: globalThis.__ver.key, storageBucket: globalThis.__ver.bucket, sizeBytes: 12_000_000, mime: 'video/mp4',
    } });
    assert(v.id, 'no version id returned');
  });
  await check('Editor completes editing → WRITING', async () => {
    await api(`/videos/${videoId}/complete-editing`, { method: 'POST', role: 'editor' });
    const v = await api(`/videos/${videoId}`, { role: 'editor' });
    assert(v.status === 'WRITING', `expected WRITING, got ${v.status}`);
    assert(Array.isArray(v.versions) && v.versions.length >= 1, 'detail did not include versions[]');
  });
  await check('Writer submits captions → PEER_REVIEW', async () => {
    await api(`/videos/${videoId}/submit-for-review`, { method: 'POST', role: 'writer', body: { captions: 'Sneezing every spring? Here is what actually helps.', hashtags: ['#Allergies', '#Homeopathy'], platforms: ['Instagram', 'YouTube'] } });
    const v = await api(`/videos/${videoId}`, { role: 'writer' });
    assert(v.status === 'PEER_REVIEW', `expected PEER_REVIEW, got ${v.status}`);
  });
  await check('Stage-1 reviewer peer-approves → FINAL_REVIEW', async () => {
    await api(`/videos/${videoId}/peer-approve`, { method: 'POST', role: 'peer' });
    const v = await api(`/videos/${videoId}`, { role: 'peer' });
    assert(v.status === 'FINAL_REVIEW', `expected FINAL_REVIEW, got ${v.status}`);
  });
  await check('RBAC: a Stage-1 reviewer CANNOT final-approve (403)', async () => {
    try { await api(`/videos/${videoId}/final-approve`, { method: 'POST', role: 'peer' }); throw new Error('expected 403'); }
    catch (e) { assert(e.status === 403 || e.status === 401, `expected 403, got ${e.status}`); }
  });
  await check('Stage-2 reviewer final-approves → APPROVED', async () => {
    await api(`/videos/${videoId}/final-approve`, { method: 'POST', role: 'final' });
    const v = await api(`/videos/${videoId}`, { role: 'final' });
    assert(v.status === 'APPROVED', `expected APPROVED, got ${v.status}`);
  });
  await check('Social publishes → PUBLISHED (+ classification PUBLIC)', async () => {
    await api(`/videos/${videoId}/publish`, { method: 'POST', role: 'social', body: { platforms: ['Instagram', 'YouTube'] } });
    const v = await api(`/videos/${videoId}`, { role: 'social' });
    assert(v.status === 'PUBLISHED', `expected PUBLISHED, got ${v.status}`);
    assert(v.classification === 'PUBLIC', `expected PUBLIC, got ${v.classification}`);
  });
  await check('Comment thread works + notifies uploader', async () => {
    await api(`/videos/${videoId}/comments`, { method: 'POST', role: 'editor', body: { body: 'Great topic for spring.' } });
    const comments = await api(`/videos/${videoId}/comments`, { role: 'doctor' });
    assert(comments.length >= 1, 'no comments returned');
  });
  await check('Workflow history captured every transition', async () => {
    const v = await api(`/videos/${videoId}`, { role: 'admin' });
    const actions = (v.history || []).map(h => h.action);
    for (const a of ['CREATED', 'EDITED', 'WRITTEN', 'PEER_APPROVED', 'FINAL_APPROVED', 'PUBLISHED']) {
      assert(actions.includes(a), `history missing ${a}`);
    }
  });

  // ---- Notifications ----
  await check('Notifications were generated for the workflow', async () => {
    const n = await api('/notifications', { role: 'social' });
    assert(Array.isArray(n), 'notifications not an array');
  });

  // ---- User management ----
  let newUserId;
  await check('Admin creates a user', async () => {
    const u = await api('/users', { method: 'POST', role: 'admin', body: { name: 'Smoke Test Writer', email: `smoke+${Date.now()}@drmanojhomeopathy.com`, phone: '+91 90000 00000', role: 'WRITER', specialty: 'Test' } });
    assert(u.id, 'no user id returned');
    newUserId = u.id;
  });
  await check('Admin deactivates the user', async () => {
    await api(`/users/${newUserId}`, { method: 'PATCH', role: 'admin', body: { active: false } });
  });
  await check('Admin deletes the user', async () => {
    await api(`/users/${newUserId}`, { method: 'DELETE', role: 'admin' });
  });

  // ---- Governance ----
  await check('Audit log is populated + admin-readable', async () => {
    const audit = await api('/governance/audit', { role: 'admin' });
    assert(Array.isArray(audit) && audit.length > 0, 'audit log empty');
  });
  await check('RBAC matrix endpoint returns permissions', async () => {
    const m = await api('/governance/rbac', { role: 'admin' });
    assert(m, 'no rbac matrix');
  });

  // ---- Logout ----
  await check('Logout revokes the session', async () => {
    await api('/auth/logout', { method: 'POST', role: 'social' });
  });

  // ---- Report ----
  console.log(results.join('\n'));
  console.log(`\n${failed === 0 ? '\x1b[32m' : '\x1b[31m'}${passed}/${passed + failed} checks passed\x1b[0m\n`);
  process.exit(failed === 0 ? 0 : 1);
})().catch(e => {
  console.error('\n\x1b[31mSmoke test harness crashed:\x1b[0m', e.message);
  console.error('Is the API running and reachable at ' + BASE + '? Did you run `npm run seed`?');
  process.exit(1);
});
