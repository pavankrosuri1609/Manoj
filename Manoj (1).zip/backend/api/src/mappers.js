// Shared mappers: DB row → API shape (camelCase, with JSON-parsed fields).
export function rowToUser(r) {
  if (!r) return null;
  return {
    id: r.id,
    name: r.name,
    email: r.email,
    phone: r.phone,
    role: r.role,
    tier: r.approver_tier,
    specialty: r.specialty,
    initials: r.initials,
    tone: r.tone,
    active: !!r.active,
    mfaEnabled: !!r.mfa_enabled,
    lastLoginAt: r.last_login_at,
    createdAt: r.created_at,
  };
}

export function rowToVideo(r) {
  if (!r) return null;
  return {
    id: r.id,
    title: r.title,
    description: r.description,
    status: r.status,
    classification: r.classification,
    duration: r.duration_seconds,
    thumb: r.thumb_seed,
    uploader: r.uploader_id,
    editor: r.editor_id,
    writer: r.writer_id,
    peerApprover: r.peer_approver_id,
    finalApprover: r.final_approver_id,
    social: r.social_id,
    captions: r.captions || '',
    hashtags: parseJson(r.hashtags_json) || [],
    platforms: parseJson(r.platforms_json) || [],
    purgeAfter: r.purge_after,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    publishedAt: r.published_at,
  };
}

export function rowToVersion(r) {
  if (!r) return null;
  return {
    id: r.id,
    videoId: r.video_id,
    kind: r.kind,
    label: r.label,
    fileName: r.file_name,
    storageKey: r.storage_key,
    storageBucket: r.storage_bucket,
    sizeBytes: Number(r.size_bytes),
    sizeMB: Math.round(Number(r.size_bytes) / 1024 / 1024 * 10) / 10,
    mime: r.mime_type,
    checksum: r.checksum_sha256,
    notes: r.notes,
    by: r.uploaded_by,
    at: r.uploaded_at,
  };
}

export function rowToComment(r) {
  return r && { id: r.id, videoId: r.video_id, author: r.author_id, text: r.body, at: r.created_at };
}

export function rowToHistory(r) {
  return r && { id: r.id, action: r.action, actor: r.actor_name, actorId: r.actor_id, label: r.label, at: r.at };
}

export function rowToNotification(r) {
  return r && {
    id: r.id, for: r.user_id, type: r.type, text: r.text,
    videoId: r.video_id, read: !!r.read_at, at: r.created_at,
  };
}

export function rowToAudit(r) {
  return r && {
    id: r.id, at: r.at,
    actor: r.actor_name, actorId: r.actor_id, sessionId: r.session_id,
    sourceIp: r.source_ip, userAgent: r.user_agent,
    action: r.action, outcome: r.outcome,
    resourceType: r.resource_type, resourceId: r.resource_id, resourceLabel: r.resource_label,
    metadata: parseJson(r.metadata_json),
  };
}

function parseJson(v) {
  if (v == null) return null;
  if (typeof v === 'object') return v;          // mysql2 already parsed it
  try { return JSON.parse(v); } catch (e) { return null; }
}
