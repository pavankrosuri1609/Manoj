// JWT issue + verify, password hashing, MFA helpers.
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import speakeasy from 'speakeasy';

const SECRET = () => process.env.JWT_SECRET || 'dev_only_change_me';
const ACCESS_TTL = () => Number(process.env.JWT_ACCESS_TTL || 900);
const REFRESH_TTL = () => Number(process.env.JWT_REFRESH_TTL || 2592000);

export function hashPassword(plain) {
  return bcrypt.hash(plain, 12);
}
export function verifyPassword(plain, hash) {
  if (!hash) return false;
  return bcrypt.compare(plain, hash);
}

export function signAccessToken({ userId, role, tier, sessionId }) {
  return jwt.sign({ sub: userId, role, tier, sid: sessionId }, SECRET(), {
    expiresIn: ACCESS_TTL(),
    issuer: 'clinicast',
  });
}
export function signRefreshToken({ userId, sessionId }) {
  return jwt.sign({ sub: userId, sid: sessionId, typ: 'refresh' }, SECRET(), {
    expiresIn: REFRESH_TTL(),
    issuer: 'clinicast',
  });
}
export function verifyToken(token) {
  return jwt.verify(token, SECRET(), { issuer: 'clinicast' });
}

export function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export function newSessionId() {
  return crypto.randomBytes(16).toString('hex');
}

export function verifyTotp(secret, code) {
  if (!secret) return true; // MFA not enabled
  return speakeasy.totp.verify({ secret, encoding: 'base32', token: code, window: 1 });
}

// Express middleware — requires a valid Bearer token.
export function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'NO_TOKEN', message: 'Missing Bearer token' });
  try {
    const payload = verifyToken(token);
    req.user = {
      id: payload.sub,
      role: payload.role,
      tier: payload.tier,
      sessionId: payload.sid,
    };
    next();
  } catch (e) {
    return res.status(401).json({ error: 'INVALID_TOKEN', message: e.message });
  }
}

// Role/tier guard.
export function requireRole(...allowed) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'NOT_AUTHENTICATED' });
    if (!allowed.includes(req.user.role)) {
      return res.status(403).json({ error: 'FORBIDDEN', message: `Requires role: ${allowed.join('|')}` });
    }
    next();
  };
}

// Approver-tier guard.
export function requireTier(tier) {
  return (req, res, next) => {
    if (req.user.role !== 'APPROVER' || req.user.tier !== tier) {
      return res.status(403).json({ error: 'FORBIDDEN', message: `Requires ${tier} reviewer` });
    }
    next();
  };
}
