// RBAC enforcement using the role_permissions table (source-of-truth).
import { q } from './db.js';

// Cache the matrix in process for speed — invalidate on user/role changes.
let cache = null;
let cachedAt = 0;
const TTL = 60_000;

export async function getMatrix() {
  if (cache && Date.now() - cachedAt < TTL) return cache;
  const rows = await q('SELECT role, permission, scope FROM role_permissions');
  const m = {};
  for (const r of rows) {
    (m[r.permission] ||= {})[r.role] = r.scope;
  }
  cache = m;
  cachedAt = Date.now();
  return m;
}

export function invalidateMatrix() { cache = null; }

// Map a (role, tier) → the matrix-role key.
function matrixRole(user) {
  if (user.role === 'APPROVER') return user.tier === 'final' ? 'APPROVER_FINAL' : 'APPROVER_PEER';
  return user.role;
}

// `requirePermission` middleware. The handler decides ownership/assignment for
// 'own'/'assigned' scopes by attaching `req.resource` in an earlier middleware.
export function requirePermission(permission) {
  return async (req, res, next) => {
    try {
      if (!req.user) return res.status(401).json({ error: 'NOT_AUTHENTICATED' });
      const matrix = await getMatrix();
      const scope = matrix[permission]?.[matrixRole(req.user)];
      if (!scope) {
        return res.status(403).json({ error: 'FORBIDDEN', message: `Missing permission: ${permission}` });
      }
      req.permissionScope = scope;   // 'full' | 'assigned' | 'own'
      next();
    } catch (e) { next(e); }
  };
}
