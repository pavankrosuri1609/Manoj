// Seed all demo users' password_hash columns with bcrypt('demo1234').
// Run once after first deploy:    docker compose exec api npm run seed
import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { pool, q } from '../db.js';

const DEFAULT_PASSWORD = process.env.SEED_PASSWORD || 'demo1234';

async function main() {
  const hash = await bcrypt.hash(DEFAULT_PASSWORD, 12);
  const result = await q(
    `UPDATE users SET password_hash = ? WHERE password_hash IS NULL OR password_hash = ''`,
    [hash]
  );
  console.log(`Updated ${result.affectedRows} user(s). Default password: ${DEFAULT_PASSWORD}`);
  console.log('Sign-in emails:');
  const rows = await q(`SELECT email, role, approver_tier FROM users ORDER BY role, email`);
  for (const r of rows) {
    console.log(`  ${r.email.padEnd(40)} ${r.role}${r.approver_tier ? ' · ' + r.approver_tier : ''}`);
  }
  await pool.end();
}

main().catch((e) => { console.error(e); process.exit(1); });
