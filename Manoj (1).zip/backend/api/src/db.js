// MySQL connection pool — shared across the API.
import mysql from 'mysql2/promise';

export const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'clinicast',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  // JSON columns come back as native objects automatically
  dateStrings: false,
  timezone: 'Z',
});

// Helpers ---------------------------------------------------------------------
export async function q(sql, params) {
  const [rows] = await pool.query(sql, params);
  return rows;
}
export async function one(sql, params) {
  const rows = await q(sql, params);
  return rows[0] || null;
}
export async function tx(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const out = await fn(conn);
    await conn.commit();
    return out;
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
}
