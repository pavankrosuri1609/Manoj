// S3 / MinIO presigner — issues short-lived PUT/GET URLs so the browser uploads
// and downloads video files directly to/from object storage. The API never
// proxies binary content — least privilege at the network layer.
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

const s3 = new S3Client({
  endpoint: process.env.S3_ENDPOINT,
  region: process.env.S3_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY,
    secretAccessKey: process.env.S3_SECRET_KEY,
  },
  forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
});

const bucketFor = (kind) => kind === 'raw'
  ? (process.env.S3_BUCKET_RAW  || 'clinicast-raw')
  : (process.env.S3_BUCKET_EDIT || 'clinicast-edit');

export async function presignUpload({ kind, videoId, fileName, mime }) {
  const bucket = bucketFor(kind);
  const safe = fileName.replace(/[^\w.\-]/g, '_').slice(0, 200);
  const key = `${videoId}/${Date.now()}_${safe}`;
  const cmd = new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    ContentType: mime || 'video/mp4',
    // ServerSideEncryption: 'aws:kms', KMSKeyId: process.env.S3_KMS_KEY_ID, // production
  });
  const url = await getSignedUrl(s3, cmd, { expiresIn: 300 });   // 5 min
  return { url, bucket, key };
}

export async function presignDownload({ bucket, key }) {
  const cmd = new GetObjectCommand({ Bucket: bucket, Key: key });
  const url = await getSignedUrl(s3, cmd, { expiresIn: 300 });
  return { url };
}
