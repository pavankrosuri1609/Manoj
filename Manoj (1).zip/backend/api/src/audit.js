// Audit log — append-only. Every privileged action writes a row here.
// In production: chain HMAC for tamper-evidence, replicate to a WORM store.
import crypto from 'crypto';
import { q, one } from './db.js';

export async function appendAudit({
  actorId = null,
  actorName = 'system',
  sessionId = null,
  sourceIp = null,
  userAgent = null,
  action,
  outcome = 'success',
  resourceType = null,
  resourceId = null,
  resourceLabel = null,
  metadata = null,
}) {
  // Pull last row's hmac to chain
  const last = await one('SELECT hmac FROM audit_log ORDER BY id DESC LIMIT 1');
  const prev = last?.hmac || null;

  // Compute deterministic body, then HMAC
  const body = JSON.stringify({
    actorId, actorName, sessionId, sourceIp, userAgent,
    action, outcome, resourceType, resourceId, resourceLabel,
    metadata, prev,
  });
  const secret = process.env.AUDIT_HMAC_KEY || process.env.JWT_SECRET || 'dev';
  const hmac = crypto.createHmac('sha256', secret).update(body).digest('hex');

  await q(
    `INSERT INTO audit_log
       (actor_id, actor_name, session_id, source_ip, user_agent, action, outcome,
        resource_type, resource_id, resource_label, metadata_json, prev_hmac, hmac)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [actorId, actorName, sessionId, sourceIp, userAgent, action, outcome,
      resourceType, resourceId, resourceLabel,
      metadata ? JSON.stringify(metadata) : null, prev, hmac]
  );
}

// Express middleware factory — captures the audit context for downstream handlers.
export function withAuditContext(req, _res, next) {
  req.audit = (opts) => appendAudit({
    actorId: req.user?.id,
    actorName: req.user?.name || 'anonymous',
    sessionId: req.user?.sessionId,
    sourceIp: req.ip,
    userAgent: req.headers['user-agent'],
    ...opts,
  });
  next();
}
