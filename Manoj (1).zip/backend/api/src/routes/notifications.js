// /notifications/* — list, mark-read, mark-all-read for the current user
import { Router } from 'express';
import { q, one } from '../db.js';
import { requireAuth } from '../auth.js';
import { rowToNotification } from '../mappers.js';

const router = Router();
router.use(requireAuth);

router.get('/', async (req, res, next) => {
  try {
    const rows = await q('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 200', [req.user.id]);
    res.json(rows.map(rowToNotification));
  } catch (e) { next(e); }
});

router.post('/:id/read', async (req, res, next) => {
  try {
    await q('UPDATE notifications SET read_at = NOW() WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

router.post('/read-all', async (req, res, next) => {
  try {
    await q('UPDATE notifications SET read_at = NOW() WHERE user_id = ? AND read_at IS NULL', [req.user.id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

export default router;
