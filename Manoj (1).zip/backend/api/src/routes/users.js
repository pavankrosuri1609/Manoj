// /users/* — admin-only RBAC for the user table.
import { Router } from 'express';
import { z } from 'zod';
import { ulid } from 'ulid';
import { q, one } from '../db.js';
import { requireAuth } from '../auth.js';
import { requirePermission } from '../rbac.js';
import { hashPassword } from '../auth.js';
import { rowToUser } from '../mappers.js';

const router = Router();
router.use(requireAuth);

const userCreate = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  phone: z.string().min(7),
  role: z.enum(['DOCTOR','EDITOR','WRITER','APPROVER','SOCIAL']),
  tier: z.enum(['peer','final']).optional(),
  specialty: z.string().max(160).optional().nullable(),
  password: z.string().min(8).optional(),
});

const userUpdate = userCreate.partial();

router.get('/', requirePermission('users.read'), async (_req, res, next) => {
  try {
    const rows = await q('SELECT * FROM users ORDER BY role, name');
    res.json(rows.map(rowToUser));
  } catch (e) { next(e); }
});

router.post('/', requirePermission('users.create'), async (req, res, next) => {
  try {
    const body = userCreate.parse(req.body);
    if (body.role === 'APPROVER' && !body.tier) return res.status(400).json({ error: 'TIER_REQUIRED' });
    const id = ulid();
    const initials = body.name.split(' ').filter(Boolean).map(s => s[0]).join('').slice(0,2).toUpperCase();
    const password_hash = body.password ? await hashPassword(body.password) : null;
    await q(
      `INSERT INTO users (id, name, email, phone, role, approver_tier, specialty, initials, tone, password_hash, active)
       VALUES (?,?,?,?,?,?,?,?,?,?,1)`,
      [id, body.name, body.email.toLowerCase(), body.phone, body.role,
        body.role === 'APPROVER' ? body.tier : null,
        body.specialty || null, initials,
        `thumb-grad-${Math.floor(Math.random()*6)}`,
        password_hash]
    );
    await req.audit({ action: 'USER_CREATE', resourceType: 'user', resourceId: id, resourceLabel: body.name });
    const created = await one('SELECT * FROM users WHERE id = ?', [id]);
    res.status(201).json(rowToUser(created));
  } catch (e) {
    if (e?.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'EMAIL_EXISTS' });
    next(e);
  }
});

router.patch('/:id', requirePermission('users.update'), async (req, res, next) => {
  try {
    const id = req.params.id;
    const body = userUpdate.parse(req.body);
    const sets = [], vals = [];
    const allow = {
      name: 'name', email: 'email', phone: 'phone', role: 'role',
      tier: 'approver_tier', specialty: 'specialty', active: 'active',
    };
    for (const [k, col] of Object.entries(allow)) {
      if (k in body) { sets.push(`${col} = ?`); vals.push(k === 'email' ? body[k].toLowerCase() : body[k]); }
    }
    if (body.password) { sets.push('password_hash = ?'); vals.push(await hashPassword(body.password)); }
    if (sets.length === 0) return res.status(400).json({ error: 'NOTHING_TO_UPDATE' });
    vals.push(id);
    await q(`UPDATE users SET ${sets.join(', ')} WHERE id = ?`, vals);
    await req.audit({ action: 'USER_UPDATE', resourceType: 'user', resourceId: id, metadata: body });
    const updated = await one('SELECT * FROM users WHERE id = ?', [id]);
    if (!updated) return res.status(404).json({ error: 'NOT_FOUND' });
    res.json(rowToUser(updated));
  } catch (e) { next(e); }
});

router.delete('/:id', requirePermission('users.delete'), async (req, res, next) => {
  try {
    if (req.params.id === req.user.id) return res.status(400).json({ error: 'CANNOT_DELETE_SELF' });
    // If user has assignments, deactivate instead of delete.
    const used = await one(
      `SELECT 1 FROM videos WHERE uploader_id=? OR editor_id=? OR writer_id=? OR peer_approver_id=? OR final_approver_id=? OR social_id=? LIMIT 1`,
      [req.params.id, req.params.id, req.params.id, req.params.id, req.params.id, req.params.id]
    );
    if (used) {
      await q('UPDATE users SET active = 0 WHERE id = ?', [req.params.id]);
      await req.audit({ action: 'USER_DEACTIVATE', resourceType: 'user', resourceId: req.params.id });
      return res.json({ deactivated: true });
    }
    await q('DELETE FROM users WHERE id = ?', [req.params.id]);
    await req.audit({ action: 'USER_DELETE', resourceType: 'user', resourceId: req.params.id });
    res.json({ deleted: true });
  } catch (e) { next(e); }
});

export default router;
