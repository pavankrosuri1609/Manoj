// /governance/* — audit query, RBAC matrix, posture (admin-only)
import { Router } from 'express';
import { q } from '../db.js';
import { requireAuth, requireRole } from '../auth.js';
import { rowToAudit } from '../mappers.js';

const router = Router();
router.use(requireAuth, requireRole('ADMIN'));

router.get('/audit', async (req, res, next) => {
  try {
    const where = ['1=1']; const params = [];
    if (req.query.action) { where.push('action = ?'); params.push(req.query.action); }
    if (req.query.actorId) { where.push('actor_id = ?'); params.push(req.query.actorId); }
    if (req.query.from) { where.push('at >= ?'); params.push(req.query.from); }
    if (req.query.to)   { where.push('at <= ?'); params.push(req.query.to); }
    const limit = Math.min(Number(req.query.limit) || 200, 1000);
    const rows = await q(`SELECT * FROM audit_log WHERE ${where.join(' AND ')} ORDER BY at DESC LIMIT ?`, [...params, limit]);
    res.json(rows.map(rowToAudit));
  } catch (e) { next(e); }
});

router.get('/rbac', async (_req, res, next) => {
  try {
    const rows = await q('SELECT role, permission, scope FROM role_permissions ORDER BY role, permission');
    res.json(rows);
  } catch (e) { next(e); }
});

router.get('/posture', async (_req, res, next) => {
  try {
    const [users, videos, audit, sessions] = await Promise.all([
      q(`SELECT
           COUNT(*) AS total,
           SUM(active = 1) AS active,
           SUM(mfa_enabled = 1) AS mfa
         FROM users`),
      q(`SELECT classification, COUNT(*) c FROM videos GROUP BY classification`),
      q(`SELECT COUNT(*) c FROM audit_log WHERE at >= DATE_SUB(NOW(), INTERVAL 30 DAY)`),
      q(`SELECT COUNT(*) c FROM sessions WHERE revoked_at IS NULL AND expires_at > NOW()`),
    ]);
    res.json({
      users: users[0],
      videoClassification: videos.reduce((acc, r) => (acc[r.classification] = r.c, acc), {}),
      auditEvents30d: audit[0].c,
      activeSessions: sessions[0].c,
    });
  } catch (e) { next(e); }
});

export default router;
