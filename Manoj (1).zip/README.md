# Clinicast — Doctor Content Workflow Platform

A complete, production-ready stack for routing doctor-recorded video content through editing, captioning, two-stage medical/compliance review, and publishing to social channels.

## What's inside this package

```
clinicast/
├── README.md                    ← you are here
├── DEPLOYMENT.md                ← step-by-step deploy guide (Docker + native)
├── ARCHITECTURE.md              ← system design, data flow, security model
│
├── frontend/                    ← React + Tailwind UI
│   ├── index.html
│   └── src/
│       ├── api.jsx              ← Local + HTTP adapters (flip with one console call)
│       ├── data.jsx             ← App state, reducer, context
│       ├── login.jsx            ← Team + Admin sign-in
│       ├── shell.jsx            ← Sidebar, header, breadcrumbs, notifications
│       ├── dashboards.jsx       ← Per-role dashboards (Doctor, Editor, Writer, …)
│       ├── admin.jsx            ← User & role management (RBAC)
│       ├── workflow.jsx         ← Kanban workflow board (drag & drop)
│       ├── detail.jsx           ← Video detail page (player, comments, timeline)
│       ├── governance.jsx       ← Security posture, audit log, RBAC matrix
│       ├── ui.jsx               ← Shared components
│       └── icons.jsx            ← Lucide wrapper
│
└── backend/
    ├── README.md                ← API-specific docs
    ├── schema.sql               ← MySQL 8 DDL + RBAC seed + demo users
    ├── docker-compose.yml       ← mysql + minio + api in one command
    └── api/                     ← Node 20 / Express service
        ├── package.json
        ├── Dockerfile
        ├── .env.example
        └── src/
            ├── server.js        ← Express bootstrap, hardening, routing
            ├── db.js            ← mysql2 pool + transaction helper
            ├── auth.js          ← JWT + bcrypt + MFA + middleware
            ├── rbac.js          ← Permission matrix loader + middleware
            ├── audit.js         ← HMAC-chained append-only log
            ├── storage.js       ← S3 / MinIO presigner
            ├── mappers.js       ← DB row → API shape
            ├── routes/
            │   ├── auth.js
            │   ├── users.js
            │   ├── videos.js
            │   ├── notifications.js
            │   └── governance.js
            └── scripts/
                └── seed-passwords.js
```

## Features

### Workflow
- Doctor uploads original recording → editor downloads & uploads edited cut → writer adds captions/hashtags/platforms → **Stage 1 peer review** (clinical accuracy) → **Stage 2 final approval** (compliance / department head) → social team publishes
- Full version history (raw + edited cuts both retained, with file metadata)
- Send-back with assignee picker + required reason at any review stage
- Real-time in-app notifications at every handoff

### Roles (RBAC)
- **Administrator** — manage users, view governance & audit
- **Doctor** — upload videos, track progress, view performance
- **Editor** — edit & upload finished cuts
- **Writer** — write captions, hashtags, choose platforms
- **Reviewer (Stage 1 / Peer)** — clinical accuracy sign-off
- **Reviewer (Stage 2 / Final)** — compliance & brand sign-off
- **Social Media** — publish to channels

### Security & Governance
- Short-lived JWT access tokens (15 min) + rotating refresh tokens (30 days)
- bcrypt password hashing, TOTP MFA-ready
- Row-level RBAC from a database-driven permission matrix (single source of truth)
- HMAC-chained tamper-evident audit log on every privileged action
- Data classification (PHI / Internal / Public) with HIPAA-aligned retention (7y / 3y / 2y)
- Per-classification S3 buckets, presigned upload/download (API never proxies binary)
- Helmet headers, CORS allowlist, rate limiting, parameterized SQL everywhere
- Live security posture dashboard + Zero Trust scorecard + RBAC matrix view (admin)

## Quick start

See **DEPLOYMENT.md** for full instructions. The 30-second version:

```bash
# Backend
cd backend
docker compose up --build
docker compose exec api npm run seed      # in another terminal

# Frontend — serve index.html with any static host
cd ../frontend
python3 -m http.server 8000

# Open http://localhost:8000, then in browser console:
#   window.clinicast.setMode('http', 'http://localhost:4000/api')
# Sign in: sarah.mitchell@clinicast.health / demo1234
```

## Tech stack

| Layer | Tech |
|---|---|
| Frontend | React 18, Tailwind CSS, Lucide icons, Babel (in-browser, dev) |
| Backend | Node 20, Express 4, mysql2, JSON Web Tokens, bcryptjs, speakeasy, Zod |
| Database | MySQL 8 (InnoDB, utf8mb4) |
| Object storage | S3-compatible (MinIO locally, AWS S3 in production) |
| Container | Docker + docker-compose (optional — native deploy fully supported) |

## License

Proprietary — internal use. Contact your platform team for license terms.
