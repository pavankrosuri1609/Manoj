# Architecture

## System diagram

```
                       ┌────────────────────────────┐
                       │  Browser (React + Tailwind) │
                       │  - LocalAdapter (demo)     │
                       │  - HttpAdapter  (prod)     │
                       └─────────────┬──────────────┘
                                     │ HTTPS · JWT Bearer
                                     ▼
                       ┌────────────────────────────┐
                       │   Reverse proxy / CDN      │  nginx, ALB, CloudFront
                       │   (TLS, WAF, rate limit)   │
                       └─────────────┬──────────────┘
                                     │
                       ┌─────────────▼──────────────┐
                       │   Node / Express API       │
                       │   - JWT verify (HS256)     │
                       │   - RBAC middleware        │
                       │   - Audit middleware       │
                       │   - Zod request validation │
                       └──┬──────────────────┬──────┘
                          │                  │
                ┌─────────▼─────┐    ┌───────▼──────────┐
                │   MySQL 8     │    │  S3 / MinIO       │
                │   (10 tables) │    │  raw + edit       │
                │   InnoDB      │    │  presigned URLs   │
                └───────────────┘    └───────────────────┘
```

## Data model

### Tables

| Table | Purpose |
|---|---|
| `users` | All accounts. One role per user; reviewers also carry a `peer` / `final` tier |
| `videos` | Workflow primary entity. Carries assignment FKs for each role and a `classification` |
| `video_versions` | Raw (doctor's upload) + edited cuts (editor's deliverables). Both retained |
| `comments` | Per-video discussion |
| `workflow_history` | User-readable timeline of state transitions |
| `rejection_reasons` | Send-back metadata (who → whom, reason, from which stage) |
| `notifications` | Per-user inbox |
| `sessions` | Refresh-token store (hashed). Drives JWT refresh + revocation |
| `audit_log` | Append-only, HMAC-chained event log. Source of truth for compliance |
| `role_permissions` | RBAC matrix — same matrix the UI displays in the Governance tab |

### Status machine

```
              ┌─→ EDITING ──→ WRITING ──→ PEER_REVIEW ──→ FINAL_REVIEW ──→ APPROVED ──→ PUBLISHED
              │      ↑           ↑              │                │
   UPLOADED ──┘      │           │              │                │
                     │           │   send back  │                │
                     └───────────┴──────────────┴────────────────┘
                                            (reviewer chooses assignee + reason)
```

A `videos.status` enum + transition handlers in `routes/videos.js` enforce the legal moves; any other move returns 403.

### Classifications & retention

| Class | Used for | Retention | Encryption |
|---|---|---|---|
| `PHI` | Pre-publication clinical content (patient-identifiable) | 2555 days (7 years, HIPAA) | AES-256 + KMS-managed key in prod |
| `INTERNAL` | Pre-publication non-PHI material | 1095 days (3 years) | AES-256 |
| `PUBLIC` | Published content | 730 days (2 years) | AES-256 |

The `videos.purge_after` column is computed at write time from `created_at + classification.retentionDays`. A daily cron job (out of scope here) deletes expired rows; CASCADEs clear children automatically.

## Security model

### Authentication

```
Login:
  POST /api/auth/login { email, password, mfa_code? }
    ↓
  bcrypt.verify(password, user.password_hash)
    ↓
  speakeasy.totp.verify(user.mfa_secret, mfa_code)     // if mfa_enabled
    ↓
  INSERT INTO sessions (id, user_id, refresh_token_h, ...)
    ↓
  Issue:
    access_token  (HS256, 15-min, claims: sub, role, tier, sid)
    refresh_token (HS256, 30-day, hashed before store)

Every request:
  Authorization: Bearer <access_token>
    ↓
  jwt.verify() against JWT_SECRET
    ↓
  req.user = { id, role, tier, sessionId }
    ↓
  RBAC middleware: requirePermission('video.publish') checks role_permissions table
    ↓
  Handler logic + audit log entry

Refresh (when access expires):
  POST /api/auth/refresh { refresh_token }
    ↓
  Lookup session by SHA-256(refresh_token) in sessions table
    ↓
  Issue new access_token + rotated refresh_token (defense in depth)
```

### RBAC enforcement

The `role_permissions` table is the single source of truth. The same matrix:
- Is loaded by the API on startup → checked on every request via `requirePermission()`
- Is exposed at `GET /api/governance/rbac` → displayed in the frontend's Governance tab

If you change a permission, the UI and the API stay in sync — there's no separate enforcement code per route.

### Audit chain

Every privileged action calls `req.audit({ action, resourceType, resourceId, ... })`, which:

1. Reads the previous row's `hmac`
2. Builds a canonical JSON body
3. Computes `hmac = HMAC-SHA256(body || prev_hmac, JWT_SECRET)`
4. Inserts the row with `prev_hmac` and `hmac` columns

To verify the chain hasn't been tampered with, replay: for each row, recompute the HMAC from `prev_hmac + body` and confirm it matches the stored `hmac`. Any tampered row breaks the chain from that point forward.

At the DB user level, the API user has `INSERT + SELECT` only on `audit_log` — even SQL injection cannot UPDATE or DELETE rows. (See `DEPLOYMENT.md` step 2 for the GRANT/REVOKE commands.)

### File storage

The API never proxies binary content. Instead:

1. Client: `POST /api/videos/:id/versions/upload-url { kind, fileName, sizeBytes, mime }`
2. API: returns a pre-signed S3 PUT URL (5-minute expiry, content-type pinned)
3. Client: `fetch(url, { method: 'PUT', body: file })` directly to S3
4. Client: `POST /api/videos/:id/versions { storageKey, sizeBytes, ... }` to finalize the version record

This keeps:
- The API stateless and small (no streaming)
- Network egress between client and S3, not via the API
- IAM permissions scoped to specific actions on specific buckets

Per-classification buckets allow per-class encryption policies, object lock, and replication rules to be set at the bucket level without per-row logic.

### Defense-in-depth summary

| Concern | Control |
|---|---|
| SQL injection | mysql2 with parameterized `?` placeholders everywhere |
| XSS | React escapes by default; no `dangerouslySetInnerHTML` on user content |
| CSRF | Stateless JWT in `Authorization` header (not cookies) — CSRF doesn't apply |
| Brute force | bcrypt cost 12 + rate limit + failed-login audit entries |
| Token theft | 15-min access TTL + rotating refresh + DB-side session revocation |
| Session fixation | Session ID generated server-side, stored hashed |
| Path traversal | No filesystem paths — all storage is S3 keys, sanitized |
| Mass assignment | Zod schemas explicitly enumerate accepted fields |
| Information leak | Production error handler returns generic errors; stack traces logged only |
| Privilege escalation | Role + tier checks at API; UI guards are convenience-only |

## Frontend architecture

### The integration seam (`src/api.jsx`)

Every action goes through `window.api.*`. Two adapters implement the same interface:

- **LocalAdapter** — dispatches against the in-memory reducer (the demo)
- **HttpAdapter** — calls the real backend, auto-refreshes expired tokens

Switch at runtime:

```javascript
window.clinicast.setMode('http', 'https://api.example.com');  // reloads in HTTP mode
window.clinicast.setMode('local');                             // back to demo
```

This single seam is the entire migration cost from "demo" to "production data".

### State management

A single `useReducer` (in `src/data.jsx`) holds users, videos, notifications, audit log, and session. The reducer is the source of truth — components subscribe via `useContext(AppContext)`. In HTTP mode, mutations bypass the reducer and call the API directly; reads still come from the reducer (which an outer effect could refresh on a schedule or via WebSocket).

## Deployment topology (production recommended)

```
                            Internet
                                │
                          ┌─────▼─────┐
                          │  Route 53 │ (DNS)
                          └─────┬─────┘
                                │
                          ┌─────▼─────┐
                          │ CloudFront│ (CDN — static frontend)
                          └─────┬─────┘
                                │
                          ┌─────▼─────┐
                          │  AWS WAF  │ (OWASP rules, geo-fence, bot mgmt)
                          └─────┬─────┘
                                │
                          ┌─────▼─────┐
                          │    ALB    │ (TLS termination)
                          └─────┬─────┘
                                │
                       ┌────────▼────────┐
                       │ ECS / EKS / EC2 │ (API — autoscaling)
                       │ Node + Express  │
                       └────┬───────┬────┘
                            │       │
                ┌───────────▼┐    ┌─▼──────────────┐
                │   Aurora   │    │  S3 (per-class │
                │  MySQL 8   │    │  buckets +     │
                │  multi-AZ  │    │  object lock)  │
                └────────────┘    └────────────────┘
                       │
                       └──→  Daily snapshots + binlog PITR
                       └──→  Audit log → OpenSearch + WORM S3
```

Single-region is sufficient for HIPAA. Multi-region failover requires careful design around the audit chain (the HMAC chain must be globally consistent).

## Performance characteristics

| Operation | Expected latency (p50) | Bottleneck |
|---|---|---|
| `POST /auth/login` | 80–150 ms | bcrypt verify (intentionally slow) |
| `GET /videos` | 10–30 ms | MySQL index scan |
| `GET /videos/:id` | 20–50 ms | Three parallel queries |
| Workflow transition | 40–100 ms | DB transaction with 2–3 INSERTs |
| `POST /versions/upload-url` | 10–20 ms | S3 SDK signing (in-process) |
| Audit append | 5–15 ms | One INSERT with HMAC compute |

Read-heavy endpoints can be cached at the edge by 10–30 seconds with no consistency risk for this workflow.
