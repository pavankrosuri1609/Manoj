# Deployment Guide

Two deployment paths are supported — **Docker** (fastest) and **native** (Node + MySQL installed directly on the host). Both result in identical functionality.

---

## Option A — Docker (recommended for local dev & dev environments)

### Prerequisites
- Docker 20+ and Docker Compose v2+
- Ports 3306, 4000, 9000, 9001 free

### Steps

```bash
cd backend
docker compose up --build
```

This starts MySQL, MinIO, the MinIO bucket initializer, and the API. Wait ~30 seconds for MySQL to finish initializing (it loads `schema.sql` automatically).

In a second terminal, hash the demo users' passwords:

```bash
docker compose exec api npm run seed
# → Updated 11 user(s). Default password: demo1234
```

Verify:

```bash
curl http://localhost:4000/health
# {"status":"ok",...}
```

### Verify the whole stack with one command

After `npm run seed`, run the end-to-end smoke test. It logs in as every role and drives the full workflow (create → edit → S3 presign → write → 2-stage approval → publish → comment → user CRUD → audit), asserting status transitions and RBAC at each step:

```bash
cd backend/api
npm run smoke
# → 24/24 checks passed
#
# Against a remote env:  API_URL=https://api.yourhost.com/api npm run smoke
```

A green run means MySQL, S3/MinIO presigning, JWT auth, RBAC, and every workflow endpoint are working. Wire it into CI to catch regressions.

### Point the frontend at the backend

The React app ships in **local (demo) mode**. To make it use your live API, open the app and run in the browser console:

```javascript
window.clinicast.setMode('http', 'http://localhost:4000/api');   // reloads, now talks to your backend
```

From then on, **login authenticates against your SQL users table** (real JWT), and every action (uploads, approvals, publishing, user management) hits the API and reads/writes MySQL + S3 — not localStorage. Switch back any time with `window.clinicast.setMode('local')`.

### Serve the frontend

The frontend is plain static files. Use any static server:

```bash
cd frontend
python3 -m http.server 8000
# or:  npx serve .
# or:  any nginx / caddy / IIS static config
```

Open `http://localhost:8000`. Then in the browser console:

```javascript
window.clinicast.setMode('http', 'http://localhost:4000/api');
```

Page reloads pointing at your real backend. Sign in:

| User | Email | Role |
|---|---|---|
| Sarah Mitchell | `sarah.mitchell@clinicast.health` | Administrator |
| Dr. Rajesh Kumar | `rajesh.kumar@clinicast.health` | Doctor |
| Priya Shah | `priya.shah@clinicast.health` | Editor |
| Lena Okafor | `lena.okafor@clinicast.health` | Writer |
| Dr. Hannah Park | `hannah.park@clinicast.health` | Reviewer · Stage 1 |
| Olivia Tran | `olivia.tran@clinicast.health` | Reviewer · Stage 2 |
| Yusuf Bello | `yusuf.bello@clinicast.health` | Social Media |

**Password for all demo accounts:** `demo1234`

---

## Option B — Native deployment (no Docker)

Use this for production deploys, on-prem servers, or anywhere Docker isn't an option.

### 1. Install MySQL 8

Ubuntu/Debian:
```bash
sudo apt update && sudo apt install -y mysql-server-8.0
sudo mysql_secure_installation
```

RHEL/CentOS:
```bash
sudo dnf install -y mysql-server
sudo systemctl enable --now mysqld
```

Windows: download MySQL Installer from mysql.com.

### 2. Create the database and API user

```sql
mysql -u root -p < backend/schema.sql

mysql -u root -p <<'SQL'
CREATE USER 'clinicast_api'@'%' IDENTIFIED BY 'STRONG_PASSWORD_HERE';
GRANT SELECT, INSERT, UPDATE, DELETE ON clinicast.* TO 'clinicast_api'@'%';
REVOKE UPDATE, DELETE ON clinicast.audit_log FROM 'clinicast_api'@'%';
FLUSH PRIVILEGES;
SQL
```

### 3. Install Node.js 20+

Ubuntu/Debian:
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt install -y nodejs
```

Or use `nvm install 20`.

### 4. Set up object storage

**Option 1 — AWS S3** (recommended for production):
1. Create two buckets: `clinicast-raw` and `clinicast-edit`
2. Create IAM user with `s3:PutObject`, `s3:GetObject` on those buckets
3. Use AWS keys in the `.env` below (leave `S3_ENDPOINT` empty)

**Option 2 — Self-hosted MinIO** (on-prem):
```bash
wget https://dl.min.io/server/minio/release/linux-amd64/minio
chmod +x minio && sudo mv minio /usr/local/bin/
MINIO_ROOT_USER=admin MINIO_ROOT_PASSWORD=changeme \
  minio server /var/lib/minio --console-address :9001
```

Then create the two buckets via the console at `http://server:9001`.

### 5. Configure the API

```bash
cd backend/api
cp .env.example .env
# Edit .env — set DB_HOST, DB_PASSWORD, JWT_SECRET (run `openssl rand -hex 64`),
# S3_ENDPOINT (omit for AWS S3), S3_ACCESS_KEY, S3_SECRET_KEY, CORS_ORIGIN
```

### 6. Install and start

```bash
npm install --omit=dev
npm run seed                  # one-time, sets demo passwords
node src/server.js            # or use a process manager (recommended)
```

### 7. Run as a service

**systemd** (Linux):

Create `/etc/systemd/system/clinicast-api.service`:

```ini
[Unit]
Description=Clinicast API
After=network.target mysql.service

[Service]
Type=simple
User=clinicast
WorkingDirectory=/opt/clinicast/backend/api
EnvironmentFile=/opt/clinicast/backend/api/.env
ExecStart=/usr/bin/node src/server.js
Restart=always
RestartSec=5
StandardOutput=append:/var/log/clinicast/api.log
StandardError=append:/var/log/clinicast/api.err.log

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now clinicast-api
sudo systemctl status clinicast-api
```

**PM2** (cross-platform):
```bash
npm install -g pm2
pm2 start src/server.js --name clinicast-api
pm2 save
pm2 startup     # follow printed instructions to install boot hook
```

**Windows Services**: use `nssm` (Non-Sucking Service Manager) to wrap `node src/server.js`.

### 8. Serve the frontend

Any static web server works:

**nginx**:
```nginx
server {
    listen 443 ssl;
    server_name clinicast.example.com;
    ssl_certificate /etc/letsencrypt/live/clinicast.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/clinicast.example.com/privkey.pem;

    root /opt/clinicast/frontend;
    index index.html;

    location /api/ {
        proxy_pass http://127.0.0.1:4000/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

**Apache**, **Caddy**, **IIS**: equivalent reverse-proxy config — proxy `/api/*` to the Node server, serve everything else as static.

When everything's on the same domain (which the nginx config above arranges), the frontend can call `/api` directly with no CORS/setMode call needed.

---

## Production checklist

Before going live:

- [ ] **TLS** — Let's Encrypt or commercial cert, HSTS preload
- [ ] **JWT_SECRET** — 64 random bytes via `openssl rand -hex 64`, store in a secrets manager
- [ ] **DB password** — rotate, store in secrets manager
- [ ] **DB backups** — `mysqldump` nightly + binlog for PITR, or use Aurora's continuous backup
- [ ] **DB user privileges** — confirm the API user has UPDATE/DELETE *revoked* on `audit_log`
- [ ] **CORS_ORIGIN** — set to your real frontend domain(s), never `*`
- [ ] **Rate limiting** — already at 200 req/min/IP; tighten per-route as needed
- [ ] **Logs** — ship to a central system (CloudWatch / OpenSearch / Loki)
- [ ] **Monitoring** — uptime check on `/health`, alert on 5xx rate
- [ ] **MFA** — enable TOTP for all administrators (`UPDATE users SET mfa_enabled = 1 WHERE role = 'ADMIN'` after onboarding TOTP secrets)
- [ ] **Retention purge job** — cron daily: `DELETE FROM videos WHERE purge_after < CURDATE();`
- [ ] **WAF** — Cloudflare, AWS WAF, or ModSecurity in front of the API
- [ ] **Audit retention** — replicate `audit_log` to immutable storage (S3 object-lock or WORM)
- [ ] **Penetration test** — third-party, OWASP Top 10 + auth bypass + IDOR
- [ ] **HIPAA BAA** — sign with all third-party vendors (AWS, email provider, etc.) before any real PHI

---

## Common operations

```bash
# Tail audit log
mysql -u clinicast_api -p clinicast -e \
  "SELECT at, actor_name, action, resource_label FROM audit_log ORDER BY id DESC LIMIT 20;"

# Reset a user's password
node -e "
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');
(async () => {
  const hash = await bcrypt.hash(process.argv[1], 12);
  const pool = mysql.createPool({/* from .env */});
  await pool.query('UPDATE users SET password_hash = ? WHERE email = ?', [hash, process.argv[2]]);
  await pool.end();
})();" 'newpassword' 'user@clinicast.health'

# Restart the API
sudo systemctl restart clinicast-api

# Tear down Docker setup completely (deletes volumes)
docker compose down -v

# Promote a user to admin
mysql -u clinicast_api -p clinicast -e \
  "UPDATE users SET role = 'ADMIN' WHERE email = 'someone@clinicast.health';"
```

---

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| Frontend stuck on "demo mode" after `setMode('http', ...)` | Browser cached old `index.html` — hard refresh (Cmd+Shift+R / Ctrl+Shift+R) |
| `CORS_DENIED` errors | `CORS_ORIGIN` env doesn't include the frontend domain |
| `INVALID_CREDENTIALS` on a known-good user | Forgot to run `npm run seed` after `schema.sql` |
| `ECONNREFUSED` on port 3306 | MySQL not running, or `DB_HOST` points to wrong host |
| Presigned upload URL returns 403 | S3 bucket policy missing, or IAM user has no `s3:PutObject` |
| Refresh token rejected after restart | `JWT_SECRET` changed — all sessions invalidated (expected on rotation) |
| 401 after 15 minutes | Working as intended — the frontend's HTTP adapter auto-refreshes via `/auth/refresh` |
