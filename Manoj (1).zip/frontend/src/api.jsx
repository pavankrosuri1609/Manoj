// ============================================================================
// API integration layer.
//
// Two backends behind one API:
//   - LocalAdapter  — current behavior, dispatches against the in-memory reducer
//                     so the demo keeps working with zero config.
//   - HttpAdapter   — talks to a real REST/JSON backend (Node/Express/FastAPI
//                     against the MySQL schema in backend/schema.sql).
//
// Flip with:
//   window.__CLINICAST_API = { mode: 'http', baseUrl: 'https://api.clinicast.health' };
// or by setting localStorage.setItem('clinicast.api.mode', 'http')
//
// All app code calls api.<method>(...) — never localStorage or fetch() directly.
// That way we have a single seam to swap.
// ============================================================================

const API_MODE = (() => {
  try {
    if (window.__CLINICAST_API?.mode) return window.__CLINICAST_API.mode;
    return localStorage.getItem('clinicast.api.mode') || 'local';
  } catch (e) { return 'local'; }
})();

const API_BASE_URL = (() => {
  try {
    return window.__CLINICAST_API?.baseUrl
      || localStorage.getItem('clinicast.api.baseUrl')
      || 'http://localhost:4000/api';
  } catch (e) { return 'http://localhost:4000/api'; }
})();

// ---------------------------------------------------------------------------
// HttpAdapter — calls a real backend.
// ---------------------------------------------------------------------------
function HttpAdapter(baseUrl) {
  const getAccess  = () => { try { return localStorage.getItem('clinicast.access_token'); }  catch (e) { return null; } };
  const getRefresh = () => { try { return localStorage.getItem('clinicast.refresh_token'); } catch (e) { return null; } };
  const setTokens = (access, refresh) => {
    try {
      if (access)  localStorage.setItem('clinicast.access_token',  access);
      if (refresh) localStorage.setItem('clinicast.refresh_token', refresh);
    } catch (e) {}
  };
  const clearTokens = () => {
    try {
      localStorage.removeItem('clinicast.access_token');
      localStorage.removeItem('clinicast.refresh_token');
    } catch (e) {}
  };

  let refreshing = null;
  async function refreshToken() {
    if (refreshing) return refreshing;
    refreshing = (async () => {
      const rt = getRefresh();
      if (!rt) throw new Error('NO_REFRESH_TOKEN');
      const res = await fetch(`${baseUrl}/auth/refresh`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ refresh_token: rt }),
      });
      if (!res.ok) { clearTokens(); throw new Error('REFRESH_FAILED'); }
      const json = await res.json();
      setTokens(json.access_token, json.refresh_token);
      return json.access_token;
    })().finally(() => { refreshing = null; });
    return refreshing;
  }

  async function request(path, { method = 'GET', body, retry = true } = {}) {
    const token = getAccess();
    const headers = { 'content-type': 'application/json' };
    if (token) headers.authorization = `Bearer ${token}`;
    const res = await fetch(`${baseUrl}${path}`, {
      method,
      headers,
      credentials: 'include',
      body: body ? JSON.stringify(body) : undefined,
    });
    if (res.status === 401 && retry && getRefresh()) {
      try { await refreshToken(); return request(path, { method, body, retry: false }); }
      catch (e) { /* fall through */ }
    }
    if (!res.ok) {
      let detail = null;
      try { detail = await res.json(); } catch (e) {}
      const err = new Error(detail?.message || `HTTP ${res.status}`);
      err.status = res.status; err.detail = detail;
      throw err;
    }
    if (res.status === 204) return null;
    return res.json();
  }

  return {
    mode: 'http',

    // -------- Auth --------
    async login({ email, password, mfaCode }) {
      const json = await request('/auth/login', { method: 'POST', body: { email, password, mfa_code: mfaCode } });
      setTokens(json.access_token, json.refresh_token);
      return json.user;
    },
    async logout() {
      try { await request('/auth/logout', { method: 'POST' }); } catch (e) {}
      clearTokens();
    },
    async me() { return request('/auth/me'); },
    async session() { return request('/auth/session'); },

    // -------- Users --------
    listUsers: ()           => request('/users'),
    createUser: (draft)     => request('/users', { method: 'POST', body: draft }),
    updateUser: (id, patch) => request(`/users/${id}`, { method: 'PATCH', body: patch }),
    deleteUser: (id)        => request(`/users/${id}`, { method: 'DELETE' }),

    // -------- Videos --------
    listVideos: (params = {}) => {
      const qs = new URLSearchParams(params).toString();
      return request(`/videos${qs ? `?${qs}` : ''}`);
    },
    getVideo:        (id)            => request(`/videos/${id}`),
    createVideo:     (draft)         => request('/videos', { method: 'POST', body: draft }),
    updateVideo:     (id, patch)     => request(`/videos/${id}`, { method: 'PATCH', body: patch }),
    deleteVideo:     (id)            => request(`/videos/${id}`, { method: 'DELETE' }),

    // -------- Versions / file uploads --------
    // Two-step: backend returns a pre-signed PUT for direct-to-S3, then we
    // confirm the version record once the file is uploaded.
    requestUploadUrl: (videoId, kind, fileName, sizeBytes, mime) =>
      request(`/videos/${videoId}/versions/upload-url`, {
        method: 'POST', body: { kind, fileName, sizeBytes, mime },
      }),
    finalizeVersion: (videoId, version) =>
      request(`/videos/${videoId}/versions`, { method: 'POST', body: version }),
    requestDownloadUrl: (versionId) =>
      request(`/versions/${versionId}/download-url`),

    // -------- Workflow transitions --------
    completeEditing:  (videoId, payload) => request(`/videos/${videoId}/complete-editing`, { method: 'POST', body: payload }),
    submitForReview:  (videoId, payload) => request(`/videos/${videoId}/submit-for-review`, { method: 'POST', body: payload }),
    peerApprove:      (videoId)          => request(`/videos/${videoId}/peer-approve`,  { method: 'POST' }),
    finalApprove:     (videoId)          => request(`/videos/${videoId}/final-approve`, { method: 'POST' }),
    sendBack:         (videoId, payload) => request(`/videos/${videoId}/send-back`,     { method: 'POST', body: payload }),
    publish:          (videoId, payload) => request(`/videos/${videoId}/publish`,       { method: 'POST', body: payload }),

    // -------- Comments --------
    listComments:  (videoId)        => request(`/videos/${videoId}/comments`),
    createComment: (videoId, body)  => request(`/videos/${videoId}/comments`, { method: 'POST', body: { body } }),

    // -------- Notifications --------
    listNotifications: ()              => request('/notifications'),
    markRead:          (id)            => request(`/notifications/${id}/read`, { method: 'POST' }),
    markAllRead:       ()              => request('/notifications/read-all',   { method: 'POST' }),

    // -------- Governance --------
    listAudit:   (params = {}) => {
      const qs = new URLSearchParams(params).toString();
      return request(`/governance/audit${qs ? `?${qs}` : ''}`);
    },
    rbacMatrix:  () => request('/governance/rbac'),
    posture:     () => request('/governance/posture'),
  };
}

// ---------------------------------------------------------------------------
// LocalAdapter — delegates everything to the in-memory reducer.
// dispatchFor is a "lookup" callback the AppProvider sets after mount, so the
// adapter can grab the latest dispatch + state at call time.
// ---------------------------------------------------------------------------
function LocalAdapter() {
  let ctxRef = { dispatch: null, getState: null, helpers: {} };
  return {
    mode: 'local',
    __bind(ctx) { ctxRef = ctx; },

    // -------- Auth --------
    async login({ email, password }) {
      const users = ctxRef.getState().users;
      const u = users.find(x => x.email?.toLowerCase() === email.toLowerCase() && x.active !== false);
      if (!u) throw new Error('USER_NOT_FOUND');
      ctxRef.dispatch({ type: 'LOGIN', userId: u.id });
      return u;
    },
    async logout() { ctxRef.dispatch({ type: 'LOGOUT' }); },
    async me() { return ctxRef.getState().users.find(u => u.id === ctxRef.getState().currentUserId) || null; },
    async session() { return ctxRef.getState().session; },

    // -------- Users --------
    async listUsers() { return ctxRef.getState().users; },
    async createUser(draft) { return ctxRef.helpers.createUser?.(draft); },
    async updateUser(id, patch) { ctxRef.helpers.updateUser?.(id, patch); return { id, ...patch }; },
    async deleteUser(id) { ctxRef.helpers.deleteUser?.(id); return null; },

    // -------- Videos --------
    async listVideos() { return ctxRef.getState().videos; },
    async getVideo(id) { return ctxRef.getState().videos.find(v => v.id === id) || null; },
    async createVideo(draft) { return ctxRef.helpers.uploadVideo?.(draft); },
    async updateVideo(id, patch) { ctxRef.dispatch({ type: 'UPDATE_VIDEO', id, patch }); return { id, ...patch }; },

    // -------- Versions (no real files in local mode) --------
    async requestUploadUrl() { return { url: null, storageKey: null, note: 'local-mode' }; },
    async finalizeVersion(videoId, version) {
      const v = await this.getVideo(videoId);
      const versions = [...(v.versions || []), version];
      ctxRef.dispatch({ type: 'UPDATE_VIDEO', id: videoId, patch: { versions } });
      return version;
    },
    async requestDownloadUrl() { return { url: null, note: 'local-mode' }; },

    // -------- Workflow --------
    async completeEditing(videoId, meta) {
      const v = await this.getVideo(videoId);
      return ctxRef.helpers.completeEditing?.(v, meta);
    },
    async submitForReview(videoId, payload) {
      const v = await this.getVideo(videoId);
      return ctxRef.helpers.submitForReview?.(v, payload);
    },
    async peerApprove(videoId)  { const v = await this.getVideo(videoId); return ctxRef.helpers.peerApprove?.(v); },
    async finalApprove(videoId) { const v = await this.getVideo(videoId); return ctxRef.helpers.finalApprove?.(v); },
    async sendBack(videoId, payload) {
      const v = await this.getVideo(videoId);
      return ctxRef.helpers.sendBack?.(v, payload);
    },
    async publish(videoId, { platforms }) {
      const v = await this.getVideo(videoId);
      return ctxRef.helpers.publishVideo?.(v, platforms);
    },

    // -------- Comments --------
    async listComments(videoId) { return (await this.getVideo(videoId))?.comments || []; },
    async createComment(videoId, body) {
      ctxRef.helpers.addComment?.(videoId, body);
      return { ok: true };
    },

    // -------- Notifications --------
    async listNotifications() {
      const { notifications, currentUserId } = ctxRef.getState();
      return notifications.filter(n => n.for === currentUserId);
    },
    async markRead(id) { ctxRef.dispatch({ type: 'MARK_NOTIFICATIONS_READ', ids: [id] }); },
    async markAllRead() {
      const uid = ctxRef.getState().currentUserId;
      ctxRef.dispatch({ type: 'MARK_ALL_READ', userId: uid });
    },

    // -------- Governance --------
    async listAudit() { return ctxRef.getState().auditLog; },
    async rbacMatrix() { return null; /* baked into governance.jsx today */ },
    async posture()    { return null; },
  };
}

// ---------------------------------------------------------------------------
// Singleton — pick adapter once at boot.
// ---------------------------------------------------------------------------
const api = API_MODE === 'http' ? HttpAdapter(API_BASE_URL) : LocalAdapter();

// Tiny debug surface so you can swap modes from the console.
window.clinicast = {
  api,
  setMode(mode, baseUrl) {
    try {
      localStorage.setItem('clinicast.api.mode', mode);
      if (baseUrl) localStorage.setItem('clinicast.api.baseUrl', baseUrl);
    } catch (e) {}
    location.reload();
  },
  getMode() { return api.mode; },
};

Object.assign(window, { api });
