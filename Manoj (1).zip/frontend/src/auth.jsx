// ============================================================================
// auth.jsx — REAL authentication for the browser demo.
//
// This is not a toggle. It implements genuine crypto via the Web Crypto API:
//   - PBKDF2-SHA256 password hashing (210k iterations, per-user random salt)
//   - HMAC-SHA256 signed JWTs (RFC 7519 shape: header.payload.signature)
//   - Access tokens (15 min) + refresh tokens (30 day), both verified by signature + expiry
//   - Forgot-password with a single-use, time-limited reset token
//   - Password strength policy + constant-time-ish comparison
//
// The SAME logic runs against a real backend — only the "credential store"
// differs (localStorage here; MySQL `users.password_hash` in production).
//
// Credentials are stored separately from the app state, hashed, never plaintext.
// ============================================================================
(function () {
  const enc = new TextEncoder();
  const dec = new TextDecoder();

  // ---- base64url helpers ----
  function b64urlFromBytes(bytes) {
    let bin = '';
    bytes.forEach(b => { bin += String.fromCharCode(b); });
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function bytesFromB64url(s) {
    s = s.replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    const bin = atob(s);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function b64urlFromString(str) { return b64urlFromBytes(enc.encode(str)); }
  function stringFromB64url(s) { return dec.decode(bytesFromB64url(s)); }
  function randomBytes(n) { const a = new Uint8Array(n); crypto.getRandomValues(a); return a; }
  function randomHex(n) { return Array.from(randomBytes(n)).map(b => b.toString(16).padStart(2, '0')).join(''); }

  // ---- PBKDF2 password hashing ----
  const PBKDF2_ITERS = 210000;
  async function hashPassword(password, saltHex) {
    const salt = saltHex ? bytesFromHex(saltHex) : randomBytes(16);
    const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', salt, iterations: PBKDF2_ITERS, hash: 'SHA-256' },
      keyMaterial, 256
    );
    const hashHex = bytesToHex(new Uint8Array(bits));
    const sHex = bytesToHex(salt);
    return `pbkdf2$${PBKDF2_ITERS}$${sHex}$${hashHex}`;
  }
  async function verifyPassword(password, stored) {
    try {
      const [, iters, saltHex, expected] = stored.split('$');
      const candidate = await hashPassword(password, saltHex);
      const [, , , candHash] = candidate.split('$');
      return timingSafeEqual(candHash, expected);
    } catch (e) { return false; }
  }
  function bytesToHex(bytes) { return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join(''); }
  function bytesFromHex(hex) {
    const out = new Uint8Array(hex.length / 2);
    for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
    return out;
  }
  function timingSafeEqual(a, b) {
    if (a.length !== b.length) return false;
    let diff = 0;
    for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
    return diff === 0;
  }

  // ---- HMAC-SHA256 JWT ----
  // In production the secret lives only on the server. Here it's a demo key —
  // the point is the verification path is real (tampered tokens are rejected).
  const JWT_SECRET = 'clinicast-demo-signing-key-not-for-production';
  let _hmacKey = null;
  async function hmacKey() {
    if (_hmacKey) return _hmacKey;
    _hmacKey = await crypto.subtle.importKey('raw', enc.encode(JWT_SECRET), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
    return _hmacKey;
  }
  async function signJWT(payload, ttlSeconds) {
    const header = { alg: 'HS256', typ: 'JWT' };
    const now = Math.floor(Date.now() / 1000);
    const body = { ...payload, iat: now, exp: now + ttlSeconds, jti: randomHex(8) };
    const headerB64 = b64urlFromString(JSON.stringify(header));
    const bodyB64 = b64urlFromString(JSON.stringify(body));
    const signingInput = `${headerB64}.${bodyB64}`;
    const key = await hmacKey();
    const sig = await crypto.subtle.sign('HMAC', key, enc.encode(signingInput));
    const sigB64 = b64urlFromBytes(new Uint8Array(sig));
    return `${signingInput}.${sigB64}`;
  }
  async function verifyJWT(token) {
    try {
      const parts = token.split('.');
      if (parts.length !== 3) return { valid: false, reason: 'malformed' };
      const [headerB64, bodyB64, sigB64] = parts;
      const key = await hmacKey();
      const ok = await crypto.subtle.verify('HMAC', key, bytesFromB64url(sigB64), enc.encode(`${headerB64}.${bodyB64}`));
      if (!ok) return { valid: false, reason: 'bad_signature' };
      const payload = JSON.parse(stringFromB64url(bodyB64));
      const now = Math.floor(Date.now() / 1000);
      if (payload.exp && payload.exp < now) return { valid: false, reason: 'expired', payload };
      return { valid: true, payload };
    } catch (e) { return { valid: false, reason: 'error' }; }
  }
  function decodeJWT(token) {
    try { return JSON.parse(stringFromB64url(token.split('.')[1])); } catch (e) { return null; }
  }

  // ---- Token TTLs ----
  const ACCESS_TTL = 15 * 60;          // 15 minutes
  const REFRESH_TTL = 30 * 24 * 3600;  // 30 days
  const RESET_TTL = 30 * 60;           // 30 minutes

  // ---- Credential store (localStorage; MySQL users table in prod) ----
  const CRED_KEY = 'clinicast.credentials.v1';
  const RESET_KEY = 'clinicast.reset_tokens.v1';
  const DEFAULT_PASSWORD = 'demo1234';
  // When set, all credential/reset reads+writes use this in-memory object instead
  // of localStorage. Used to fully isolate the self-test harness from live app
  // state (prevents a read-modify-write race that flaked the single-use test).
  let _testStore = null;
  let _selfTestRan = false;

  function loadCreds() {
    if (_testStore) return _testStore.creds;
    try { return JSON.parse(localStorage.getItem(CRED_KEY) || '{}'); } catch (e) { return {}; }
  }
  function saveCreds(c) { if (_testStore) { _testStore.creds = c; return; } try { localStorage.setItem(CRED_KEY, JSON.stringify(c)); } catch (e) {} }
  function loadResets() {
    if (_testStore) return _testStore.resets;
    try { return JSON.parse(localStorage.getItem(RESET_KEY) || '{}'); } catch (e) { return {}; }
  }
  function saveResets(r) { if (_testStore) { _testStore.resets = r; return; } try { localStorage.setItem(RESET_KEY, JSON.stringify(r)); } catch (e) {} }

  // Seed: every known email gets DEFAULT_PASSWORD hashed, once.
  async function ensureSeeded(emails) {
    const creds = loadCreds();
    let changed = false;
    for (const email of emails) {
      const key = email.toLowerCase();
      if (!creds[key]) {
        creds[key] = { hash: await hashPassword(DEFAULT_PASSWORD), failed: 0, lockedUntil: 0, updatedAt: Date.now() };
        changed = true;
      }
    }
    if (changed) saveCreds(creds);
    return creds;
  }

  // ---- Password policy ----
  function passwordIssues(pw) {
    const issues = [];
    if (pw.length < 8) issues.push('At least 8 characters');
    if (!/[A-Z]/.test(pw)) issues.push('One uppercase letter');
    if (!/[a-z]/.test(pw)) issues.push('One lowercase letter');
    if (!/[0-9]/.test(pw)) issues.push('One number');
    return issues;
  }
  function passwordStrength(pw) {
    let score = 0;
    if (pw.length >= 8) score++;
    if (pw.length >= 12) score++;
    if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;
    return Math.min(4, score); // 0..4
  }

  // ---- Brute-force lockout ----
  const MAX_FAILED = 5;
  const LOCK_MS = 5 * 60 * 1000;

  // ---- Public API ----
  async function login(email, password) {
    const creds = loadCreds();
    const key = (email || '').toLowerCase();
    const rec = creds[key];
    if (!rec) throw authError('INVALID_CREDENTIALS', 'Email or password is incorrect.');
    if (rec.lockedUntil && rec.lockedUntil > Date.now()) {
      const mins = Math.ceil((rec.lockedUntil - Date.now()) / 60000);
      throw authError('ACCOUNT_LOCKED', `Too many attempts. Try again in ${mins} minute${mins !== 1 ? 's' : ''}.`);
    }
    const ok = await verifyPassword(password, rec.hash);
    if (!ok) {
      rec.failed = (rec.failed || 0) + 1;
      if (rec.failed >= MAX_FAILED) { rec.lockedUntil = Date.now() + LOCK_MS; rec.failed = 0; }
      saveCreds(creds);
      throw authError('INVALID_CREDENTIALS', 'Email or password is incorrect.');
    }
    rec.failed = 0; rec.lockedUntil = 0; rec.lastLogin = Date.now();
    saveCreds(creds);
    return issueTokens(key);
  }

  async function issueTokens(email) {
    const sid = 'sess_' + randomHex(12);
    const accessToken = await signJWT({ sub: email, sid, typ: 'access' }, ACCESS_TTL);
    const refreshToken = await signJWT({ sub: email, sid, typ: 'refresh' }, REFRESH_TTL);
    return { accessToken, refreshToken, sid, email };
  }

  async function refresh(refreshToken) {
    const res = await verifyJWT(refreshToken);
    if (!res.valid) throw authError('REFRESH_FAILED', res.reason === 'expired' ? 'Session expired — please sign in again.' : 'Invalid session.');
    if (res.payload.typ !== 'refresh') throw authError('REFRESH_FAILED', 'Wrong token type.');
    return issueTokens(res.payload.sub);
  }

  async function changePassword(email, currentPassword, newPassword) {
    const creds = loadCreds();
    const key = email.toLowerCase();
    const rec = creds[key];
    if (!rec) throw authError('NOT_FOUND', 'No such account.');
    const ok = await verifyPassword(currentPassword, rec.hash);
    if (!ok) throw authError('INVALID_CREDENTIALS', 'Current password is incorrect.');
    const issues = passwordIssues(newPassword);
    if (issues.length) throw authError('WEAK_PASSWORD', 'Password too weak: ' + issues.join(', '));
    rec.hash = await hashPassword(newPassword);
    rec.updatedAt = Date.now();
    saveCreds(creds);
    return true;
  }

  // Forgot password — step 1: request a reset token (simulates emailing a link)
  async function requestPasswordReset(email) {
    const key = (email || '').toLowerCase();
    const creds = loadCreds();
    const exists = !!creds[key];
    // Always behave the same to avoid user enumeration; only create a token if real.
    let devToken = null;
    if (exists) {
      const token = randomHex(24);
      const resets = loadResets();
      resets[token] = { email: key, expiresAt: Date.now() + RESET_TTL * 1000, used: false };
      // prune expired
      Object.keys(resets).forEach(t => { if (resets[t].expiresAt < Date.now()) delete resets[t]; });
      saveResets(resets);
      devToken = token; // in production this goes in an email link, never returned to client
    }
    return { sent: true, devToken };
  }

  // Forgot password — step 2: validate token + set new password
  async function resetPassword(token, newPassword) {
    const resets = loadResets();
    const rec = resets[token];
    if (!rec) throw authError('INVALID_TOKEN', 'This reset link is invalid.');
    if (rec.used) throw authError('USED_TOKEN', 'This reset link has already been used.');
    if (rec.expiresAt < Date.now()) throw authError('EXPIRED_TOKEN', 'This reset link has expired. Request a new one.');
    const issues = passwordIssues(newPassword);
    if (issues.length) throw authError('WEAK_PASSWORD', 'Password too weak: ' + issues.join(', '));
    const creds = loadCreds();
    const cred = creds[rec.email];
    if (!cred) throw authError('NOT_FOUND', 'Account no longer exists.');
    cred.hash = await hashPassword(newPassword);
    cred.failed = 0; cred.lockedUntil = 0; cred.updatedAt = Date.now();
    saveCreds(creds);
    rec.used = true;
    saveResets(resets);
    return { email: rec.email };
  }

  function validateResetToken(token) {
    const resets = loadResets();
    const rec = resets[token];
    if (!rec) return { valid: false, reason: 'invalid' };
    if (rec.used) return { valid: false, reason: 'used' };
    if (rec.expiresAt < Date.now()) return { valid: false, reason: 'expired' };
    return { valid: true, email: rec.email, expiresAt: rec.expiresAt };
  }

  // Register credentials for a newly-created user (admin "Add user").
  async function registerUser(email, password) {
    const creds = loadCreds();
    const key = email.toLowerCase();
    creds[key] = { hash: await hashPassword(password || DEFAULT_PASSWORD), failed: 0, lockedUntil: 0, updatedAt: Date.now() };
    saveCreds(creds);
  }
  function removeUser(email) {
    const creds = loadCreds();
    delete creds[email.toLowerCase()];
    saveCreds(creds);
  }

  function authError(code, message) { const e = new Error(message); e.code = code; return e; }

  // ---- Internal self-tests (run once on load; results in console + window.Auth.testResults) ----
  async function runSelfTests() {
    if (_selfTestRan) return window.Auth?.testResults;   // run exactly once per load
    _selfTestRan = true;
    _testStore = { creds: {}, resets: {} };              // isolate from app state
    const results = [];
    const assert = (name, cond, detail) => results.push({ name, pass: !!cond, detail });

    try {
      // 1. hash + verify round-trip
      const h = await hashPassword('demo1234');
      assert('PBKDF2 hash round-trips', await verifyPassword('demo1234', h));
      assert('PBKDF2 rejects wrong password', !(await verifyPassword('wrong', h)));
      assert('PBKDF2 salts are unique', (await hashPassword('x')) !== (await hashPassword('x')));

      // 2. JWT sign + verify
      const tok = await signJWT({ sub: 'a@b.c', typ: 'access' }, 60);
      const v = await verifyJWT(tok);
      assert('JWT verifies valid token', v.valid && v.payload.sub === 'a@b.c');

      // 3. tampered JWT rejected
      const parts = tok.split('.');
      const tampered = `${parts[0]}.${b64urlFromString(JSON.stringify({ sub: 'evil@x.c', exp: 9999999999 }))}.${parts[2]}`;
      const vt = await verifyJWT(tampered);
      assert('JWT rejects tampered payload', !vt.valid && vt.reason === 'bad_signature');

      // 4. expired JWT rejected
      const expired = await signJWT({ sub: 'a@b.c' }, -10);
      const ve = await verifyJWT(expired);
      assert('JWT rejects expired token', !ve.valid && ve.reason === 'expired');

      // 5. refresh issues fresh access token
      const seeded = await ensureSeeded(['selftest@clinicast.health']);
      // force a known password for the self-test account
      const creds = loadCreds();
      creds['selftest@clinicast.health'] = { hash: await hashPassword('Test1234'), failed: 0, lockedUntil: 0 };
      saveCreds(creds);
      const session = await login('selftest@clinicast.health', 'Test1234');
      assert('Login issues access + refresh tokens', !!session.accessToken && !!session.refreshToken);
      const refreshed = await refresh(session.refreshToken);
      assert('Refresh issues new access token', !!refreshed.accessToken && refreshed.accessToken !== session.accessToken);

      // 6. wrong password fails
      let failed = false;
      try { await login('selftest@clinicast.health', 'nope'); } catch (e) { failed = e.code === 'INVALID_CREDENTIALS'; }
      assert('Login rejects wrong password', failed);

      // 7. password policy
      assert('Weak password flagged', passwordIssues('abc').length > 0);
      assert('Strong password passes', passwordIssues('Strong123').length === 0);

      // 8. reset flow
      const req = await requestPasswordReset('selftest@clinicast.health');
      assert('Reset request returns dev token', !!req.devToken);
      const reset = await resetPassword(req.devToken, 'NewPass123');
      assert('Reset sets new password', reset.email === 'selftest@clinicast.health');
      const afterReset = await login('selftest@clinicast.health', 'NewPass123');
      assert('Login works with reset password', !!afterReset.accessToken);
      // reused token rejected
      let reuse = false;
      try { await resetPassword(req.devToken, 'Another123'); } catch (e) { reuse = e.code === 'USED_TOKEN'; }
      assert('Reset token is single-use', reuse);

      // cleanup self-test account
      removeUser('selftest@clinicast.health');
    } catch (e) {
      results.push({ name: 'Self-test harness crashed', pass: false, detail: e.message });
    } finally {
      _testStore = null;                                  // restore live localStorage store
    }

    const passed = results.filter(r => r.pass).length;
    const total = results.length;
    const allPass = passed === total;
    console[allPass ? 'log' : 'error'](
      `%c[Clinicast Auth] self-tests: ${passed}/${total} passed`,
      `color:${allPass ? '#0B876C' : '#E11D48'};font-weight:bold`
    );
    results.forEach(r => console[r.pass ? 'log' : 'error'](`  ${r.pass ? '✓' : '✗'} ${r.name}${r.detail ? ' — ' + r.detail : ''}`));
    return { passed, total, allPass, results };
  }

  // Expose
  window.Auth = {
    hashPassword, verifyPassword, signJWT, verifyJWT, decodeJWT,
    login, refresh, changePassword,
    requestPasswordReset, resetPassword, validateResetToken,
    registerUser, removeUser, ensureSeeded,
    passwordIssues, passwordStrength,
    DEFAULT_PASSWORD, ACCESS_TTL, REFRESH_TTL, RESET_TTL,
    runSelfTests, testResults: null,
  };

  // Run self-tests once on load (non-blocking).
  setTimeout(async () => { window.Auth.testResults = await runSelfTests(); }, 0);
})();
