// ============================================================================
// Kanban workflow board with HTML5 drag & drop.
// ============================================================================
function WorkflowBoard() {
  const { videos, currentUser, navigate, moveVideo, appendHistory, toast, notify, userById } = useApp();
  const [dragId, setDragId] = React.useState(null);
  const [dropCol, setDropCol] = React.useState(null);

  const grouped = STATUS_ORDER.reduce((acc, s) => {
    acc[s] = videos.filter(v => v.status === s).sort((a,b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    return acc;
  }, {});

  const canDropOn = (status, dragVideo) => {
    if (!dragVideo) return false;
    // Permissive: any movement allowed for the demo. Could lock by role.
    return dragVideo.status !== status;
  };

  const performMove = (video, nextStatus) => {
    const actor = currentUser?.name || 'User';
    moveVideo(video.id, nextStatus);
    appendHistory(video.id, { action: nextStatus, actor, label: `moved to ${STATUS[nextStatus].label}` });

    // Side effects per status:
    if (nextStatus === 'WRITING' && video.writer) notify({ for: video.writer, type:'ASSIGNED', text:`"${video.title}" is ready for captions`, videoId: video.id });
    if (nextStatus === 'PEER_REVIEW') {
      const peerApprover = video.peerApprover || 'a1';
      notify({ for: peerApprover, type:'PEER_REVIEW', text:`"${video.title}" is awaiting your peer review`, videoId: video.id });
    }
    if (nextStatus === 'FINAL_REVIEW') {
      const finalApprover = video.finalApprover || 'a2';
      notify({ for: finalApprover, type:'FINAL_REVIEW', text:`"${video.title}" is awaiting final approval (Stage 2)`, videoId: video.id });
    }
    if (nextStatus === 'APPROVED') {
      const social = video.social || 's1';
      notify({ for: social, type:'APPROVED', text:`"${video.title}" is ready to publish`, videoId: video.id });
    }
    toast({ title:'Moved', message:`"${video.title}" → ${STATUS[nextStatus].label}`, tone:'success' });
  };

  return (
    <div className="p-6 lg:p-8 max-w-[1600px] mx-auto">
      <PageHeader
        eyebrow="Pipeline"
        title="Workflow Board"
        subtitle="Drag any card across columns to move it through the pipeline. State auto-saves locally."
        actions={
          <div className="flex items-center gap-2 text-[11.5px] text-ink-500 bg-white border border-ink-200 rounded-lg px-3 py-2">
            <Icon name="info" size={14}/> {videos.length} videos · {STATUS_ORDER.length} columns
          </div>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {STATUS_ORDER.map(status => {
          const items = grouped[status];
          const cfg = STATUS[status];
          const isOver = dropCol === status && canDropOn(status, videos.find(v=>v.id===dragId));
          return (
            <div
              key={status}
              onDragOver={(e) => { e.preventDefault(); setDropCol(status); }}
              onDragLeave={() => setDropCol(d => d === status ? null : d)}
              onDrop={(e) => {
                e.preventDefault();
                const v = videos.find(x => x.id === dragId);
                if (v && v.status !== status) performMove(v, status);
                setDragId(null); setDropCol(null);
              }}
              className={`bg-ink-100/60 rounded-xl p-2 flex flex-col min-h-[480px] transition ${isOver?'drop-target':''}`}
            >
              <div className="flex items-center justify-between px-2 py-2">
                <div className="flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${cfg.dot}`}></span>
                  <span className="font-bold text-[12px] uppercase tracking-widest text-ink-700">{cfg.label}</span>
                </div>
                <span className="text-[11px] font-mono font-bold text-ink-500 bg-white rounded px-1.5 py-0.5">{items.length}</span>
              </div>

              <div className="flex flex-col gap-2 flex-1 overflow-y-auto scroll-thin pr-0.5">
                {items.length === 0 && (
                  <div className="text-center py-6 px-2 text-[11.5px] text-ink-400 border-2 border-dashed border-ink-200 rounded-lg">
                    Drag a card here
                  </div>
                )}
                {items.map(v => (
                  <KanbanCard
                    key={v.id}
                    video={v}
                    dragging={dragId === v.id}
                    onDragStart={() => setDragId(v.id)}
                    onDragEnd={() => { setDragId(null); setDropCol(null); }}
                    onClick={() => navigate({ name:'detail', videoId: v.id })}
                    userById={userById}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 text-[12px] text-ink-500 bg-white border border-ink-200 rounded-xl p-4 flex items-start gap-3">
        <div className="w-9 h-9 rounded-lg bg-brand-50 text-brand-600 flex items-center justify-center flex-shrink-0">
          <Icon name="lightbulb" size={16}/>
        </div>
        <div>
          <div className="font-semibold text-ink-900 text-[13px] mb-0.5">Drag-and-drop tips</div>
          Move a card to <span className="font-semibold">Approved</span> to auto-route it to the Social Media team. Drop into <span className="font-semibold">Editing</span> to send a video back for re-edit. Each move is logged in the video's workflow history.
        </div>
      </div>
    </div>
  );
}

function KanbanCard({ video, dragging, onDragStart, onDragEnd, onClick, userById }) {
  const up = userById(video.uploader);
  const assignee = userById(video.editor || video.writer || video.peerApprover || video.finalApprover || video.social);
  return (
    <div
      draggable
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onClick={onClick}
      className={`bg-white border border-ink-200 rounded-lg p-2.5 cursor-grab active:cursor-grabbing hover:border-ink-300 hover:shadow-card transition select-none ${dragging?'dragging':''}`}
    >
      <Thumbnail video={video} className="w-full mb-2"/>
      <div className="text-[12.5px] font-semibold text-ink-900 leading-snug line-clamp-2">{video.title}</div>
      <div className="flex items-center justify-between mt-2">
        <div className="flex -space-x-1.5">
          {up && <Avatar user={up} size={20} ring/>}
          {assignee && assignee.id !== up?.id && <Avatar user={assignee} size={20} ring/>}
        </div>
        <div className="flex items-center gap-1 text-[10.5px] text-ink-400">
          <Icon name="clock" size={11}/>
          {timeAgo(video.updatedAt)}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { WorkflowBoard });
