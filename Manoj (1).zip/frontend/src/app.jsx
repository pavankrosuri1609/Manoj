// ============================================================================
// Root app — wires everything together.
// ============================================================================
function App() {
  const { currentUser, route } = useApp();
  if (!currentUser) return <LoginScreen/>;

  let view;
  switch (route.name) {
    case 'workflow':      view = <WorkflowBoard/>; break;
    case 'my':            view = <MyVideos/>; break;
    case 'all':           view = <AllVideos/>; break;
    case 'users':         view = <AdminDashboard/>; break;
    case 'governance':    view = <GovernancePage/>; break;
    case 'notifications': view = <NotificationsPage/>; break;
    case 'detail':        view = <VideoDetail videoId={route.videoId}/>; break;
    case 'dashboard':
    default:              view = <Dashboard/>; break;
  }

  return <AppShell>{view}</AppShell>;
}

function Root() {
  return (
    <AppProvider>
      <App/>
    </AppProvider>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Root/>);
