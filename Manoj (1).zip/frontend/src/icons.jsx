// Lucide icon wrapper — uses the UMD `lucide` global.
// lucide.icons keys are PascalCase. We accept kebab-case or PascalCase names.
const _iconCache = {};
function _toPascal(name) {
  return name
    .split('-')
    .map(s => s.charAt(0).toUpperCase() + s.slice(1))
    .join('');
}
function _iconHTML(name) {
  if (_iconCache[name] !== undefined) return _iconCache[name];
  const key = _toPascal(name);
  const node = (lucide && lucide.icons && lucide.icons[key]) || null;
  if (!node) { _iconCache[name] = null; return null; }
  let svg;
  try {
    svg = lucide.createElement(node);
  } catch (e) {
    // Fallback: assemble manually. node looks like [["path", {...}], ...]
    const children = node.map(([tag, attrs]) => {
      const a = Object.entries(attrs || {}).map(([k, v]) => `${k}="${v}"`).join(' ');
      return `<${tag} ${a}/>`;
    }).join('');
    svg = { outerHTML: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${children}</svg>` };
  }
  _iconCache[name] = svg.outerHTML;
  return _iconCache[name];
}

function Icon({ name, size = 18, className = '', strokeWidth, style }) {
  const html = _iconHTML(name);
  if (!html) {
    return <span className={className} style={{ width: size, height: size, display: 'inline-block', ...style }} />;
  }
  let processed = html
    .replace(/width="24"/, `width="${size}"`)
    .replace(/height="24"/, `height="${size}"`);
  if (strokeWidth) {
    processed = processed.replace(/stroke-width="2"/, `stroke-width="${strokeWidth}"`);
  }
  return (
    <span
      className={className}
      style={{
        width: size,
        height: size,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
        ...style,
      }}
      dangerouslySetInnerHTML={{ __html: processed }}
    />
  );
}

Object.assign(window, { Icon });
