// ============================================================================
// Shared UI primitives.
// ============================================================================
const { Fragment } = React;

function Avatar({ user, size = 32, ring = false }) {
  if (!user) return (
    <div className="rounded-full bg-ink-200 text-ink-500 flex items-center justify-center font-semibold"
      style={{ width: size, height: size, fontSize: Math.round(size*0.4) }}>?</div>
  );
  return (
    <div
      className={`${user.tone || 'thumb-grad-0'} rounded-full text-white flex items-center justify-center font-bold tracking-tight ${ring ? 'ring-2 ring-white shadow-card' : ''}`}
      style={{ width: size, height: size, fontSize: Math.round(size*0.38) }}
      title={user.name}
    >{user.initials}</div>
  );
}

function StatusBadge({ status, size='md' }) {
  const cfg = STATUS[status] || STATUS.UPLOADED;
  const dims = size === 'sm'
    ? 'text-[10.5px] px-2 py-0.5'
    : size === 'lg' ? 'text-sm px-3 py-1' : 'text-[11px] px-2 py-0.5';
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border font-semibold uppercase tracking-wide ${cfg.badge} ${dims}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`}></span>
      {cfg.label}
    </span>
  );
}

function RoleBadge({ role }) {
  const r = ROLES[role];
  if (!r) return null;
  return (
    <span className="inline-flex items-center gap-1 text-[10.5px] font-semibold uppercase tracking-wider text-ink-500 bg-ink-100 px-1.5 py-0.5 rounded">
      {r.label}
    </span>
  );
}

function Button({ children, onClick, tone='primary', size='md', icon, iconRight, disabled, className='', type='button', full=false, ...rest }) {
  const tones = {
    primary:  'bg-ink-900 text-white hover:bg-ink-800 active:bg-black shadow-card',
    brand:    'bg-brand-600 text-white hover:bg-brand-700 active:bg-brand-800 shadow-card',
    secondary:'bg-white text-ink-800 border border-ink-200 hover:border-ink-300 hover:bg-ink-50',
    ghost:    'bg-transparent text-ink-700 hover:bg-ink-100',
    danger:   'bg-rose-600 text-white hover:bg-rose-700',
    warn:     'bg-amber-500 text-white hover:bg-amber-600',
    success:  'bg-brand-600 text-white hover:bg-brand-700',
  };
  const sizes = {
    sm: 'h-8 px-3 text-[12.5px] rounded-lg gap-1.5',
    md: 'h-10 px-4 text-[13.5px] rounded-lg gap-2',
    lg: 'h-12 px-5 text-[14.5px] rounded-xl gap-2',
  };
  return (
    <button
      type={type} disabled={disabled} onClick={onClick}
      className={`inline-flex items-center justify-center font-semibold transition active:scale-[.98] disabled:opacity-50 disabled:cursor-not-allowed ${tones[tone]} ${sizes[size]} ${full?'w-full':''} ${className}`}
      {...rest}
    >
      {icon && <Icon name={icon} size={size==='sm'?14:16} />}
      <span>{children}</span>
      {iconRight && <Icon name={iconRight} size={size==='sm'?14:16} />}
    </button>
  );
}

function IconButton({ name, onClick, tone='ghost', size=18, className='', title }) {
  const tones = {
    ghost:'text-ink-600 hover:bg-ink-100',
    solid:'bg-ink-900 text-white hover:bg-ink-800',
    soft: 'bg-ink-100 text-ink-700 hover:bg-ink-200',
  };
  return (
    <button title={title} onClick={onClick} className={`w-9 h-9 rounded-lg inline-flex items-center justify-center transition ${tones[tone]} ${className}`}>
      <Icon name={name} size={size} />
    </button>
  );
}

function Card({ children, className='', padding='p-5', interactive=false, onClick }) {
  return (
    <div
      onClick={onClick}
      className={`bg-white border border-ink-200 rounded-xl shadow-card ${padding} ${interactive?'cursor-pointer hover:border-ink-300 hover:shadow-pop transition':''} ${className}`}
    >{children}</div>
  );
}

function Thumbnail({ video, ratio='16/9', className='', overlay=true }) {
  return (
    <div
      className={`${`thumb-grad-${video.thumb % 6}`} relative overflow-hidden rounded-lg ${className}`}
      style={{ aspectRatio: ratio }}
    >
      {/* abstract waveform-ish lines for medical content vibe */}
      <svg className="absolute inset-0 w-full h-full opacity-25" viewBox="0 0 200 112" preserveAspectRatio="none">
        <path d="M0 70 Q 25 30, 50 70 T 100 70 T 150 70 T 200 70" stroke="white" strokeWidth="1" fill="none" />
        <path d="M0 80 Q 25 50, 50 80 T 100 80 T 150 80 T 200 80" stroke="white" strokeWidth="0.7" fill="none" opacity="0.6"/>
        <circle cx="160" cy="30" r="14" stroke="white" strokeWidth="0.7" fill="none" opacity="0.5"/>
        <circle cx="160" cy="30" r="22" stroke="white" strokeWidth="0.5" fill="none" opacity="0.3"/>
      </svg>
      {overlay && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center ring-1 ring-white/30">
            <Icon name="play" size={16} className="text-white" />
          </div>
        </div>
      )}
      <div className="absolute bottom-1.5 right-1.5 bg-black/60 text-white text-[10px] font-mono px-1.5 py-0.5 rounded">
        {formatDuration(video.duration)}
      </div>
    </div>
  );
}

function VideoCard({ video, onClick, dense=false }) {
  const { userById } = useApp();
  const up = userById(video.uploader);
  const assignee = userById(video.editor || video.writer || video.peerApprover || video.finalApprover || video.social);
  return (
    <Card interactive onClick={onClick} padding="p-3" className="anim-slide-up">
      <div className="flex gap-3">
        <Thumbnail video={video} className="w-32 flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h4 className="font-semibold text-ink-900 text-sm leading-snug truncate" title={video.title}>{video.title}</h4>
            <StatusBadge status={video.status} size="sm" />
          </div>
          {!dense && (
            <p className="text-[12px] text-ink-500 mt-1 line-clamp-2">{video.description}</p>
          )}
          <div className="flex items-center justify-between mt-2.5">
            <div className="flex items-center gap-1.5 text-[11.5px] text-ink-500">
              <Avatar user={up} size={20} />
              <span className="font-medium text-ink-700">{up?.name.replace('Dr. ','Dr. ')}</span>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-ink-400">
              {assignee && <span className="inline-flex items-center gap-1"><Icon name="user" size={12}/>{assignee.name.split(' ')[0]}</span>}
              <span className="inline-flex items-center gap-1"><Icon name="clock" size={12}/>{timeAgo(video.updatedAt)}</span>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}

function Modal({ open, onClose, title, children, footer, size='md' }) {
  if (!open) return null;
  const widths = { sm:'max-w-md', md:'max-w-lg', lg:'max-w-2xl', xl:'max-w-4xl' };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 anim-slide-up">
      <div className="absolute inset-0 bg-ink-900/40 backdrop-blur-sm" onClick={onClose}></div>
      <div className={`relative bg-white rounded-2xl shadow-pop w-full ${widths[size]} max-h-[90vh] flex flex-col`}>
        <div className="flex items-center justify-between p-5 border-b border-ink-100">
          <h3 className="font-bold text-ink-900 text-base">{title}</h3>
          <IconButton name="x" onClick={onClose} />
        </div>
        <div className="p-5 overflow-y-auto scroll-thin flex-1">{children}</div>
        {footer && <div className="p-4 border-t border-ink-100 bg-ink-50/50 rounded-b-2xl flex justify-end gap-2">{footer}</div>}
      </div>
    </div>
  );
}

function ProgressBar({ value, tone='brand' }) {
  const tones = { brand:'bg-brand-500', blue:'bg-blue-500', violet:'bg-violet-500', amber:'bg-amber-500' };
  return (
    <div className="h-2 bg-ink-100 rounded-full overflow-hidden">
      <div className={`h-full ${tones[tone]} transition-all duration-200`} style={{ width: `${Math.max(0,Math.min(100,value))}%` }}></div>
    </div>
  );
}

function EmptyState({ icon='inbox', title, body, action }) {
  return (
    <div className="text-center py-16 px-4">
      <div className="w-14 h-14 mx-auto rounded-2xl bg-ink-100 text-ink-400 flex items-center justify-center mb-4">
        <Icon name={icon} size={24}/>
      </div>
      <h3 className="font-bold text-ink-900">{title}</h3>
      {body && <p className="text-sm text-ink-500 mt-1 max-w-sm mx-auto">{body}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

function Toasts() {
  const { toasts, dispatch } = useApp();
  return (
    <div className="fixed bottom-6 right-6 z-[60] flex flex-col gap-2 w-[340px]">
      {toasts.map(t => {
        const tones = {
          success:{ bg:'bg-white', accent:'text-brand-600 bg-brand-50', icon:'check-circle-2' },
          warn:   { bg:'bg-white', accent:'text-amber-600 bg-amber-50',  icon:'alert-triangle' },
          error:  { bg:'bg-white', accent:'text-rose-600 bg-rose-50',    icon:'alert-circle' },
          info:   { bg:'bg-white', accent:'text-blue-600 bg-blue-50',    icon:'info' },
        };
        const c = tones[t.tone] || tones.success;
        return (
          <div key={t.id} className={`anim-slide-in-right ${c.bg} border border-ink-200 rounded-xl shadow-pop p-3 flex gap-3 items-start`}>
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${c.accent}`}>
              <Icon name={c.icon} size={18}/>
            </div>
            <div className="flex-1 min-w-0">
              {t.title && <div className="font-semibold text-ink-900 text-sm">{t.title}</div>}
              {t.message && <div className="text-[12.5px] text-ink-500 mt-0.5">{t.message}</div>}
            </div>
            <button onClick={() => dispatch({ type:'DISMISS_TOAST', id: t.id })} className="text-ink-400 hover:text-ink-700">
              <Icon name="x" size={14}/>
            </button>
          </div>
        );
      })}
    </div>
  );
}

function Pill({ children, tone='ink', icon, onClick, removable, onRemove }) {
  const tones = {
    ink:'bg-ink-100 text-ink-700',
    brand:'bg-brand-50 text-brand-700',
    blue:'bg-blue-50 text-blue-700',
    violet:'bg-violet-50 text-violet-700',
    amber:'bg-amber-50 text-amber-700',
  };
  return (
    <span onClick={onClick} className={`inline-flex items-center gap-1 ${tones[tone]} text-[11.5px] font-medium px-2 py-1 rounded-md ${onClick?'cursor-pointer hover:opacity-80':''}`}>
      {icon && <Icon name={icon} size={12}/>}
      {children}
      {removable && (
        <button onClick={(e)=>{e.stopPropagation(); onRemove?.();}} className="text-current opacity-60 hover:opacity-100">
          <Icon name="x" size={11}/>
        </button>
      )}
    </span>
  );
}

function Field({ label, hint, children, required }) {
  return (
    <label className="block">
      <span className="text-[12px] font-semibold text-ink-700 mb-1.5 inline-block">
        {label} {required && <span className="text-rose-500">*</span>}
      </span>
      {children}
      {hint && <span className="text-[11.5px] text-ink-400 mt-1 block">{hint}</span>}
    </label>
  );
}

function Input(props) {
  return (
    <input
      {...props}
      className={`w-full h-10 px-3 rounded-lg border border-ink-200 bg-white text-[13.5px] text-ink-900 placeholder:text-ink-400 focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100 transition ${props.className||''}`}
    />
  );
}

function Textarea(props) {
  return (
    <textarea
      {...props}
      className={`w-full px-3 py-2.5 rounded-lg border border-ink-200 bg-white text-[13.5px] text-ink-900 placeholder:text-ink-400 focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100 transition resize-y ${props.className||''}`}
    />
  );
}

function Select({ value, onChange, options, className='', placeholder }) {
  return (
    <div className={`relative ${className}`}>
      <select
        value={value} onChange={onChange}
        className="w-full h-10 pl-3 pr-9 rounded-lg border border-ink-200 bg-white text-[13.5px] text-ink-900 appearance-none focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100"
      >
        {placeholder && <option value="">{placeholder}</option>}
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
      <Icon name="chevron-down" size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-400 pointer-events-none"/>
    </div>
  );
}

function Checkbox({ checked, onChange, label }) {
  return (
    <label className="inline-flex items-center gap-2 cursor-pointer select-none">
      <span
        onClick={() => onChange(!checked)}
        className={`w-4 h-4 rounded-[5px] border-2 flex items-center justify-center transition ${checked?'bg-brand-600 border-brand-600':'border-ink-300 bg-white'}`}
      >
        {checked && <Icon name="check" size={11} className="text-white" />}
      </span>
      {label && <span className="text-[13px] text-ink-800">{label}</span>}
    </label>
  );
}

Object.assign(window, {
  Avatar, StatusBadge, RoleBadge, Button, IconButton, Card, Thumbnail, VideoCard,
  Modal, ProgressBar, EmptyState, Toasts, Pill, Field, Input, Textarea, Select, Checkbox,
});
