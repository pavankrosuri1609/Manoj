// ============================================================================
// Security & Governance — admin-only page covering:
//   1. Live security posture (session, Zero Trust scorecard)
//   2. Data governance (classification, retention, lifecycle)
//   3. Audit log
//   4. RBAC matrix
//   5. Production architecture diagram
// ============================================================================

const GOVERNANCE_TABS = [
  { id:'posture',      label:'Posture',         icon:'gauge-circle' },
  { id:'lifecycle',    label:'Data Lifecycle',  icon:'database' },
  { id:'audit',        label:'Audit Log',       icon:'history' },
  { id:'rbac',         label:'RBAC Matrix',     icon:'key-round' },
  { id:'architecture', label:'Architecture',    icon:'workflow' },
];

function GovernancePage() {
  const [tab, setTab] = React.useState('posture');
  return (
    <div className="p-6 lg:p-10 max-w-[1280px] mx-auto">
      <PageHeader
        eyebrow="Security & Governance"
        title="Trust, classification & audit"
        subtitle="Operational view of what the platform protects, who's accessing it, and how data moves through its lifecycle."
        actions={<Button tone="secondary" icon="download" onClick={() => alert('In production: triggers a signed export of the audit log to your SOC.')}>Export evidence</Button>}
      />

      <div className="flex gap-1 border-b border-ink-200 mb-6 overflow-x-auto scroll-thin">
        {GOVERNANCE_TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 h-10 text-[13px] font-semibold border-b-2 -mb-px transition whitespace-nowrap ${tab===t.id?'border-ink-900 text-ink-900':'border-transparent text-ink-500 hover:text-ink-900'}`}>
            <Icon name={t.icon} size={14}/> {t.label}
          </button>
        ))}
      </div>

      {tab === 'posture' && <PostureTab/>}
      {tab === 'lifecycle' && <LifecycleTab/>}
      {tab === 'audit' && <AuditLogTab/>}
      {tab === 'rbac' && <RBACMatrixTab/>}
      {tab === 'architecture' && <ArchitectureTab/>}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Tab 1 — Live security posture
// ---------------------------------------------------------------------------
function PostureTab() {
  const { session, currentUser, auditLog, videos, users } = useApp();

  // Zero Trust scorecard — what's enforced (in this demo) vs. policy intent.
  const controls = [
    { key:'mfa',          label:'MFA on sign-in',           status:'enforced',  detail:'TOTP required for all administrators' },
    { key:'session-ttl',  label:'Short session TTL',         status:'enforced',  detail:`${SESSION_TTL_MIN}-minute sliding window with refresh` },
    { key:'rbac',         label:'Role-based access control', status:'enforced',  detail:'Every dashboard & action gated by role' },
    { key:'two-stage',    label:'Two-stage approval',        status:'enforced',  detail:'Peer review → Final approval required for publish' },
    { key:'audit-log',    label:'Tamper-evident audit log',  status:'enforced',  detail:'Append-only, signed entries (demo: hash chain)' },
    { key:'least-priv',   label:'Least privilege',           status:'partial',   detail:'UI-level guards in demo; backend RBAC required in prod' },
    { key:'encryption',   label:'Encryption in transit',     status:'enforced',  detail:'TLS 1.3 via CloudFront / WAF' },
    { key:'encryption-r', label:'Encryption at rest',        status:'partial',   detail:'Demo: localStorage plaintext. Prod: KMS-managed AES-256' },
    { key:'data-class',   label:'Data classification',       status:'enforced',  detail:'PHI / Internal / Public labels on every video' },
    { key:'retention',    label:'Retention enforcement',     status:'policy',    detail:'Policies defined; automated purge requires backend cron' },
    { key:'jwt-validate', label:'Strict token validation',   status:'planned',   detail:'Backend API not built yet — demo session is local-only' },
    { key:'rate-limit',   label:'API rate limiting',         status:'planned',   detail:'Requires API Gateway throttling rules' },
  ];

  const counts = controls.reduce((acc, c) => { acc[c.status] = (acc[c.status]||0)+1; return acc; }, {});
  const overall = Math.round((counts.enforced || 0) / controls.length * 100);

  return (
    <div className="space-y-6">
      <div className="grid lg:grid-cols-[1.2fr_1fr] gap-4">
        <SessionCard session={session} user={currentUser}/>
        <ComplianceScore overall={overall} counts={counts} total={controls.length}/>
      </div>

      <div>
        <SectionHeader title="Zero Trust scorecard" hint="Per-control status across the platform"/>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {controls.map(c => <ControlCard key={c.key} control={c}/>)}
        </div>
      </div>

      <div className="grid sm:grid-cols-4 gap-3">
        <StatTile icon="users" label="Active sessions (demo)" value={session ? 1 : 0} hint="Real: live from auth service" tone="brand"/>
        <StatTile icon="shield-check" label="MFA-verified users" value={users.filter(u => u.active !== false).length} hint="Mandatory for admin" tone="indigo"/>
        <StatTile icon="history" label="Audit events (30d)" value={auditLog.length} tone="amber"/>
        <StatTile icon="alert-triangle" label="Failed access (30d)" value={0} hint="Real: from auth logs" tone="rose"/>
      </div>
    </div>
  );
}

function SessionCard({ session, user }) {
  const { dispatch } = useApp();
  const [now, setNow] = React.useState(Date.now());
  React.useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);

  if (!session) {
    return <Card padding="p-5"><EmptyState icon="user-x" title="No session" body="Sign in to see the live session token."/></Card>;
  }
  const expiresAt = new Date(session.expiresAt).getTime();
  const issuedAt = new Date(session.issuedAt).getTime();
  const ttl = expiresAt - issuedAt;
  const remaining = Math.max(0, expiresAt - now);
  const remainingPct = Math.max(0, Math.min(100, (remaining / ttl) * 100));
  const mins = Math.floor(remaining / 60000);
  const secs = Math.floor((remaining % 60000) / 1000);

  const refresh = () => {
    dispatch({ type:'LOGIN', userId: user.id });
  };

  return (
    <Card padding="p-5" className="bg-gradient-to-br from-ink-900 to-ink-800 border-ink-900 text-white">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center">
            <Icon name="key-round" size={20} className="text-brand-300"/>
          </div>
          <div>
            <div className="text-[10.5px] uppercase tracking-widest text-brand-300 font-bold">Live session token</div>
            <div className="font-bold text-[15px] tracking-tight">{user?.name}</div>
            <div className="text-[11px] text-ink-300 mt-0.5">{ROLES[user?.role]?.label}{user?.tier?` · ${APPROVER_TIERS[user.tier].short}`:''}</div>
          </div>
        </div>
        <div className="flex items-center gap-1.5 text-[10.5px] font-bold uppercase tracking-widest text-brand-300 bg-brand-500/15 border border-brand-500/30 px-2 py-1 rounded">
          <span className="w-1.5 h-1.5 rounded-full bg-brand-400 pulse-ring"></span>
          {session.mfaVerified ? 'MFA verified' : 'No MFA'}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 text-[11.5px]">
        <SessionField label="Session ID" value={<code className="font-mono text-[11px]">{session.sessionId}</code>}/>
        <SessionField label="Issued at"  value={formatDate(session.issuedAt)}/>
        <SessionField label="Source IP"  value={<code className="font-mono">{session.sourceIp}</code>}/>
        <SessionField label="User agent" value={session.userAgent}/>
      </div>

      <div className="mt-4 pt-4 border-t border-white/10">
        <div className="flex items-center justify-between mb-1.5">
          <div className="text-[11px] uppercase tracking-widest text-ink-300 font-bold">Expires in</div>
          <div className={`font-mono font-bold ${remaining < 60000 ? 'text-rose-300' : 'text-white'}`}>
            {String(mins).padStart(2,'0')}:{String(secs).padStart(2,'0')}
          </div>
        </div>
        <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
          <div className={`h-full transition-all ${remainingPct < 25 ? 'bg-rose-400' : 'bg-brand-400'}`} style={{ width: `${remainingPct}%` }}></div>
        </div>
        <div className="flex justify-between text-[10.5px] text-ink-400 mt-2 font-mono">
          <span>Iat {new Date(session.issuedAt).toISOString().slice(11,19)}Z</span>
          <span>Exp {new Date(session.expiresAt).toISOString().slice(11,19)}Z</span>
        </div>
      </div>

      <div className="mt-4 flex gap-2">
        <button onClick={refresh} className="flex-1 inline-flex items-center justify-center gap-1.5 h-9 rounded-lg bg-white/10 hover:bg-white/20 text-[12.5px] font-semibold transition"><Icon name="refresh-ccw" size={13}/> Refresh token</button>
        <button onClick={() => alert('In production: revokes the token at the auth service and clears all device sessions.')} className="flex-1 inline-flex items-center justify-center gap-1.5 h-9 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-[12.5px] font-semibold transition"><Icon name="x-octagon" size={13}/> Revoke all sessions</button>
      </div>
    </Card>
  );
}

function SessionField({ label, value }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-widest text-ink-400 font-bold">{label}</div>
      <div className="text-ink-100 mt-0.5 truncate">{value}</div>
    </div>
  );
}

function ComplianceScore({ overall, counts, total }) {
  const ringPct = overall;
  const r = 52, c = 2 * Math.PI * r;
  const dash = (ringPct / 100) * c;
  return (
    <Card padding="p-5">
      <div className="flex items-center gap-5">
        <svg width="128" height="128" viewBox="0 0 128 128" className="flex-shrink-0">
          <circle cx="64" cy="64" r={r} fill="none" stroke="#EEF1F5" strokeWidth="12"/>
          <circle cx="64" cy="64" r={r} fill="none" stroke="#13A786" strokeWidth="12"
            strokeDasharray={`${dash} ${c}`} strokeDashoffset="0" strokeLinecap="round"
            transform="rotate(-90 64 64)"/>
          <text x="64" y="64" textAnchor="middle" dominantBaseline="central" className="font-bold" fontSize="28" fill="#0E1521">{overall}%</text>
          <text x="64" y="86" textAnchor="middle" dominantBaseline="central" fontSize="10" fill="#5B6B82" fontWeight="600">ENFORCED</text>
        </svg>
        <div className="flex-1 min-w-0">
          <div className="text-[11px] uppercase tracking-widest font-bold text-ink-500">Posture score</div>
          <div className="font-bold text-ink-900 text-[15px] leading-tight mt-1">Solid demo posture, infra gaps remain</div>
          <div className="text-[12px] text-ink-500 mt-1">{counts.enforced || 0} of {total} controls fully enforced. Remaining items either policy-defined (need backend) or planned.</div>
          <div className="grid grid-cols-2 gap-2 mt-3 text-[11.5px]">
            <Legend dot="bg-brand-500" label="Enforced" count={counts.enforced || 0}/>
            <Legend dot="bg-blue-500"  label="Policy"   count={counts.policy || 0}/>
            <Legend dot="bg-amber-500" label="Partial"  count={counts.partial || 0}/>
            <Legend dot="bg-ink-300"   label="Planned"  count={counts.planned || 0}/>
          </div>
        </div>
      </div>
    </Card>
  );
}

function Legend({ dot, label, count }) {
  return (
    <div className="flex items-center gap-1.5"><span className={`w-2 h-2 rounded-full ${dot}`}></span><span className="text-ink-700 font-semibold">{count}</span><span className="text-ink-500">{label}</span></div>
  );
}

function ControlCard({ control }) {
  const cfg = {
    enforced:{ bg:'bg-brand-50',  border:'border-brand-200',  pill:'bg-brand-500 text-white',    label:'Enforced',  icon:'check-circle-2' },
    policy:  { bg:'bg-blue-50',   border:'border-blue-200',   pill:'bg-blue-500 text-white',      label:'Policy',    icon:'file-text' },
    partial: { bg:'bg-amber-50',  border:'border-amber-200',  pill:'bg-amber-500 text-white',     label:'Partial',   icon:'alert-triangle' },
    planned: { bg:'bg-ink-50',    border:'border-ink-200',    pill:'bg-ink-400 text-white',       label:'Planned',   icon:'clock' },
  }[control.status];
  return (
    <div className={`rounded-xl border ${cfg.border} ${cfg.bg} p-3.5`}>
      <div className="flex items-start gap-2.5">
        <div className={`w-7 h-7 rounded-lg ${cfg.pill} flex items-center justify-center flex-shrink-0`}>
          <Icon name={cfg.icon} size={14}/>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <div className="font-bold text-ink-900 text-[12.5px] leading-tight">{control.label}</div>
            <span className={`text-[9.5px] font-bold uppercase tracking-wider ${cfg.pill} px-1.5 py-0.5 rounded`}>{cfg.label}</span>
          </div>
          <div className="text-[11.5px] text-ink-600 mt-1 leading-snug">{control.detail}</div>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Tab 2 — Data lifecycle, classification, retention
// ---------------------------------------------------------------------------
function LifecycleTab() {
  const { videos } = useApp();
  const byClass = Object.keys(CLASSIFICATIONS).reduce((acc, k) => {
    acc[k] = videos.filter(v => (v.classification || 'INTERNAL') === k);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div>
        <SectionHeader title="Data lifecycle" hint="Every video moves through these stages — each gate is auditable"/>
        <LifecycleDiagram/>
      </div>

      <div>
        <SectionHeader title="Data classification" hint="Sensitivity labels drive encryption, retention and access scope"/>
        <div className="grid lg:grid-cols-3 gap-3">
          {Object.keys(CLASSIFICATIONS).map(k => (
            <ClassificationCard key={k} cls={CLASSIFICATIONS[k]} videos={byClass[k]||[]}/>
          ))}
        </div>
      </div>

      <div>
        <SectionHeader title="Retention countdown" hint="Days until automated purge per classification policy"/>
        <Card padding="p-0">
          <div className="overflow-x-auto scroll-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-ink-50 border-b border-ink-200 text-[11px] uppercase tracking-widest text-ink-500">
                  <th className="text-left font-bold px-4 py-2.5">Video</th>
                  <th className="text-left font-bold px-4 py-2.5">Class</th>
                  <th className="text-left font-bold px-4 py-2.5">Retention</th>
                  <th className="text-left font-bold px-4 py-2.5">Purge after</th>
                  <th className="text-left font-bold px-4 py-2.5">Days left</th>
                </tr>
              </thead>
              <tbody>
                {videos.slice(0, 10).map(v => {
                  const cls = CLASSIFICATIONS[v.classification || 'INTERNAL'];
                  const r = retentionRemaining(v);
                  return (
                    <tr key={v.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50/60">
                      <td className="px-4 py-3">
                        <div className="font-semibold text-ink-900 text-[13px] truncate max-w-xs">{v.title}</div>
                        <div className="text-[11px] text-ink-500 mt-0.5 font-mono">{v.id}</div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 text-[10.5px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${cls.tone}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${cls.dot}`}></span>{cls.short}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-[12px] text-ink-700 font-mono">{cls.retentionDays.toLocaleString()} days</td>
                      <td className="px-4 py-3 text-[12px] text-ink-500">{new Date(r.purgeAt).toLocaleDateString('en-US',{year:'numeric',month:'short',day:'numeric'})}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-24 h-1.5 bg-ink-100 rounded-full overflow-hidden">
                            <div className={`h-full ${r.pct > 33 ? 'bg-brand-500' : r.pct > 10 ? 'bg-amber-500' : 'bg-rose-500'}`} style={{width:`${r.pct}%`}}></div>
                          </div>
                          <span className="text-[12px] font-mono text-ink-700">{r.daysLeft.toLocaleString()}d</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}

function LifecycleDiagram() {
  const stages = [
    { key:'upload',  label:'Upload',     icon:'upload-cloud', detail:'TLS, antivirus scan, MIME validation' },
    { key:'process', label:'Processing', icon:'cpu',          detail:'Transcode → multi-bitrate, captions, thumbnails' },
    { key:'storage', label:'Active storage', icon:'database', detail:'KMS-encrypted S3, object versioning on' },
    { key:'archive', label:'Archival',   icon:'archive',      detail:'Glacier after 180 days inactive' },
    { key:'delete',  label:'Deletion',   icon:'trash-2',      detail:'Crypto-shred per classification policy' },
  ];
  return (
    <Card padding="p-5">
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2 relative">
        {stages.map((s, i) => (
          <React.Fragment key={s.key}>
            <div className="relative bg-ink-50 border border-ink-200 rounded-xl p-3.5 text-center">
              <div className="w-10 h-10 mx-auto rounded-lg bg-ink-900 text-white flex items-center justify-center mb-2">
                <Icon name={s.icon} size={16}/>
              </div>
              <div className="font-bold text-ink-900 text-[12.5px]">{s.label}</div>
              <div className="text-[10.5px] text-ink-500 mt-1 leading-snug">{s.detail}</div>
              {i < stages.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-2 -translate-y-1/2 text-ink-300 z-10 bg-white rounded-full">
                  <Icon name="arrow-right" size={14}/>
                </div>
              )}
            </div>
          </React.Fragment>
        ))}
      </div>
      <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px]">
        <LifecycleGate label="Auth" detail="JWT + MFA at gateway"/>
        <LifecycleGate label="RBAC" detail="Role gate per stage"/>
        <LifecycleGate label="Audit" detail="Every transition logged"/>
        <LifecycleGate label="Backup" detail="Daily snapshots × 30"/>
      </div>
    </Card>
  );
}

function LifecycleGate({ label, detail }) {
  return (
    <div className="flex items-center gap-2 bg-brand-50/40 border border-brand-200 rounded-lg px-2.5 py-2">
      <Icon name="shield-check" size={12} className="text-brand-600 flex-shrink-0"/>
      <div className="min-w-0">
        <div className="font-bold text-ink-900 text-[11px]">{label}</div>
        <div className="text-[10.5px] text-ink-500 truncate">{detail}</div>
      </div>
    </div>
  );
}

function ClassificationCard({ cls, videos }) {
  return (
    <div className={`rounded-xl border p-4 ${cls.tone.replace(/text-\S+/, '').trim()}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className={`w-2.5 h-2.5 rounded-full ${cls.dot}`}></span>
          <span className="font-bold text-ink-900 text-[14px]">{cls.label}</span>
        </div>
        <span className="font-mono text-[12px] font-bold text-ink-700">{videos.length}</span>
      </div>
      <div className="text-[12px] text-ink-600 mt-2">{cls.desc}</div>
      <div className="mt-3 grid grid-cols-2 gap-2 text-[11px]">
        <div className="bg-white/70 rounded-md px-2 py-1.5">
          <div className="text-ink-500 text-[10px] uppercase tracking-wider font-bold">Retention</div>
          <div className="text-ink-900 font-bold font-mono">{cls.retentionDays.toLocaleString()}d</div>
        </div>
        <div className="bg-white/70 rounded-md px-2 py-1.5">
          <div className="text-ink-500 text-[10px] uppercase tracking-wider font-bold">Encryption</div>
          <div className="text-ink-900 font-bold">{cls.key === 'PHI' ? 'AES-256 + HSM' : 'AES-256'}</div>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Tab 3 — Audit log
// ---------------------------------------------------------------------------
function AuditLogTab() {
  const { auditLog, users } = useApp();
  const [filterAction, setFilterAction] = React.useState('ALL');
  const [filterActor, setFilterActor] = React.useState('ALL');
  const [q, setQ] = React.useState('');

  const actionKeys = ['ALL', ...new Set(auditLog.map(e => e.action))];

  const filtered = auditLog.filter(e => {
    if (filterAction !== 'ALL' && e.action !== filterAction) return false;
    if (filterActor !== 'ALL' && e.actorId !== filterActor && e.actor !== users.find(u => u.id === filterActor)?.name) return false;
    if (q && !`${e.actor} ${e.action} ${e.resourceLabel||''} ${e.resourceId||''}`.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  }).slice(0, 100);

  return (
    <div className="space-y-4">
      <Card padding="p-3">
        <div className="flex flex-wrap gap-2 items-center">
          <div className="relative flex-1 min-w-[200px]">
            <Icon name="search" size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-400"/>
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search actor, action, or resource…" className="w-full h-9 pl-8 pr-3 rounded-lg border border-ink-200 text-[13px] focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100"/>
          </div>
          <Select value={filterAction} onChange={e => setFilterAction(e.target.value)}
            options={actionKeys.map(a => ({ value:a, label: a === 'ALL' ? 'All actions' : a }))}
            className="w-44"/>
          <Select value={filterActor} onChange={e => setFilterActor(e.target.value)}
            options={[{value:'ALL', label:'All users'}, ...users.map(u => ({ value: u.id, label: u.name }))]}
            className="w-52"/>
          <div className="text-[11.5px] text-ink-500 ml-auto font-mono">{filtered.length} of {auditLog.length} events</div>
        </div>
      </Card>

      <Card padding="p-0">
        <div className="overflow-x-auto scroll-thin">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-ink-50 border-b border-ink-200 text-[11px] uppercase tracking-widest text-ink-500">
                <th className="text-left font-bold px-4 py-2.5">Timestamp</th>
                <th className="text-left font-bold px-4 py-2.5">Actor</th>
                <th className="text-left font-bold px-4 py-2.5">Action</th>
                <th className="text-left font-bold px-4 py-2.5">Resource</th>
                <th className="text-left font-bold px-4 py-2.5 hidden lg:table-cell">Source</th>
                <th className="text-left font-bold px-4 py-2.5 hidden md:table-cell">Outcome</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="text-center py-10 text-ink-400 text-sm">No audit events match your filter.</td></tr>
              )}
              {filtered.map(e => (
                <tr key={e.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50/60 align-top">
                  <td className="px-4 py-2.5 text-[11.5px] font-mono text-ink-600 whitespace-nowrap">
                    <div>{new Date(e.at).toLocaleString('en-US', { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit', second:'2-digit' })}</div>
                    <div className="text-ink-400 text-[10px]">{timeAgo(e.at)}</div>
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="text-[12.5px] font-semibold text-ink-900">{e.actor}</div>
                    {e.sessionId && <div className="text-[10px] font-mono text-ink-400">{e.sessionId.slice(0, 18)}…</div>}
                  </td>
                  <td className="px-4 py-2.5">
                    <code className="text-[11.5px] font-mono font-semibold bg-ink-100 text-ink-700 px-1.5 py-0.5 rounded">{e.action}</code>
                  </td>
                  <td className="px-4 py-2.5">
                    {e.resourceLabel ? (
                      <div>
                        <div className="text-[12.5px] text-ink-800 truncate max-w-xs">{e.resourceLabel}</div>
                        <div className="text-[10px] font-mono text-ink-400">{e.resourceType} · {e.resourceId}</div>
                      </div>
                    ) : <span className="text-[12px] text-ink-400">—</span>}
                  </td>
                  <td className="px-4 py-2.5 hidden lg:table-cell text-[11.5px] font-mono text-ink-500">
                    {e.sourceIp}<br/><span className="text-[10px] text-ink-400">{e.userAgent}</span>
                  </td>
                  <td className="px-4 py-2.5 hidden md:table-cell">
                    <span className={`inline-flex items-center gap-1 text-[10.5px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border ${e.outcome === 'success' ? 'bg-brand-50 text-brand-700 border-brand-200' : 'bg-rose-50 text-rose-700 border-rose-200'}`}>
                      <Icon name={e.outcome === 'success' ? 'check' : 'x'} size={10}/>
                      {e.outcome}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="text-[11.5px] text-ink-500 bg-white border border-ink-200 rounded-lg p-3 flex items-start gap-2">
        <Icon name="info" size={13} className="text-ink-400 mt-0.5 flex-shrink-0"/>
        <div><span className="font-semibold text-ink-700">In production:</span> entries are append-only, signed with a per-event HMAC chained to the previous event's signature, and replicated to an immutable WORM store for SOC export.</div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Tab 4 — RBAC matrix
// ---------------------------------------------------------------------------
function RBACMatrixTab() {
  const roles = ['ADMIN', 'DOCTOR', 'EDITOR', 'WRITER', 'APPROVER_PEER', 'APPROVER_FINAL', 'SOCIAL'];
  const roleLabels = {
    ADMIN:'Admin', DOCTOR:'Doctor', EDITOR:'Editor', WRITER:'Writer',
    APPROVER_PEER:'Reviewer · S1', APPROVER_FINAL:'Reviewer · S2', SOCIAL:'Social',
  };
  const permissions = [
    { group:'User management', items:[
      { key:'users.read',   label:'View user directory' },
      { key:'users.create', label:'Create / invite users' },
      { key:'users.update', label:'Edit user details / role' },
      { key:'users.delete', label:'Deactivate / delete users' },
    ]},
    { group:'Video content', items:[
      { key:'video.upload',          label:'Upload original recording' },
      { key:'video.read.own',        label:'View own videos' },
      { key:'video.read.all',        label:'View all videos' },
      { key:'video.download.raw',    label:'Download raw (PHI) version' },
      { key:'video.download.edit',   label:'Download edited cut' },
      { key:'video.upload.edit',     label:'Upload edited cut' },
      { key:'video.delete',          label:'Permanent delete' },
    ]},
    { group:'Workflow', items:[
      { key:'workflow.write_captions',   label:'Write captions & hashtags' },
      { key:'workflow.peer_approve',     label:'Approve at Stage 1 (peer)' },
      { key:'workflow.final_approve',    label:'Approve at Stage 2 (final)' },
      { key:'workflow.send_back',        label:'Send back for changes' },
      { key:'workflow.publish',          label:'Publish to channels' },
    ]},
    { group:'Governance', items:[
      { key:'audit.read',         label:'Read audit log' },
      { key:'audit.export',       label:'Export evidence to SOC' },
      { key:'classification.set', label:'Override classification' },
    ]},
  ];

  // Permission matrix — keep it explicit, easy to audit.
  const matrix = {
    'users.read':                 { ADMIN:'full' },
    'users.create':               { ADMIN:'full' },
    'users.update':               { ADMIN:'full' },
    'users.delete':               { ADMIN:'full' },
    'video.upload':               { ADMIN:'full', DOCTOR:'full' },
    'video.read.own':             { ADMIN:'full', DOCTOR:'full', EDITOR:'full', WRITER:'full', APPROVER_PEER:'full', APPROVER_FINAL:'full', SOCIAL:'full' },
    'video.read.all':             { ADMIN:'full' },
    'video.download.raw':         { ADMIN:'full', DOCTOR:'own', EDITOR:'assigned' },
    'video.download.edit':        { ADMIN:'full', DOCTOR:'own', EDITOR:'assigned', WRITER:'assigned', APPROVER_PEER:'assigned', APPROVER_FINAL:'assigned', SOCIAL:'assigned' },
    'video.upload.edit':          { ADMIN:'full', EDITOR:'assigned' },
    'video.delete':               { ADMIN:'full' },
    'workflow.write_captions':    { ADMIN:'full', WRITER:'assigned' },
    'workflow.peer_approve':      { ADMIN:'full', APPROVER_PEER:'assigned' },
    'workflow.final_approve':     { ADMIN:'full', APPROVER_FINAL:'assigned' },
    'workflow.send_back':         { ADMIN:'full', APPROVER_PEER:'assigned', APPROVER_FINAL:'assigned' },
    'workflow.publish':           { ADMIN:'full', SOCIAL:'assigned' },
    'audit.read':                 { ADMIN:'full' },
    'audit.export':               { ADMIN:'full' },
    'classification.set':         { ADMIN:'full' },
  };

  const dot = (level) => {
    if (!level) return <span className="text-ink-300">·</span>;
    if (level === 'full') return <span className="inline-flex items-center gap-1 text-brand-700 font-bold text-[11px]"><span className="w-1.5 h-1.5 rounded-full bg-brand-500"></span>FULL</span>;
    if (level === 'assigned') return <span className="inline-flex items-center gap-1 text-amber-700 font-bold text-[11px]"><span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>SCOPED</span>;
    if (level === 'own') return <span className="inline-flex items-center gap-1 text-blue-700 font-bold text-[11px]"><span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>OWN</span>;
    return null;
  };

  return (
    <div className="space-y-4">
      <Card padding="p-3">
        <div className="flex flex-wrap items-center gap-3 text-[11.5px]">
          <span className="font-bold text-ink-700">Legend:</span>
          <span className="inline-flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-brand-500"></span><span className="text-ink-700"><span className="font-bold">Full</span> · unrestricted access</span></span>
          <span className="inline-flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-amber-500"></span><span className="text-ink-700"><span className="font-bold">Scoped</span> · only resources assigned to user</span></span>
          <span className="inline-flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-blue-500"></span><span className="text-ink-700"><span className="font-bold">Own</span> · only resources the user created</span></span>
          <span className="inline-flex items-center gap-1.5 text-ink-400">· no access</span>
        </div>
      </Card>

      <Card padding="p-0">
        <div className="overflow-x-auto scroll-thin">
          <table className="w-full text-sm">
            <thead className="sticky top-0">
              <tr className="bg-ink-100 text-[11px] uppercase tracking-widest text-ink-600">
                <th className="text-left font-bold px-4 py-2.5 sticky left-0 bg-ink-100 z-10">Permission</th>
                {roles.map(r => <th key={r} className="text-center font-bold px-3 py-2.5 whitespace-nowrap">{roleLabels[r]}</th>)}
              </tr>
            </thead>
            <tbody>
              {permissions.map(group => (
                <React.Fragment key={group.group}>
                  <tr className="bg-ink-50/60">
                    <td colSpan={1 + roles.length} className="px-4 py-1.5 text-[10.5px] font-bold uppercase tracking-widest text-ink-500">{group.group}</td>
                  </tr>
                  {group.items.map(item => (
                    <tr key={item.key} className="border-b border-ink-100 hover:bg-ink-50/40">
                      <td className="px-4 py-2 sticky left-0 bg-white">
                        <div className="font-semibold text-ink-900 text-[12.5px]">{item.label}</div>
                        <code className="text-[10px] font-mono text-ink-400">{item.key}</code>
                      </td>
                      {roles.map(r => (
                        <td key={r} className="text-center px-3 py-2 whitespace-nowrap">{dot(matrix[item.key]?.[r])}</td>
                      ))}
                    </tr>
                  ))}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="text-[11.5px] text-ink-500 bg-white border border-ink-200 rounded-lg p-3 flex items-start gap-2">
        <Icon name="info" size={13} className="text-ink-400 mt-0.5 flex-shrink-0"/>
        <div><span className="font-semibold text-ink-700">Enforcement:</span> in production, this matrix is the source of truth. The API gateway loads it at startup and checks every request via an OPA (Open Policy Agent) sidecar — independent of the UI.</div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Tab 5 — Architecture diagram
// ---------------------------------------------------------------------------
function ArchitectureTab() {
  return (
    <div className="space-y-6">
      <Card padding="p-5">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
          <div>
            <h3 className="font-bold text-ink-900 text-[16px]">Production reference architecture</h3>
            <div className="text-[12.5px] text-ink-500 mt-1">What needs to exist for this demo to meet the governance checklist in production.</div>
          </div>
          <div className="flex items-center gap-3 text-[11px]">
            <LegendSwatch color="bg-ink-200" label="In demo"/>
            <LegendSwatch color="bg-brand-200" label="Real, today"/>
            <LegendSwatch color="bg-amber-200" label="To build"/>
          </div>
        </div>
        <ArchitectureDiagram/>
      </Card>

      <div>
        <SectionHeader title="Component inventory" hint="What each layer does and where it lives"/>
        <ComponentInventory/>
      </div>
    </div>
  );
}

function LegendSwatch({ color, label }) {
  return <span className="inline-flex items-center gap-1.5"><span className={`w-3 h-3 rounded ${color}`}></span><span className="text-ink-600">{label}</span></span>;
}

function ArchitectureDiagram() {
  // Box = [x, y, w, h, label, status, sub]
  // status: 'demo' (ink), 'real' (brand), 'todo' (amber)
  const groups = [
    { x:20,  y:20,  w:300, h:120, title:'CLIENT', items:[
      { x:30, y:50, w:130, h:60, label:'Web App', sub:'React · this demo', status:'real' },
      { x:170,y:50, w:140, h:60, label:'Mobile App', sub:'iOS / Android', status:'todo' },
    ]},
    { x:20,  y:160, w:300, h:120, title:'EDGE', items:[
      { x:30, y:190, w:130, h:60, label:'CloudFront', sub:'TLS 1.3 · CDN', status:'todo' },
      { x:170,y:190, w:140, h:60, label:'WAF', sub:'OWASP rules + bot guard', status:'todo' },
    ]},
    { x:350, y:20,  w:380, h:260, title:'API & SECURITY', items:[
      { x:360, y:50,  w:170, h:60, label:'API Gateway', sub:'JWT + rate limit', status:'todo' },
      { x:540, y:50,  w:180, h:60, label:'Auth Service', sub:'Cognito · MFA · refresh', status:'todo' },
      { x:360, y:130, w:170, h:60, label:'OPA Policy Engine', sub:'RBAC matrix at every req', status:'todo' },
      { x:540, y:130, w:180, h:60, label:'Workflow API', sub:'Status FSM · 2-stage approval', status:'todo' },
      { x:360, y:210, w:170, h:60, label:'Audit Service', sub:'HMAC-chained · WORM', status:'todo' },
      { x:540, y:210, w:180, h:60, label:'Notification Service', sub:'Email · SMS · in-app', status:'todo' },
    ]},
    { x:760, y:20, w:300, h:120, title:'DATA', items:[
      { x:770, y:50, w:130, h:60, label:'PostgreSQL', sub:'Aurora · multi-AZ', status:'todo' },
      { x:910, y:50, w:140, h:60, label:'S3 + KMS', sub:'Video objects · AES-256', status:'todo' },
    ]},
    { x:760, y:160, w:300, h:120, title:'OBSERVABILITY', items:[
      { x:770, y:190, w:130, h:60, label:'OpenSearch', sub:'Logs · audit query', status:'todo' },
      { x:910, y:190, w:140, h:60, label:'Datadog', sub:'Metrics · traces · alerts', status:'todo' },
    ]},
  ];

  const allBoxes = groups.flatMap(g => g.items);
  const find = (label) => allBoxes.find(b => b.label === label);

  const connections = [
    ['Web App', 'CloudFront'],
    ['CloudFront', 'WAF'],
    ['WAF', 'API Gateway'],
    ['API Gateway', 'Auth Service'],
    ['API Gateway', 'OPA Policy Engine'],
    ['OPA Policy Engine', 'Workflow API'],
    ['Workflow API', 'PostgreSQL'],
    ['Workflow API', 'S3 + KMS'],
    ['Workflow API', 'Audit Service'],
    ['Workflow API', 'Notification Service'],
    ['Audit Service', 'OpenSearch'],
    ['Audit Service', 'PostgreSQL'],
  ];

  const statusFill = { real:'#D1F5EA', todo:'#FEF3C7', demo:'#EEF1F5' };
  const statusStroke = { real:'#13A786', todo:'#D97706', demo:'#8593A8' };

  return (
    <div className="bg-ink-50 rounded-xl border border-ink-200 overflow-auto scroll-thin">
      <svg viewBox="0 0 1080 300" className="w-full" style={{ minWidth: 900 }}>
        <defs>
          <marker id="archArrow" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
            <path d="M0,0 L6,3 L0,6 Z" fill="#3F4D62"/>
          </marker>
        </defs>

        {/* Group containers */}
        {groups.map(g => (
          <g key={g.title}>
            <rect x={g.x} y={g.y} width={g.w} height={g.h} fill="white" stroke="#DCE2EB" strokeWidth="1" strokeDasharray="3 3" rx="10"/>
            <text x={g.x + 10} y={g.y + 16} fill="#5B6B82" fontSize="9" fontWeight="700" letterSpacing="1">{g.title}</text>
          </g>
        ))}

        {/* Connections */}
        {connections.map(([a, b], i) => {
          const A = find(a), B = find(b);
          if (!A || !B) return null;
          const ax = A.x + A.w / 2, ay = A.y + A.h / 2;
          const bx = B.x + B.w / 2, by = B.y + B.h / 2;
          // Pick edge attach points
          const dx = bx - ax, dy = by - ay;
          let x1, y1, x2, y2;
          if (Math.abs(dx) > Math.abs(dy)) {
            x1 = dx > 0 ? A.x + A.w : A.x;
            y1 = ay;
            x2 = dx > 0 ? B.x : B.x + B.w;
            y2 = by;
          } else {
            x1 = ax;
            y1 = dy > 0 ? A.y + A.h : A.y;
            x2 = bx;
            y2 = dy > 0 ? B.y : B.y + B.h;
          }
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#3F4D62" strokeWidth="1.2" markerEnd="url(#archArrow)" opacity="0.55"/>;
        })}

        {/* Boxes */}
        {allBoxes.map(b => (
          <g key={b.label}>
            <rect x={b.x} y={b.y} width={b.w} height={b.h} rx="8" fill={statusFill[b.status]} stroke={statusStroke[b.status]} strokeWidth="1.5"/>
            <text x={b.x + b.w/2} y={b.y + 24} textAnchor="middle" fontSize="13" fontWeight="700" fill="#0E1521">{b.label}</text>
            <text x={b.x + b.w/2} y={b.y + 42} textAnchor="middle" fontSize="10" fill="#5B6B82">{b.sub}</text>
          </g>
        ))}
      </svg>
    </div>
  );
}

function ComponentInventory() {
  const components = [
    { tier:'Edge',     name:'CloudFront + WAF',  desc:'TLS termination, OWASP rules, geo-fence, DDoS shield', status:'todo', tech:'AWS' },
    { tier:'API',      name:'API Gateway',       desc:'JWT validation, per-route rate limit, request schema validation',           status:'todo', tech:'AWS API Gateway / Kong' },
    { tier:'API',      name:'Auth Service',      desc:'OIDC, MFA (TOTP/WebAuthn), short-lived access tokens + refresh tokens',     status:'todo', tech:'Cognito / Auth0 / Keycloak' },
    { tier:'API',      name:'OPA Policy Engine', desc:'Centralized RBAC enforcement — same matrix as the Governance tab',           status:'todo', tech:'Open Policy Agent + Rego' },
    { tier:'API',      name:'Workflow API',      desc:'Finite-state machine for video status; two-stage approval transitions',     status:'todo', tech:'Node / Go microservice' },
    { tier:'API',      name:'Audit Service',     desc:'Append-only event store, HMAC chain, WORM mirror for SOC export',           status:'todo', tech:'Lambda + DynamoDB Streams' },
    { tier:'Data',     name:'PostgreSQL (Aurora)',  desc:'User, video metadata, workflow state. KMS-encrypted at rest',             status:'todo', tech:'AWS Aurora Postgres' },
    { tier:'Data',     name:'S3 + KMS',           desc:'Raw + edited video objects. Per-classification bucket policies, object lock',status:'todo', tech:'AWS S3 + KMS' },
    { tier:'Data',     name:'OpenSearch',         desc:'Audit queries + log aggregation. 90-day hot, 7-year warm tier',              status:'todo', tech:'AWS OpenSearch' },
    { tier:'Observ.',  name:'Datadog (or OTEL)',  desc:'Metrics, traces, anomaly detection on auth failures & sensitive operations',status:'todo', tech:'Datadog / Grafana' },
    { tier:'Client',   name:'Web app',            desc:'You are here. React + Tailwind. Demo state in localStorage',                 status:'real', tech:'This codebase' },
  ];
  const statusCfg = {
    real: { dot:'bg-brand-500', label:'Live', text:'text-brand-700 bg-brand-50 border-brand-200' },
    todo: { dot:'bg-amber-500', label:'To build', text:'text-amber-700 bg-amber-50 border-amber-200' },
    demo: { dot:'bg-ink-400',   label:'Demo only', text:'text-ink-700 bg-ink-100 border-ink-200' },
  };
  return (
    <Card padding="p-0">
      <div className="overflow-x-auto scroll-thin">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-ink-50 border-b border-ink-200 text-[11px] uppercase tracking-widest text-ink-500">
              <th className="text-left font-bold px-4 py-2.5">Tier</th>
              <th className="text-left font-bold px-4 py-2.5">Component</th>
              <th className="text-left font-bold px-4 py-2.5">Responsibility</th>
              <th className="text-left font-bold px-4 py-2.5 hidden md:table-cell">Reference tech</th>
              <th className="text-left font-bold px-4 py-2.5">Status</th>
            </tr>
          </thead>
          <tbody>
            {components.map(c => (
              <tr key={c.name} className="border-b border-ink-100 last:border-0 hover:bg-ink-50/60">
                <td className="px-4 py-2.5 text-[11.5px] font-bold uppercase tracking-wider text-ink-500">{c.tier}</td>
                <td className="px-4 py-2.5 font-semibold text-ink-900 text-[13px]">{c.name}</td>
                <td className="px-4 py-2.5 text-[12px] text-ink-600 leading-relaxed">{c.desc}</td>
                <td className="px-4 py-2.5 hidden md:table-cell text-[12px] text-ink-500 font-mono">{c.tech}</td>
                <td className="px-4 py-2.5">
                  <span className={`inline-flex items-center gap-1 text-[10.5px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${statusCfg[c.status].text}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${statusCfg[c.status].dot}`}></span>
                    {statusCfg[c.status].label}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

Object.assign(window, { GovernancePage });
